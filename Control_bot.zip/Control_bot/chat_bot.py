import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from handlers.chat_handler import router as chat_router
from config import load_config

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Загружаем конфигурацию
config = load_config()

# Создаем чат-бота
chat_bot = Bot(token=config.chat_bot_token)
chat_storage = MemoryStorage()
chat_dp = Dispatcher(storage=chat_storage)

# Подключаем роутеры
chat_dp.include_router(chat_router)