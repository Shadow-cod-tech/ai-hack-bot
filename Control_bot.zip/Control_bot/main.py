import asyncio
import logging
from aiogram.types import Message
from keyboards.main_menu import main_menu
from main_bot import main_bot, main_dp
from chat_bot import chat_bot, chat_dp
from services.autoposter import initialize_autoposter

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# НАСТРОЙКИ КАНАЛА
CHANNEL_ID = "@kubovskiyandrey"  # Замените на ваш канал, например "@kubovskiyandrey"

# Обработчики команд для основного бота
@main_dp.message(lambda m: m.text == "/start")
async def start_command(message: Message):
    """Обработчик команды /start для основного бота"""
    welcome_text = (
        "👋 <b>Привет! Я Control-бот Андрея</b>\n\n"
        "🏋️ <b>Андрей</b> — Повар, диабетик со стажем 3 года\n"
        "💪 Помогу с рационом, тренировками и вопросами о диабете\n\n"
        "🎯 Выбери, что тебя интересует:\n\n"
        "🤝 По вопросам сотрудничества: @Control8AI_bot\n"
        "💡 <i>Нравится Ассистент? Можете заказать тут: @Niro7_Bot</i>"
    )
    
    await message.answer(
        welcome_text, 
        reply_markup=main_menu, 
        parse_mode="HTML"
    )

@main_dp.message(lambda m: m.text == "/help")
async def help_command(message: Message):
    """Обработчик команды /help для основного бота"""
    help_text = (
        "🤖 <b>Как пользоваться ботом:</b>\n\n"
        "🍽️ <b>Рацион</b> — готовые планы питания\n"
        "🥗 <b>Питание</b> — расчет КБЖУ и советы\n"
        "🏋️ <b>Тренировки</b> — программы упражнений\n"
        "❓ <b>Задать вопрос</b> — свободное общение\n"
        "💎 <b>VIP функции</b> — персональные программы\n"
        "🤖 <b>Свой AI Ассистент</b> — заказать бота\n"
        "🗑 <b>Очистить диалог</b> — сбросить контекст\n\n"
        "Просто нажимай на кнопки и получай ответы! 😊\n\n"
        "💡 <i>Нравится Ассистент? Можете заказать тут: @Niro7_Bot</i>"
    )
    
    await message.answer(help_text, parse_mode="HTML")

# КОМАНДЫ ДЛЯ АВТОПОСТИНГА (только для админа)
@main_dp.message(lambda m: m.text == "/start_autopost")
async def start_autopost_command(message: Message):
    """Запуск автопостинга (только для админа)"""
    from config import load_config
    config = load_config()
    
    if message.from_user.id != config.admin_id:
        await message.answer("❌ Команда только для администратора")
        return
    
    try:
        autoposter = initialize_autoposter(main_bot, CHANNEL_ID)
        await autoposter.start_scheduler()
        await message.answer("✅ Автопостинг запущен!\n\n📅 Расписание:\n12:00 - Ежедневный пост\n\n🔄 Чередование:\nДень 1: Совет дня\nДень 2: Рецепт\nДень 3: Тренировка")
    except Exception as e:
        await message.answer(f"❌ Ошибка запуска автопостинга: {e}")

@main_dp.message(lambda m: m.text == "/stop_autopost")
async def stop_autopost_command(message: Message):
    """Остановка автопостинга (только для админа)"""
    from config import load_config
    config = load_config()
    
    if message.from_user.id != config.admin_id:
        await message.answer("❌ Команда только для администратора")
        return
    
    try:
        from services.autoposter import autoposter
        if autoposter:
            await autoposter.stop_scheduler()
            await message.answer("⏹️ Автопостинг остановлен")
        else:
            await message.answer("❌ Автопостинг не был запущен")
    except Exception as e:
        await message.answer(f"❌ Ошибка остановки автопостинга: {e}")

@main_dp.message(lambda m: m.text == "/toggle_content")
async def toggle_content_command(message: Message):
    """Переключение режима контента (только для админа)"""
    from config import load_config
    config = load_config()
    
    if message.from_user.id != config.admin_id:
        await message.answer("❌ Команда только для администратора")
        return
    
    try:
        from services.autoposter import autoposter
        if autoposter:
            mode = autoposter.toggle_content_mode()
            await message.answer(f"🔄 Переключен на {mode} контент")
        else:
            await message.answer("❌ Автопостер не инициализирован")
    except Exception as e:
        await message.answer(f"❌ Ошибка переключения режима: {e}")

@main_dp.message(lambda m: m.text.startswith("/test_post"))
async def test_post_command(message: Message):
    """Тестовая публикация (только для админа)"""
    from config import load_config
    config = load_config()
    
    if message.from_user.id != config.admin_id:
        await message.answer("❌ Команда только для администратора")
        return
    
    try:
        # Парсим тип поста из команды
        parts = message.text.split()
        post_type = parts[1] if len(parts) > 1 else "morning"
        
        autoposter = initialize_autoposter(main_bot, CHANNEL_ID)
        await autoposter.test_post(post_type)
        await message.answer(f"✅ Тестовый пост '{post_type}' опубликован")
        
    except Exception as e:
        await message.answer(f"❌ Ошибка тестовой публикации: {e}")

async def main():
    """Запуск обоих ботов"""
    logger.info("Запуск основного бота и чат-бота...")
    
    try:
        # Запускаем оба бота одновременно
        await asyncio.gather(
            main_dp.start_polling(main_bot, skip_updates=True),
            chat_dp.start_polling(chat_bot, skip_updates=True)
        )
    except Exception as e:
        logger.error(f"Ошибка при запуске ботов: {e}")
    finally:
        await main_bot.session.close()
        await chat_bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())