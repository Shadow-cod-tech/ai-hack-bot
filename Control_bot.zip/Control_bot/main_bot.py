import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from handlers.main_handler import router as main_router
from config import load_config

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Загружаем конфигурацию
config = load_config()

# Создаем основного бота
main_bot = Bot(token=config.main_bot_token)
main_storage = MemoryStorage()
main_dp = Dispatcher(storage=main_storage)

# Подключаем роутеры
main_dp.include_router(main_router)