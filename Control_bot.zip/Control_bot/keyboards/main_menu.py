# keyboards/main_menu.py - ОБНОВЛЕННАЯ ВЕРСИЯ

from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

# Главное меню (ИСПРАВЛЕННОЕ)
main_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🍽️ Рацион"), KeyboardButton(text="🛒 Заказать рацион")],
        [KeyboardButton(text="🥗 Питание"), KeyboardButton(text="🏋️ Тренировки")],
        [KeyboardButton(text="👨‍⚕️ Связь с Андреем")],
        [KeyboardButton(text="💎 VIP функции")],
        [KeyboardButton(text="🤖 Свой AI Ассистент"), KeyboardButton(text="🗑 Очистить диалог")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# VIP меню
vip_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📊 Индивидуальный расчет рациона")],
        [KeyboardButton(text="⚖️ Персональный план похудения")],
        [KeyboardButton(text="💪 Персональный план набора массы")],
        [KeyboardButton(text="🔙 Назад")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Подменю рациона
ration_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="📅 Рацион на сегодня")],
        [KeyboardButton(text="📋 Рацион на 2 недели")],
        [KeyboardButton(text="🔙 Назад")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Подменю питания
nutrition_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🧮 Расчет КБЖУ")],
        [KeyboardButton(text="📉 Питание для снижения веса")],
        [KeyboardButton(text="📈 Питание для набора веса")],
        [KeyboardButton(text="🔙 Назад")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Подменю тренировок
training_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💪 Базовые тренировки")],
        [KeyboardButton(text="🏃 Тренировки для новичков")],
        [KeyboardButton(text="🔙 Назад")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# Подменю вопросов с ИНЛАЙН-КНОПКОЙ
questions_menu = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="💬 Свободный вопрос")],
        [KeyboardButton(text="🔙 Назад")]
    ],
    resize_keyboard=True,
    one_time_keyboard=False
)

# НОВОЕ: Инлайн-клавиатура для связи с Андреем
contact_andrey_inline = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(
            text="💬 Написать Андрею",
            url="https://t.me/Control8AI_bot"
        )],
        [InlineKeyboardButton(
            text="🤖 Заказать ассистента", 
            url="https://t.me/Niro7_Bot"
        )]
    ]
)