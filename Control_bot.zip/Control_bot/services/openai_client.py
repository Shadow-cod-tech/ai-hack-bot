from openai import OpenAI
from typing import Optional
import logging
import asyncio
import re

logger = logging.getLogger(__name__)

ANDREY_SYSTEM_PROMPT = """
Ты — Андрей, блогер и тренер по здоровому образу жизни. Твой стиль — честный, простой, дружелюбный.

ВАЖНЫЕ ПРАВИЛА:
- НЕ упоминай диабет в каждом ответе
- Диабет - это ТОЛЬКО одна из твоих тем, не главная
- Если человек не говорил про диабет - НЕ начинай про него
- Сначала дай общий совет, потом можешь добавить "а с диабетом..."
- Не все люди диабетики! Отвечай универсально
- На "как дела?" отвечай просто как человек
- НЕ говори "У меня было похоже" если не связано с диабетом

ЗАПРЕЩЕНО ЗАДАВАТЬ ВОПРОСЫ В КОНЦЕ ОТВЕТА!
- НЕ спрашивай "Как у Вас дела?"
- НЕ спрашивай "А Вы что предпочитаете?"
- НЕ спрашивай "Как Вы планируете рацион?"
- ВСЕГДА заканчивай советом или мотивацией

ОБЯЗАТЕЛЬНАЯ КОНЦОВКА:
"Если есть вопросы - пишите @Control8AI_bot"

СТОП-СЛОВА: НЕ начинай ответы с:
- "У меня было похоже..."
- "Когда я только начинал с диабетом..."
- "Проверяем уровень сахара..."

ПРИМЕРЫ ПРАВИЛЬНЫХ ОТВЕТОВ:
- "что поесть?" → "Рекомендую овощной салат с курицей. Сытно и полезно! 😊"
- "как дела?" → "Отлично! Спасибо что спросили. Как у Вас дела? 😀"
- "хочу похудеть" → "Главное - дефицит калорий и больше движения! 💪"

🎯 СТИЛЬ РЕЧИ:
- Пишешь от первого лица
- Обращайся к пользователю на «Вы» (уважительно)
- Тон: дружелюбный, иногда шутливый, мотивирующий без поучений
- Короткие предложения, живой язык

📚 ЭКСПЕРТИЗА:
- Здоровое питание и калории
- Диабет 1 типа (только если спрашивают напрямую)
- Тренировки и фитнес
- Объясняешь простыми словами, через примеры из жизни

😊 ЭМОДЗИ: 🫶 😀 ☀️ 🫡 🥳 (2-3 в конце абзацев)

💬 ПРИМЕРЫ ФРАЗ:
- «Вот и прожит ещё один день»
- «Если я смог — и Вы сможете»
- «Жизнь как у атлета»
- «Взвешиваю заранее — так спокойнее»

Используй HTML теги: <b>жирный</b>, <i>курсив</i>. НЕ используй markdown.
Всегда напоминай о важности консультации с врачом.
"""

def convert_markdown_to_html(text: str) -> str:
    """Конвертирует markdown в HTML теги для Telegram"""
    # Заменяем LaTeX формулы \[ формула \] на обычный текст
    text = re.sub(r'\\\[\s*(.*?)\s*\\\]', r'\1', text, flags=re.DOTALL)
    
    # Заменяем LaTeX формулы \( формула \) на обычный текст
    text = re.sub(r'\\\(\s*(.*?)\s*\\\)', r'\1', text)
    
    # Заменяем \text{текст} на просто текст
    text = re.sub(r'\\text\{(.*?)\}', r'\1', text)
    
    # Заменяем \times на ×
    text = text.replace(r'\times', '×')
    
    # Заменяем заголовки ### на жирный текст
    text = re.sub(r'###\s*(.*?)(?=\n|$)', r'<b>\1</b>', text)
    text = re.sub(r'##\s*(.*?)(?=\n|$)', r'<b>\1</b>', text)
    text = re.sub(r'#\s*(.*?)(?=\n|$)', r'<b>\1</b>', text)
    
    # Заменяем **текст** на <b>текст</b>
    text = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', text)
    
    # Заменяем *текст* на <i>текст</i>
    text = re.sub(r'\*(.*?)\*', r'<i>\1</i>', text)
    
    # Заменяем `код` на <code>код</code>
    text = re.sub(r'`(.*?)`', r'<code>\1</code>', text)
    
    # Добавляем переносы после предложений для создания абзацев
    text = re.sub(r'(\. )([А-ЯA-Z])', r'\1\n\n\2', text)  # После точки и пробела перед заглавной буквой
    text = re.sub(r'(! )([А-ЯA-Z])', r'\1\n\n\2', text)  # После восклицательного знака
    
    # Принудительно добавляем перенос перед всей финальной фразой
    text = text.replace("Если есть вопросы", "\nЕсли есть вопросы")
    text = text.replace("Если остались вопросы", "\nЕсли остались вопросы")
    
    return text

class OpenAIClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.client = OpenAI(api_key=api_key)
        logger.info("OpenAI клиент инициализирован (новая версия)")
    
    async def get_completion(
        self, 
        prompt: str, 
        model: str = "gpt-4o",
        max_tokens: int = 1000,
        temperature: float = 0.8
    ) -> Optional[str]:
        """
        Получение ответа от OpenAI API (новая версия)
        """
        try:
            logger.info(f"Отправка запроса в OpenAI (модель: {model})")
            
            # Используем новый API клиент
            response = await asyncio.to_thread(
                self.client.chat.completions.create,
                model=model,
                messages=[
                    {
                        "role": "system", 
                        "content": ANDREY_SYSTEM_PROMPT
                    },
                    {
                        "role": "user", 
                        "content": prompt
                    }
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                timeout=30
            )
            
            answer = response.choices[0].message.content.strip()
            
            # ДОБАВЛЯЕМ КОНВЕРТАЦИЮ MARKDOWN В HTML
            answer = convert_markdown_to_html(answer)
            
            logger.info(f"Получен ответ от OpenAI ({len(answer)} символов)")
            
            return answer
            
        except Exception as e:
            error_msg = str(e).lower()
            
            if "rate limit" in error_msg:
                logger.error("Превышен лимит запросов OpenAI")
                return "⏳ Слишком много запросов. Попробуйте через минуту."
                
            elif "authentication" in error_msg or "unauthorized" in error_msg:
                logger.error("Ошибка аутентификации OpenAI")
                return "❌ Проблема с доступом к ИИ. Обратитесь к администратору."
                
            elif "invalid" in error_msg or "bad request" in error_msg:
                logger.error(f"Неверный запрос к OpenAI: {e}")
                return "❌ Ошибка в запросе. Попробуйте переформулировать вопрос."
                
            elif "openai" in error_msg:
                logger.error(f"Ошибка OpenAI API: {e}")
                return "🤖 Временные проблемы с ИИ. Попробуйте позже."
                
            else:
                logger.error(f"Неожиданная ошибка: {e}")
                return "❌ Что-то пошло не так. Попробуйте позже или обратитесь к поддержке."