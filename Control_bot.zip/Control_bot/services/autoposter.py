# services/autoposter.py - 1 ПОСТ В ДЕНЬ

import asyncio
import logging
from datetime import datetime, time
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from aiogram import Bot
from config import load_config
from .dynamic_content import content_generator
from .post_content import get_morning_advice, get_recipe_post, get_evening_training

logger = logging.getLogger(__name__)

class AutoPoster:
    def __init__(self, bot: Bot, channel_id: str):
        self.bot = bot
        self.channel_id = channel_id
        self.scheduler = AsyncIOScheduler()
        self.is_running = False
        self.use_dynamic_content = True
        self.post_cycle = 0  # Для чередования типов постов
        
    async def start_scheduler(self):
        """Запуск планировщика автопостов"""
        if self.is_running:
            logger.info("Планировщик уже запущен")
            return
            
        try:
            # ОДИН пост в день в 12:00
            self.scheduler.add_job(
                func=self.post_daily_content,
                trigger=CronTrigger(hour=12, minute=0),
                id='daily_post',
                name='Ежедневный пост'
            )
            
            self.scheduler.start()
            self.is_running = True
            mode = "динамическим" if self.use_dynamic_content else "статичным"
            logger.info(f"✅ Планировщик автопостов запущен с {mode} контентом (1 пост в день)")
            
        except Exception as e:
            logger.error(f"❌ Ошибка запуска планировщика: {e}")
    
    async def post_daily_content(self):
        """Публикация ежедневного поста с чередованием типов"""
        try:
            # Чередуем типы постов: совет → рецепт → тренировка
            post_types = ['morning', 'recipe', 'training']
            current_type = post_types[self.post_cycle % 3]
            
            if self.use_dynamic_content:
                if current_type == 'morning':
                    content = await content_generator.generate_morning_advice()
                    logger.info("📝 Сгенерирован динамический совет дня")
                elif current_type == 'recipe':
                    content = await content_generator.generate_recipe_post()
                    logger.info("📝 Сгенерирован динамический рецепт")
                else:  # training
                    content = await content_generator.generate_training_post()
                    logger.info("📝 Сгенерирована динамическая тренировка")
            else:
                if current_type == 'morning':
                    content = get_morning_advice()
                elif current_type == 'recipe':
                    content = get_recipe_post()
                else:  # training
                    content = get_evening_training()
                logger.info(f"📋 Использован статичный контент: {current_type}")
            
            await self.bot.send_message(
                chat_id=self.channel_id,
                text=content,
                parse_mode="HTML"
            )
            
            # Увеличиваем счетчик для следующего поста
            self.post_cycle += 1
            
            logger.info(f"✅ Опубликован ежедневный пост (тип: {current_type})")
            
        except Exception as e:
            logger.error(f"❌ Ошибка публикации ежедневного поста: {e}")
            # Резервный вариант
            try:
                current_type = post_types[self.post_cycle % 3]
                if current_type == 'morning':
                    content = get_morning_advice()
                elif current_type == 'recipe':
                    content = get_recipe_post()
                else:
                    content = get_evening_training()
                    
                await self.bot.send_message(
                    chat_id=self.channel_id,
                    text=content,
                    parse_mode="HTML"
                )
                self.post_cycle += 1
                logger.info("✅ Опубликован резервный пост")
            except Exception as backup_e:
                logger.error(f"❌ Ошибка резервной публикации: {backup_e}")
    
    async def stop_scheduler(self):
        """Остановка планировщика"""
        if self.scheduler.running:
            self.scheduler.shutdown()
            self.is_running = False
            logger.info("⏹️ Планировщик автопостов остановлен")
    
    def toggle_content_mode(self):
        """Переключение между динамическим и статичным контентом"""
        self.use_dynamic_content = not self.use_dynamic_content
        mode = "динамический" if self.use_dynamic_content else "статичный"
        logger.info(f"🔄 Переключен режим на {mode} контент")
        return mode
    
    async def test_post(self, post_type: str = "morning"):
        """Тестовая публикация для проверки"""
        try:
            if post_type == "morning":
                if self.use_dynamic_content:
                    content = await content_generator.generate_morning_advice()
                else:
                    content = get_morning_advice()
            elif post_type == "recipe":
                if self.use_dynamic_content:
                    content = await content_generator.generate_recipe_post()
                else:
                    content = get_recipe_post()
            elif post_type == "training":
                if self.use_dynamic_content:
                    content = await content_generator.generate_training_post()
                else:
                    content = get_evening_training()
            else:
                logger.error("Неизвестный тип поста для теста")
                return
                
            await self.bot.send_message(
                chat_id=self.channel_id,
                text=content,
                parse_mode="HTML"
            )
            logger.info(f"✅ Тестовый пост '{post_type}' опубликован")
            
        except Exception as e:
            logger.error(f"❌ Ошибка тестовой публикации: {e}")

# Глобальный экземпляр автопостера
config = load_config()
autoposter = None

def initialize_autoposter(bot: Bot, channel_id: str):
    """Инициализация автопостера"""
    global autoposter
    autoposter = AutoPoster(bot, channel_id)
    return autoposter