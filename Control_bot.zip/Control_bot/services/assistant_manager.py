from typing import Dict, Optional
from services.openai_client import OpenAIClient
from services.assistant_prompts import ASSISTANT_PROMPTS, ACTION_PROMPTS
from config import load_config  # ← ДОБАВИТЬ

class AssistantManager:
    def __init__(self):
        config = load_config()  # ← ДОБАВИТЬ
        self.openai_client = OpenAIClient(config.openai_api_key)  # ← ИЗМЕНИТЬ
        self.user_assistants: Dict[int, str] = {}
        self.user_contexts: Dict[int, list] = {}
    
    async def set_user_assistant(self, user_id: int, assistant_name: str):
        """Устанавливает активного ассистента для пользователя"""
        self.user_assistants[user_id] = assistant_name
        # Инициализируем контекст диалога
        if user_id not in self.user_contexts:
            self.user_contexts[user_id] = []
    
    def get_user_assistant(self, user_id: int) -> Optional[str]:
        """Получает активного ассистента пользователя"""
        return self.user_assistants.get(user_id)
    
# В assistant_manager.py в методе process_message ДОБАВИТЬ:

    async def process_message(
        self, 
        user_id: int, 
        message: str, 
        action_type: str = "free"
    ) -> str:
        """
        Обрабатывает сообщение пользователя
        """
        assistant_name = self.get_user_assistant(user_id)
        
        if not assistant_name:
            return "Сначала выбери ассистента из меню"
        
        # Получаем базовый промпт ассистента
        base_prompt = ASSISTANT_PROMPTS.get(assistant_name, "")
        
        # Получаем промпт для конкретного действия
        action_prompt = ACTION_PROMPTS.get(assistant_name, {}).get(action_type, "")
        
        # Формируем итоговый промпт
        if action_prompt:
            full_prompt = f"{base_prompt}\n\n{action_prompt.format(user_input=message)}"
        else:
            full_prompt = f"{base_prompt}\n\nВопрос: {message}"
        
        # КНОПОЧНЫЕ ОТВЕТЫ - БЕЗ КОНТЕКСТА для разнообразия
        button_actions = [
            "daily_ration", "weekly_ration", "kbju_calculation", 
            "weight_loss", "weight_gain", "basic_training", "beginner_training"
        ]
        
        if action_type in button_actions:
            # Для кнопок - без контекста, всегда новые ответы
            context = []
        else:
            # Для диалогов - с контекстом
            context = self.user_contexts.get(user_id, [])
        
        # Добавляем контекст предыдущих сообщений (если есть)
        if context:
            context_str = "\n".join(context[-5:])  # Последние 5 сообщений
            full_prompt += f"\n\nКонтекст диалога:\n{context_str}"
        
        # Получаем ответ от OpenAI
        response = await self.openai_client.get_completion(full_prompt)
        
        # Сохраняем в контекст ТОЛЬКО для диалогов (не для кнопок)
        if action_type not in button_actions:
            if user_id not in self.user_contexts:
                self.user_contexts[user_id] = []
            
            self.user_contexts[user_id].append(f"Пользователь: {message}")
            if response:
                self.user_contexts[user_id].append(f"Андрей: {response}")
        
        return response or "Извини, что-то пошло не так 😔"
    
    def clear_user_context(self, user_id: int):
        """Очищает контекст диалога пользователя"""
        if user_id in self.user_contexts:
            self.user_contexts[user_id] = []

# Создаем глобальный экземпляр
assistant_manager = AssistantManager()