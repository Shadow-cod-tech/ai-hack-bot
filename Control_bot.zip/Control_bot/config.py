import os
from dotenv import load_dotenv
from dataclasses import dataclass

@dataclass
class Config:
    main_bot_token: str
    chat_bot_token: str
    openai_api_key: str
    admin_id: int

def load_config() -> Config:
    load_dotenv()
    
    main_bot_token = os.getenv('MAIN_BOT_TOKEN')
    chat_bot_token = os.getenv('CHAT_BOT_TOKEN')
    openai_api_key = os.getenv('OPENAI_API_KEY')
    admin_id = int(os.getenv('ADMIN_ID', '0'))
    
    if not main_bot_token:
        raise ValueError("MAIN_BOT_TOKEN не найден в .env файле")
    if not chat_bot_token:
        raise ValueError("CHAT_BOT_TOKEN не найден в .env файле")
    if not openai_api_key:
        raise ValueError("OPENAI_API_KEY не найден в .env файле")
    if not admin_id:
        raise ValueError("ADMIN_ID не найден в .env файле")
    
    return Config(
        main_bot_token=main_bot_token,
        chat_bot_token=chat_bot_token,
        openai_api_key=openai_api_key,
        admin_id=admin_id
    )