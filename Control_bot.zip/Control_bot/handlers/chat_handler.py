# handlers/chat_handler.py - ПОЛНАЯ ВЕРСИЯ С КНОПКОЙ "ОТВЕТИТЬ"

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from config import load_config
from services.assistant_manager import assistant_manager
from services.openai_client import OpenAIClient, convert_markdown_to_html
import logging
import asyncio
import asyncio

router = Router()
config = load_config()
logger = logging.getLogger(__name__)

class ReplyStates(StatesGroup):
    waiting_for_reply = State()

# Хранилище для связи callback с user_id
reply_to_user = {}

@router.message(F.text == "/start")
async def start_command(message: Message):
    """Приветствие в чат-боте"""
    welcome_text = (
        "👋 <b>Привет! Я помощник Андрея</b>\n\n"
        "🤖 Отвечу на простые вопросы сразу\n"
        "👨‍⚕️ Сложные вопросы передам Андрею\n"
        "⏰ Андрей отвечает в течение 24 часов\n\n"
        "🚀 Канал в тг: @kubovskiyandrey\n"
        "🔗 Основной бот: @Contro8bot"
    )
    
    await message.answer(welcome_text, parse_mode="HTML")

async def should_forward_to_admin(user_message: str) -> bool:
    """Определяет, нужно ли пересылать сообщение админу"""
    
    # Ключевые слова для пересылки админу
    admin_keywords = [
        "заказ", "купить", "цена", "стоимость", "оплата", "платно",
        "персональный", "индивидуальный", "личный", "программа",
        "жалоба", "проблема", "не работает", "помогите", "срочно",
        "план питания", "программа тренировок", "расписание",
        "диета", "меню", "рацион", "тренер", "консультация"
    ]
    
    # Если в сообщении есть ключевые слова
    for keyword in admin_keywords:
        if keyword.lower() in user_message.lower():
            return True
    
    # Если сообщение слишком длинное (сложный вопрос)
    if len(user_message) > 200:
        return True
    
    return False

@router.callback_query(F.data.startswith("reply_"))
async def handle_reply_callback(callback: CallbackQuery, state: FSMContext):
    """Обработка нажатия кнопки 'Ответить'"""
    try:
        # Извлекаем user_id из callback_data
        user_id = int(callback.data.split("_")[1])
        
        # Сохраняем user_id для следующего сообщения
        reply_to_user[callback.from_user.id] = user_id
        
        # Устанавливаем состояние ожидания ответа
        await state.set_state(ReplyStates.waiting_for_reply)
        
        await callback.message.answer(
            f"💬 <b>Режим ответа активирован</b>\n\n"
            f"👤 Пользователь: {user_id}\n\n"
            f"Напишите ваш ответ следующим сообщением:",
            parse_mode="HTML"
        )
        
        await callback.answer("✅ Режим ответа включен")
        
    except Exception as e:
        logger.error(f"Ошибка обработки callback: {e}")
        await callback.answer("❌ Ошибка")

@router.message(ReplyStates.waiting_for_reply)
async def handle_admin_reply(message: Message, state: FSMContext):
    """Обработка ответа админа"""
    try:
        # Получаем user_id из хранилища
        user_id = reply_to_user.get(message.from_user.id)
        
        if not user_id:
            await message.answer("❌ Ошибка: пользователь не найден")
            await state.clear()
            return
        
        # Отправляем ответ пользователю
        await message.bot.send_message(
            chat_id=user_id,
            text=f"📩 <b>Ответ от Андрея:</b>\n\n{message.text}",
            parse_mode="HTML"
        )
        
        # Подтверждение админу
        await message.answer(
            f"✅ <b>Ответ отправлен!</b>\n\n"
            f"👤 Пользователю: {user_id}\n"
            f"💬 Сообщение: {message.text[:100]}{'...' if len(message.text) > 100 else ''}",
            parse_mode="HTML"
        )
        
        # Очищаем состояние и хранилище
        await state.clear()
        if message.from_user.id in reply_to_user:
            del reply_to_user[message.from_user.id]
        
    except Exception as e:
        logger.error(f"Ошибка отправки ответа: {e}")
        await message.answer("❌ Ошибка отправки ответа")
        await state.clear()

@router.message()
async def handle_message(message: Message):
    """Обработка сообщений"""
    try:
        # Пропускаем сообщения админа (кроме режима ответа)
        if message.from_user.id == config.admin_id:
            await message.answer("👋 Привет, Андрей! Это ваш чат-бот.")
            return
        
        # Обработка простых приветствий (включая опечатки)
        simple_greetings = [
            "привет", "здравствуйте", "hello", "hi",
            "как дела", "как дела?", "как едла", "как едла?",  # опечатки
            "как поживаете", "как поживаете?",
            "добрый день", "доброе утро", "добрый вечер"
        ]
        
        if message.text.lower() in simple_greetings:
            await message.answer("Привет! Что Вас интересует? Готов поделиться опытом! 😊")
            return
        
        # Обработка очень коротких сообщений (1-2 символа)
        if len(message.text.strip()) <= 2:
            await message.answer("Не совсем понял. Что именно Вас интересует? 🤔")
            return
        
        # Добавляем typing action для скорости восприятия
        await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
        
        # Проверяем, нужно ли пересылать админу
        needs_admin = await should_forward_to_admin(message.text)
        
        # ДОБАВЛЯЕМ: Только сложные расчеты и планы к админу
        calculation_keywords = [
            "кбжу", "расчит", "рассчит", "план", "программа", 
            "персональный", "индивидуальный", "составь"
        ]
        
        message_lower = message.text.lower()
        if any(word in message_lower for word in calculation_keywords):
            needs_admin = True
        
        if needs_admin:
            # Пересылаем админу с кнопкой ответить
            user_info = f"👤 @{message.from_user.username or 'без_username'} ({message.from_user.full_name})"
            user_id = f"🆔 ID: {message.from_user.id}"
            
            reply_keyboard = InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(
                        text="💬 Ответить", 
                        callback_data=f"reply_{message.from_user.id}"
                    )]
                ]
            )
            
            admin_message = f"""
📩 <b>Вопрос для Андрея:</b>

{user_info}
{user_id}

💬 <b>Сообщение:</b>
{message.text}

📅 {message.date.strftime('%d.%m.%Y %H:%M')}
"""
            
            await message.bot.send_message(
                chat_id=config.admin_id,
                text=admin_message,
                reply_markup=reply_keyboard,
                parse_mode="HTML"
            )
            
            # Ответ пользователю
            await message.answer(
                "Спасибо за вопрос! Я передал его Андрею 📩\n"
                "⏰ Он ответит в течение 24 часов\n\n"
                "💡 Для простых вопросов можете попробовать основной бот: @Contro8bot"
            )
            
        else:
            # Простой вопрос - отвечает ИИ с ОТДЕЛЬНЫМ промптом
            from services.openai_client import OpenAIClient
            
            config_data = load_config()
            openai_client = OpenAIClient(config_data.openai_api_key)
            
            # ЧИСТЫЙ промпт без упоминания @Control8AI_bot
            chat_prompt = """
Ты — Андрей, блогер с диабетом более 3 лет. Но тренируешься уже более 15 лет.

ПРАВИЛА ФОРМАТИРОВАНИЯ (ОБЯЗАТЕЛЬНО):
- ВСЕГДА используй HTML теги: <b>жирный</b>, <i>курсив</i>
- НЕ используй markdown (**текст** или *текст*)
- Выделяй жирным КЛЮЧЕВЫЕ СЛОВА и важные моменты
- Обязательно сделай жирными: названия упражнений, важные советы, цифры

СТИЛЬ:
- Говори: "я", "у меня", "мой опыт"
- Обращайся на "Вы" 
- 2-3 предложения максимум
- Используй эмодзи: 😊 😀 🫶 ☀️ 💪 🥗 🏋️‍♂️ 🎯

ПРИМЕР ПРАВИЛЬНОГО ОТВЕТА:
"Рекомендую <b>приседания</b> и <b>отжимания</b> — это основа! Начинай с <b>3 подходов по 10 раз</b>. 💪"

НЕ извиняйся за путаницу! Просто отвечай на вопрос с правильным форматированием.
"""
            
            # Прямой вызов OpenAI БЕЗ системного промпта с концовкой
            response = await asyncio.to_thread(
                openai_client.client.chat.completions.create,
                model="gpt-4o",
                messages=[
                    {
                        "role": "system", 
                        "content": chat_prompt
                    },
                    {
                        "role": "user", 
                        "content": message.text
                    }
                ],
                max_tokens=300,
                temperature=0.8,
                timeout=30
            )
            
            ai_response = response.choices[0].message.content.strip()
            ai_response = convert_markdown_to_html(ai_response)
            
            # Отвечаем пользователю
            await message.answer(ai_response or "Что-то пошло не так 😔", parse_mode="HTML")
            
            # ЛОГИРУЕМ АДМИНУ ДЛЯ КОНТРОЛЯ (с кнопкой ответить)
            reply_keyboard = InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(
                        text="💬 Ответить", 
                        callback_data=f"reply_{message.from_user.id}"
                    )]
                ]
            )
            
            admin_log = f"""
📝 <b>Лог чат-бота (ИИ ответил сам):</b>

👤 @{message.from_user.username or 'без_username'}: {message.text}

🤖 <b>Ответ ИИ:</b>
{ai_response}

📅 {message.date.strftime('%d.%m.%Y %H:%M')}

<i>Если ответ неправильный - нажмите "Ответить"</i>
"""
            
            await message.bot.send_message(
                chat_id=config.admin_id,
                text=admin_log,
                reply_markup=reply_keyboard,
                parse_mode="HTML"
            )
        
    except Exception as e:
        logger.error(f"Ошибка в чат-боте: {e}")
        
        # При ошибке пересылаем админу
        await message.bot.send_message(
            chat_id=config.admin_id,
            text=f"❌ Ошибка в чат-боте от @{message.from_user.username}: {message.text}",
            parse_mode="HTML"
        )
        
        await message.answer(
            "🤖 Произошла техническая ошибка. Ваше сообщение передано Андрею!\n"
            "⏰ Он ответит в течение 24 часов"
        )