from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.main_menu import (
    main_menu, ration_menu, nutrition_menu, 
    training_menu, questions_menu, vip_menu
)
from services.assistant_manager import assistant_manager

router = Router()

class BotStates(StatesGroup):
    # Рацион
    waiting_daily_ration = State()
    waiting_weekly_ration = State()
    
    # Питание
    waiting_kbju = State()
    waiting_weight_loss = State()
    waiting_weight_gain = State()
    
    # Тренировки  
    waiting_basic_training = State()
    waiting_beginner_training = State()
    
    # Вопросы
    waiting_free_question = State()
    waiting_contact_andrey = State()

# === ГЛАВНОЕ МЕНЮ ===
@router.message(F.text == "🍽️ Рацион")
async def ration_menu_handler(message: Message):
    await message.answer(
        "🍽️ <b>Рацион</b>\n\nВыбери, что тебя интересует:",
        reply_markup=ration_menu,
        parse_mode="HTML"
    )

@router.message(F.text == "🥗 Питание")
async def nutrition_menu_handler(message: Message):
    await message.answer(
        "🥗 <b>Питание</b>\n\nВыбери раздел:",
        reply_markup=nutrition_menu,
        parse_mode="HTML"
    )

@router.message(F.text == "🏋️ Тренировки")
async def training_menu_handler(message: Message):
    await message.answer(
        "🏋️ <b>Тренировки</b>\n\nВыбери программу:",
        reply_markup=training_menu,
        parse_mode="HTML"
    )

@router.message(F.text == "❓ Задать вопрос")
async def questions_menu_handler(message: Message):
    await message.answer(
        "❓ <b>Задать вопрос</b>\n\nВыбери способ:",
        reply_markup=questions_menu,
        parse_mode="HTML"
    )

@router.message(F.text == "🛒 Заказать рацион")
async def order_ration_handler(message: Message):
    response = """
👋 <b>Привет!</b>

Вот как мы работаем с индивидуальным рационом:

🍽 <b>Шаг 1:</b> Сначала считаем КБЖУ — подбираем норму под Ваш вес, рост и активность.

🚫 <b>Шаг 2:</b> Уточняем, чего Вы не едите — аллергии, непереносимости, антипатии к брокколи 😉

🚚 <b>Шаг 3:</b> Договариваемся по доставке и оплате — всё просто и прозрачно.

📒 <b>Шаг 4:</b> Мы всё готовим, привозим, ведём дневник питания — Вам остаётся только есть и смотреть, как работает.

💪 Если у Вас есть тренер — можем с ним работать напрямую и подстраиваться под его рекомендации.

💰 <b>Стоимость:</b>
— Рацион на день (1500–2500 ккал) с доставкой по Нагорной части — 1400₽
— Неделя: 7000₽
— Две недели: 14 000₽ (рекомендуем — первые результаты обычно уже появляются)

🤝 По вопросам сотрудничества: @Control8AI_bot
Если остались вопросы — с радостью расскажу подробнее! 😊
"""
    
    await message.answer(response, parse_mode="HTML", reply_markup=main_menu)

@router.message(F.text == "💎 VIP функции")
async def vip_menu_handler(message: Message):
    await message.answer(
        "💎 <b>VIP функции</b>\n\n"
        "🌟 Персональные программы от Андрея:\n\n"
        "Выбери интересующую услугу:",
        reply_markup=vip_menu,
        parse_mode="HTML"
    )
    
@router.message(F.text == "👨‍⚕️ Связь с Андреем")
async def contact_andrey_handler(message: Message):
    from keyboards.main_menu import contact_andrey_inline
    
    await message.answer(
        "👨‍⚕️ <b>Связь с Андреем</b>\n\n"
        "💬 Нажмите кнопку ниже, чтобы написать Андрею напрямую\n\n"
        "⏰ Отвечает на простые вопросы сразу\n"
        "📩 Сложные вопросы передает реальному Андрею\n"
        "🔗 Или используйте меню для быстрых ответов",
        reply_markup=contact_andrey_inline,
        parse_mode="HTML"
    )

@router.message(F.text == "🤖 Свой AI Ассистент")
async def ai_assistant_handler(message: Message):
    await message.answer(
        "🤖 <b>Свой AI Ассистент</b>\n\n"
        "Хочешь создать персонального AI-помощника под твои задачи?\n\n"
        "🎯 Заказать можно здесь: @Niro7_Bot\n\n"
        "💡 Мы создаем умных ботов для любых целей!",
        reply_markup=main_menu,
        parse_mode="HTML"
    )

@router.message(F.text == "🗑 Очистить диалог")
async def clear_dialog_handler(message: Message, state: FSMContext):
    assistant_manager.clear_user_context(message.from_user.id)
    await state.clear()
    await message.answer("Диалог очищен! 🧹", reply_markup=main_menu)

@router.message(F.text == "🔙 Назад")
async def back_handler(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Главное меню 👋", reply_markup=main_menu)

# === РАЦИОН ===
@router.message(F.text == "📅 Рацион на сегодня")
async def daily_ration_handler(message: Message):
    from datetime import datetime
    
    # Определяем сегодняшний день
    today = datetime.now()
    day_of_week = today.weekday()  # 0=понедельник, 6=воскресенье
    week_number = (today.day - 1) // 7 + 1  # номер недели в месяце
    
    # Определяем неделю (1 или 2) - автоматически каждую неделю
    # Инвертируем логику, чтобы сейчас была 2 неделя
    current_week = 2 if week_number % 2 == 1 else 1
    
    # Дни недели
    days = ['понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота', 'воскресенье']
    today_name = days[day_of_week]
    
    # Словарь с готовыми рационами
    weekly_rations = {
        1: {  # Неделя 1
            'понедельник': """
🍽️ <b>Рацион на сегодня - Понедельник (неделя 1)</b>

🌅 <b>Завтрак:</b> Каша овсяная с бананом и ягодой
🌞 <b>Обед:</b> Картофель запеченный + куриная отбивная под шапочкой
🥜 <b>Перекус:</b> Запеканка киви сметана
🌆 <b>Ужин:</b> Макароны под соусом «Болоньезе»
🥗 <b>Салат:</b> Крабовый (айсберг, кукуруза, яйцо, крабовое мясо)

💡 <b>Совет:</b> Не забывай контролировать уровень сахара!
""",
            'вторник': """
🍽️ <b>Рацион на сегодня - Вторник (неделя 1)</b>

🌅 <b>Завтрак:</b> Каша рисовая с бананом и ягодой
🌞 <b>Обед:</b> Гречка по купечески с говядиной
🥜 <b>Перекус:</b> Ассорти из свежих овощей со сметанным соусом
🌆 <b>Ужин:</b> Соба цельнозерновая с курицей
🥗 <b>Салат:</b> «Хрустик» (сельдерей, яблоко, крабовое мясо, яйцо)

💡 <b>Совет:</b> Не забывай контролировать уровень сахара!
""",
            'среда': """
🍽️ <b>Рацион на сегодня - Среда (неделя 1)</b>

🌅 <b>Завтрак:</b> Запеканка творожная с яблоком и грушей
🌞 <b>Обед:</b> Рис мексиканский + пангасиус под овощами
🥜 <b>Перекус:</b> Сендвич с куриным паштетом и маринованым огурцом
🌆 <b>Ужин:</b> Паста курица грибы
🥗 <b>Салат:</b> Овощной со сметаной (огурец, томат, красный лук)

💡 <b>Совет:</b> Не забывай контролировать уровень сахара!
""",
            'четверг': """
🍽️ <b>Рацион на сегодня - Четверг (неделя 1)</b>

🌅 <b>Завтрак:</b> Фруктовый салат (банан, яблоко, киви, мандарин, йогурт)
🌞 <b>Обед:</b> Томатные спагетти и курица по французски
🥜 <b>Перекус:</b> Куриный шашлык
🌆 <b>Ужин:</b> Плов с говядиной
🥗 <b>Салат:</b> «Нежность» (курица, яйцо, сыр, огурец, лук)

💡 <b>Совет:</b> Не забывай контролировать уровень сахара!
""",
            'пятница': """
🍽️ <b>Рацион на сегодня - Пятница (неделя 1)</b>

🌅 <b>Завтрак:</b> Гречка с яйцом в крутую и перечным соусом
🌞 <b>Обед:</b> Булгур и курица в апельсинах терияки
🥜 <b>Перекус:</b> Сендвич (творожный сыр, яйцо, томат)
🌆 <b>Ужин:</b> Картофель тушеный с говядиной
🥗 <b>Салат:</b> Пекинская капуста, лук, огурец, кукуруза

💡 <b>Совет:</b> Не забывай контролировать уровень сахара!
""",
            'суббота': """
🍽️ <b>Рацион на сегодня - Суббота (неделя 1)</b>

🌅 <b>Завтрак:</b> Каша овсяная с фруктами
🌞 <b>Обед:</b> Куриные котлеты с овощным гарниром
🥜 <b>Перекус:</b> Творожная запеканка
🌆 <b>Ужин:</b> Рыба на пару с овощами
🥗 <b>Салат:</b> Свежие овощи с зеленью

💡 <b>Совет:</b> Выходные - время для легких блюд!
""",
            'воскресенье': """
🍽️ <b>Рацион на сегодня - Воскресенье (неделя 1)</b>

🌅 <b>Завтрак:</b> Омлет с овощами
🌞 <b>Обед:</b> Запеченная курица с картофелем
🥜 <b>Перекус:</b> Фруктовый салат
🌆 <b>Ужин:</b> Легкий овощной суп
🥗 <b>Салат:</b> Микс зелени с орехами

💡 <b>Совет:</b> Воскресенье - день для подготовки к новой неделе!
"""
        },
        2: {  # Неделя 2
            'понедельник': """
🍽️ <b>Рацион на сегодня - Понедельник (неделя 2)</b>

🌅 <b>Завтрак:</b> Каша пшеничная на молоке с бананом
🌞 <b>Обед:</b> Пюре картофельное + пангасиус по французски
🥜 <b>Перекус:</b> Блины с творогом и бананом
🌆 <b>Ужин:</b> Гречка по купечески с курицей
🥗 <b>Салат:</b> «Нежность»

💡 <b>Совет:</b> Начинаем вторую неделю с новыми силами!
""",
            'вторник': """
🍽️ <b>Рацион на сегодня - Вторник (неделя 2)</b>

🌅 <b>Завтрак:</b> Каша овсяная на молоке
🌞 <b>Обед:</b> Шпинатные спагетти и куриный рулетик с черносливом
🥜 <b>Перекус:</b> Сэндвич творожный сыр и томат
🌆 <b>Ужин:</b> Соба цельнозерновая с говядиной
🥗 <b>Салат:</b> Хрустик

💡 <b>Совет:</b> Не забывай контролировать уровень сахара!
""",
            'среда': """
🍽️ <b>Рацион на сегодня - Среда (неделя 2)</b>

🌅 <b>Завтрак:</b> Блины + смузи черничный
🌞 <b>Обед:</b> Рис с грибами + бедро куриное в сливочном соусе
🥜 <b>Перекус:</b> Запеканка творожная с манго
🌆 <b>Ужин:</b> Картофель отварной + котлеты куриные
🥗 <b>Салат:</b> Грузинский (томат, огурец, лук красный, петрушка, орехи)

💡 <b>Совет:</b> Середина недели - время для разнообразия!
""",
            'четверг': """
🍽️ <b>Рацион на сегодня - Четверг (неделя 2)</b>

🌅 <b>Завтрак:</b> Шакшука(яйцо,перец,томат,лук), Смузи (Миндальное молоко,банан,вишня,семена льна)
🌞 <b>Обед:</b> Булгур с курицей и зеленью.
🥜 <b>Перекус:</b> Запеканка творожная с цукатами
🌆 <b>Ужин:</b> Паста креветки брокколи 
🥗 <b>Салат:</b> Куриное филе,фасоль,морковь по-корейски чеснок,укроп,сметана

💡 <b>Совет:</b> Белковый день для поддержания мышц!
""",
            'пятница': """
🍽️ <b>Рацион на сегодня - Пятница (неделя 2)</b>

🌅 <b>Завтрак:</b> Каша рисовая на молоке
🌞 <b>Обед:</b> Томатные спагетти + куриное бедро
🥜 <b>Перекус:</b> Фреш ролл с говядиной и горчичным соусом
🌆 <b>Ужин:</b> Булгур + пангасиус под овощами
🥗 <b>Салат:</b> Кукуруза, помидоры, лук зеленый, яйцо

💡 <b>Совет:</b> Пятница - готовимся к выходным!
""",
            'суббота': """
🍽️ <b>Рацион на сегодня - Суббота (неделя 2)</b>

🌅 <b>Завтрак:</b> Творожная запеканка с ягодами
🌞 <b>Обед:</b> Говядина тушеная с овощами
🥜 <b>Перекус:</b> Орехи и сухофрукты
🌆 <b>Ужин:</b> Рыбные котлеты с салатом
🥗 <b>Салат:</b> Свежие овощи с авокадо

💡 <b>Совет:</b> Выходные - время для полезных экспериментов!
""",
            'воскресенье': """
🍽️ <b>Рацион на сегодня - Воскресенье (неделя 2)</b>

🌅 <b>Завтрак:</b> Сырники с медом
🌞 <b>Обед:</b> Куриный суп с овощами
🥜 <b>Перекус:</b> Йогурт с орехами
🌆 <b>Ужин:</b> Запеченные овощи с сыром
🥗 <b>Салат:</b> Листовая зелень с семечками

💡 <b>Совет:</b> Воскресенье - планируем питание на новую неделю!
"""
        }
    }
    
    # Получаем рацион на сегодня
    if today_name in weekly_rations[current_week]:
        response = weekly_rations[current_week][today_name]
    else:
        response = f"🍽️ <b>Рацион на {today_name}</b>\n\nК сожалению, рацион на сегодня пока не готов. Попробуйте завтра!"
    
    await message.answer(response, parse_mode="HTML", reply_markup=ration_menu)

@router.message(F.text == "📋 Рацион на 2 недели")
async def weekly_ration_handler(message: Message):
    response = """
📋 <b>Рацион на 2 недели</b>

<b>🗓️ НЕДЕЛЯ 1</b>

<b>Понедельник</b>
🌅 <b>Завтрак:</b> Каша овсяная с бананом и ягодой
🌞 <b>Обед:</b> Картофель запеченный + куриная отбивная под шапочкой
🥜 <b>Перекус:</b> Запеканка киви сметана
🌆 <b>Ужин:</b> Макароны под соусом «Болоньезе»
🥗 <b>Салат:</b> Крабовый (айсберг, кукуруза, яйцо, крабовое мясо)

<b>Вторник</b>
🌅 <b>Завтрак:</b> Каша рисовая с бананом и ягодой
🌞 <b>Обед:</b> Гречка по купечески с говядиной
🥜 <b>Перекус:</b> Ассорти из свежих овощей со сметанным соусом
🌆 <b>Ужин:</b> Соба цельнозерновая с курицей
🥗 <b>Салат:</b> «Хрустик» (сельдерей, яблоко, крабовое мясо, яйцо)

<b>Среда</b>
🌅 <b>Завтрак:</b> Запеканка творожная с яблоком и грушей
🌞 <b>Обед:</b> Рис мексиканский + пангасиус под овощами
🥜 <b>Перекус:</b> Сендвич с куриным паштетом и маринованым огурцом
🌆 <b>Ужин:</b> Паста курица грибы
🥗 <b>Салат:</b> Овощной со сметаной (огурец, томат, красный лук)

<b>Четверг</b>
🌅 <b>Завтрак:</b> Фруктовый салат (банан, яблоко, киви, мандарин, йогурт)
🌞 <b>Обед:</b> Томатные спагетти и курица по французски
🥜 <b>Перекус:</b> Куриный шашлык
🌆 <b>Ужин:</b> Плов с говядиной
🥗 <b>Салат:</b> «Нежность» (курица, яйцо, сыр, огурец, лук)

<b>Пятница</b>
🌅 <b>Завтрак:</b> Гречка с яйцом в крутую и перечным соусом
🌞 <b>Обед:</b> Булгур и курица в апельсинах терияки
🥜 <b>Перекус:</b> Сендвич (творожный сыр, яйцо, томат)
🌆 <b>Ужин:</b> Картофель тушеный с говядиной
🥗 <b>Салат:</b> Пекинская капуста, лук, огурец, кукуруза

<b>🗓️ НЕДЕЛЯ 2</b>

<b>Понедельник</b>
🌅 <b>Завтрак:</b> Каша пшеничная на молоке с бананом
🌞 <b>Обед:</b> Пюре картофельное + пангасиус по французски
🥜 <b>Перекус:</b> Блины с творогом и бананом
🌆 <b>Ужин:</b> Гречка по купечески с курицей
🥗 <b>Салат:</b> «Нежность»

<b>Вторник</b>
🌅 <b>Завтрак:</b> Каша овсяная на молоке
🌞 <b>Обед:</b> Шпинатные спагетти и куриный рулетик с черносливом
🥜 <b>Перекус:</b> Сэндвич творожный сыр и томат
🌆 <b>Ужин:</b> Соба цельнозерновая с говядиной
🥗 <b>Салат:</b> Хрустик

<b>Среда</b>
🌅 <b>Завтрак:</b> Блины + смузи черничный
🌞 <b>Обед:</b> Рис с грибами + бедро куриное в сливочном соусе
🥜 <b>Перекус:</b> Запеканка творожная с манго
🌆 <b>Ужин:</b> Картофель отварной + котлеты куриные
🥗 <b>Салат:</b> Грузинский (томат, огурец, лук красный, петрушка, орехи)

<b>Четверг</b>
🌅 <b>Завтрак:</b> Омлет с зеленью и сыром + смузи (миндальное молоко, банан, вишня)
🌞 <b>Обед:</b> Картофель запеченный с курицей, сметаной и сыром
🥜 <b>Перекус:</b> Запеканка творожная с цукатами
🌆 <b>Ужин:</b> Паста креветки брокколи
🥗 <b>Салат:</b> Куриное филе, фасоль, морковь по-корейски

<b>Пятница</b>
🌅 <b>Завтрак:</b> Каша рисовая на молоке
🌞 <b>Обед:</b> Томатные спагетти + куриное бедро
🥜 <b>Перекус:</b> Фреш ролл с говядиной и горчичным соусом
🌆 <b>Ужин:</b> Булгур + пангасиус под овощами
🥗 <b>Салат:</b> Кукуруза, помидоры, лук зеленый, яйцо

💡 <b>Совет:</b> Этот рацион сбалансирован с учетом потребностей диабетиков!
"""
    
    await message.answer(response, parse_mode="HTML", reply_markup=ration_menu)

# === ПИТАНИЕ ===
@router.message(F.text == "🧮 Расчет КБЖУ")
async def kbju_handler(message: Message, state: FSMContext):
    await state.set_state(BotStates.waiting_kbju)
    await message.answer(
        "🧮 <b>Расчет КБЖУ</b>\n\n"
        "Напиши свои данные в формате:\n"
        "Пол, возраст, рост, вес, активность\n\n"
        "Например: Мужчина, 25 лет, 180 см, 75 кг, средняя активность",
        parse_mode="HTML"
    )

@router.message(F.text == "📉 Питание для снижения веса")
async def weight_loss_handler(message: Message):
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
    await assistant_manager.set_user_assistant(message.from_user.id, "andrey")
    
    response = await assistant_manager.process_message(
        user_id=message.from_user.id,
        message="питание для снижения веса",
        action_type="weight_loss"
    )
    
    await message.answer(response, parse_mode="HTML", reply_markup=nutrition_menu)

@router.message(F.text == "📈 Питание для набора веса")
async def weight_gain_handler(message: Message):
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
    await assistant_manager.set_user_assistant(message.from_user.id, "andrey")
    
    response = await assistant_manager.process_message(
        user_id=message.from_user.id,
        message="питание для набора веса",
        action_type="weight_gain"
    )
    
    await message.answer(response, parse_mode="HTML", reply_markup=nutrition_menu)

# === ТРЕНИРОВКИ ===
@router.message(F.text == "💪 Базовые тренировки")
async def basic_training_handler(message: Message):
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
    await assistant_manager.set_user_assistant(message.from_user.id, "andrey")
    
    response = await assistant_manager.process_message(
        user_id=message.from_user.id,
        message="базовые тренировки",
        action_type="basic_training"
    )
    
    await message.answer(response, parse_mode="HTML", reply_markup=training_menu)

@router.message(F.text == "🏃 Тренировки для новичков")
async def beginner_training_handler(message: Message):
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
    await assistant_manager.set_user_assistant(message.from_user.id, "andrey")
    
    response = await assistant_manager.process_message(
        user_id=message.from_user.id,
        message="тренировки для новичков",
        action_type="beginner_training"
    )
    
    await message.answer(response, parse_mode="HTML", reply_markup=training_menu)

# === ВОПРОСЫ ===
@router.message(F.text == "💬 Свободный вопрос")
async def free_question_handler(message: Message, state: FSMContext):
    await state.set_state(BotStates.waiting_free_question)
    await message.answer("Спроси что угодно — я постараюсь ответить от лица Андрея 👨‍⚕️")

@router.message(F.text == "👨‍⚕️ Связь с Андреем")
async def contact_andrey_handler(message: Message):
    await message.answer(
        "👨‍⚕️ <b>Связь с Андреем</b>\n\n"
        "💬 Напиши Андрею напрямую: @Control8AI_bot\n\n"
        "⏰ Обычно отвечает в течение 24 часов\n"
        "💡 Для заказа ассистента: @Niro7_Bot",
        reply_markup=questions_menu,
        parse_mode="HTML"
    )

# === VIP ФУНКЦИИ ===
@router.message(F.text == "📊 Индивидуальный расчет рациона")
async def individual_ration_handler(message: Message):
    await message.answer(
        "📊 <b>Индивидуальный расчет рациона</b>\n\n"
        "🌟 Персональный план питания с учетом:\n"
        "• Вашего образа жизни\n"
        "• Целей (похудение/набор массы)\n"
        "• Уровня активности\n"
        "• Пищевых предпочтений\n"
        "• Особенностей здоровья\n\n"
        "💎 <b>Для VIP пользователей</b>\n"
        "🚧 <i>Пока в разработке</i>",
        reply_markup=vip_menu,
        parse_mode="HTML"
    )

@router.message(F.text == "⚖️ Персональный план похудения")
async def personal_weight_loss_handler(message: Message):
    await message.answer(
        "⚖️ <b>Персональный план похудения</b>\n\n"
        "🎯 Индивидуальная программа снижения веса с учетом:\n"
        "• Вашего образа жизни\n"
        "• Пищевых предпочтений\n"
        "• Особенностей здоровья\n\n"
        "💎 <b>Для VIP пользователей</b>\n"
        "🚧 <i>Пока в разработке</i>",
        parse_mode="HTML", 
        reply_markup=vip_menu
    )

@router.message(F.text == "💪 Персональный план набора массы")
async def personal_weight_gain_handler(message: Message):
    await message.answer(
        "💪 <b>Персональный план набора массы</b>\n\n"
        "🏋️ Индивидуальная программа набора мышечной массы:\n"
        "• Расчет калорий и БЖУ\n"
        "• План тренировок\n"
        "• Контроль прогресса\n\n"
        "💎 <b>Для VIP пользователей</b>\n"
        "🚧 <i>Пока в разработке</i>",
        parse_mode="HTML", 
        reply_markup=vip_menu
    )

# === ОБРАБОТЧИКИ СОСТОЯНИЙ ===
@router.message(BotStates.waiting_kbju)
async def handle_kbju_input(message: Message, state: FSMContext):
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
    await assistant_manager.set_user_assistant(message.from_user.id, "andrey")
    
    response = await assistant_manager.process_message(
        user_id=message.from_user.id,
        message=message.text,
        action_type="kbju_calculation"
    )
    
    await message.answer(response, parse_mode="HTML", reply_markup=nutrition_menu)
    await state.clear()

@router.message(BotStates.waiting_free_question)
async def handle_free_question(message: Message, state: FSMContext):
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
    await assistant_manager.set_user_assistant(message.from_user.id, "andrey")
    
    response = await assistant_manager.process_message(
        user_id=message.from_user.id,
        message=message.text,
        action_type="free_question"
    )
    
    await message.answer(response, parse_mode="HTML", reply_markup=questions_menu)
    await state.clear()

# === ОБРАБОТЧИК НЕИЗВЕСТНЫХ СООБЩЕНИЙ ===
@router.message()
async def handle_unknown(message: Message):
    await message.answer(
        "Используй кнопки меню для навигации 😊",
        reply_markup=main_menu
    )