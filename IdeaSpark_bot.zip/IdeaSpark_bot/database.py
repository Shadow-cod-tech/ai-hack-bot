# database.py - SQLite для аналитики (гибридный подход)

import aiosqlite
import asyncio
from datetime import datetime, date
import datetime as dt
from typing import Optional, Dict, List
import json

class AnalyticsDatabase:
    """SQLite база для детальной аналитики и логирования"""
    
    def __init__(self, db_path: str = "data/analytics.db"):
        self.db_path = db_path
        
    async def init_database(self):
        """Инициализация аналитической базы данных"""
        async with aiosqlite.connect(self.db_path) as db:
            # Таблица пользователей с детальной информацией
            await db.execute("""
                CREATE TABLE IF NOT EXISTS users_analytics (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    language_code TEXT,
                    first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
                    last_activity DATETIME DEFAULT CURRENT_TIMESTAMP,
                    total_requests INTEGER DEFAULT 0,
                    total_ideas_generated INTEGER DEFAULT 0,
                    total_packs_created INTEGER DEFAULT 0,
                    total_pitches_created INTEGER DEFAULT 0,
                    vip_requests INTEGER DEFAULT 0
                )
            """)
            
            # Таблица всех запросов для детального анализа
            await db.execute("""
                CREATE TABLE IF NOT EXISTS request_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    request_type TEXT,
                    input_text TEXT,
                    response_length INTEGER,
                    processing_time_ms INTEGER,
                    tokens_used INTEGER,
                    success BOOLEAN,
                    error_message TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users_analytics (user_id)
                )
            """)
            
            # Таблица для бизнес-аналитики
            await db.execute("""
                CREATE TABLE IF NOT EXISTS business_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    metric_name TEXT,
                    metric_value TEXT,
                    user_id INTEGER,
                    additional_data TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Таблица логов ошибок
            await db.execute("""
                CREATE TABLE IF NOT EXISTS error_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    function_name TEXT,
                    error_type TEXT,
                    error_message TEXT,
                    context_data TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Таблица OpenAI использования
            await db.execute("""
                CREATE TABLE IF NOT EXISTS openai_usage (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    model TEXT,
                    prompt_tokens INTEGER,
                    completion_tokens INTEGER,
                    total_tokens INTEGER,
                    estimated_cost REAL,
                    request_type TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            await db.commit()
            print("📊 Аналитическая база данных инициализирована")
    
    async def init_database(self):
        """Инициализация аналитической базы данных"""
        try:
            async with aiosqlite.connect(self.db_path) as db:
                # ... весь код создания таблиц остается как есть ...
                await db.commit()
                print("📊 Аналитическая база данных инициализирована")
        except Exception as e:
            print(f"❌ Ошибка инициализации БД: {e}")
            raise
    
    async def log_user_activity(self, user_id: int, username: str = None, 
                               first_name: str = None, last_name: str = None, 
                               language_code: str = None):
        """Логирует активность пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            # Обновляем или создаем запись пользователя
            await db.execute("""
                INSERT OR IGNORE INTO users_analytics 
                (user_id, username, first_name, last_name, language_code)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, username, first_name, last_name, language_code))
            
            # Обновляем последнюю активность
            await db.execute("""
                UPDATE users_analytics 
                SET last_activity = CURRENT_TIMESTAMP,
                    username = COALESCE(?, username),
                    first_name = COALESCE(?, first_name),
                    last_name = COALESCE(?, last_name)
                WHERE user_id = ?
            """, (username, first_name, last_name, user_id))
            
            await db.commit()
    
    async def log_request(self, user_id: int, request_type: str, input_text: str = "",
                         response_length: int = 0, processing_time_ms: int = 0,
                         tokens_used: int = 0, success: bool = True, 
                         error_message: str = None):
        """Логирует детальную информацию о запросе"""
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO request_history 
                (user_id, request_type, input_text, response_length, 
                 processing_time_ms, tokens_used, success, error_message)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (user_id, request_type, input_text[:500], response_length,
                  processing_time_ms, tokens_used, success, error_message))
            
            # Обновляем счетчики пользователя
            if success:
                if request_type == "idea":
                    await db.execute("""
                        UPDATE users_analytics 
                        SET total_ideas_generated = total_ideas_generated + 1,
                            total_requests = total_requests + 1
                        WHERE user_id = ?
                    """, (user_id,))
                elif request_type == "pack":
                    await db.execute("""
                        UPDATE users_analytics 
                        SET total_packs_created = total_packs_created + 1,
                            total_requests = total_requests + 1
                        WHERE user_id = ?
                    """, (user_id,))
                elif request_type == "pitch":
                    await db.execute("""
                        UPDATE users_analytics 
                        SET total_pitches_created = total_pitches_created + 1,
                            total_requests = total_requests + 1
                        WHERE user_id = ?
                    """, (user_id,))
                elif request_type.startswith("vip_"):
                    await db.execute("""
                        UPDATE users_analytics 
                        SET vip_requests = vip_requests + 1,
                            total_requests = total_requests + 1
                        WHERE user_id = ?
                    """, (user_id,))
            
            await db.commit()
    
    async def log_error(self, user_id: int, function_name: str, 
                       error_type: str, error_message: str, context_data: dict = None):
        """Логирует ошибки для анализа"""
        context_json = json.dumps(context_data) if context_data else None
        
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO error_logs 
                (user_id, function_name, error_type, error_message, context_data)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, function_name, error_type, error_message, context_json))
            await db.commit()
    
    async def log_business_metric(self, metric_name: str, metric_value: str,
                                 user_id: int = None, additional_data: dict = None):
        """Логирует бизнес-метрики"""
        additional_json = json.dumps(additional_data) if additional_data else None
        
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO business_metrics 
                (metric_name, metric_value, user_id, additional_data)
                VALUES (?, ?, ?, ?)
            """, (metric_name, metric_value, user_id, additional_json))
            await db.commit()
    
    async def log_openai_usage(self, user_id: int, model: str, prompt_tokens: int,
                              completion_tokens: int, estimated_cost: float,
                              request_type: str):
        """Логирует использование OpenAI для подсчета расходов"""
        total_tokens = prompt_tokens + completion_tokens
        
        async with aiosqlite.connect(self.db_path) as db:
            await db.execute("""
                INSERT INTO openai_usage 
                (user_id, model, prompt_tokens, completion_tokens, total_tokens, 
                 estimated_cost, request_type)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, model, prompt_tokens, completion_tokens, total_tokens,
                  estimated_cost, request_type))
            await db.commit()
    
    async def get_user_stats(self, user_id: int) -> Optional[Dict]:
        """Получает детальную статистику пользователя"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT * FROM users_analytics WHERE user_id = ?
            """, (user_id,))
            row = await cursor.fetchone()
            
            if not row:
                return None
            
            # Получаем названия колонок
            columns = [description[0] for description in cursor.description]
            return dict(zip(columns, row))
    
    async def get_daily_stats(self, date=None) -> Dict:
        """Получает статистику за день"""
        if not date:
            date = dt.date.today()  
        
        date_str = date.strftime('%Y-%m-%d')
        
        async with aiosqlite.connect(self.db_path) as db:
            # Активные пользователи
            cursor = await db.execute("""
                SELECT COUNT(DISTINCT user_id) FROM request_history 
                WHERE DATE(timestamp) = ?
            """, (date_str,))
            active_users = (await cursor.fetchone())[0]
            
            # Всего запросов
            cursor = await db.execute("""
                SELECT COUNT(*) FROM request_history 
                WHERE DATE(timestamp) = ?
            """, (date_str,))
            total_requests = (await cursor.fetchone())[0]
            
            # По типам запросов
            cursor = await db.execute("""
                SELECT request_type, COUNT(*) FROM request_history 
                WHERE DATE(timestamp) = ?
                GROUP BY request_type
            """, (date_str,))
            requests_by_type = dict(await cursor.fetchall())
            
            # Среднее время обработки
            cursor = await db.execute("""
                SELECT AVG(processing_time_ms) FROM request_history 
                WHERE DATE(timestamp) = ? AND success = 1
            """, (date_str,))
            avg_processing_time = (await cursor.fetchone())[0] or 0
            
            # Ошибки
            cursor = await db.execute("""
                SELECT COUNT(*) FROM error_logs 
                WHERE DATE(timestamp) = ?
            """, (date_str,))
            errors_count = (await cursor.fetchone())[0]
            
            return {
                "date": date_str,
                "active_users": active_users,
                "total_requests": total_requests,
                "requests_by_type": requests_by_type,
                "avg_processing_time_ms": round(avg_processing_time, 2),
                "errors_count": errors_count
            }
    
    async def get_top_users(self, limit: int = 10) -> List[Dict]:
        """Получает топ пользователей по активности"""
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT user_id, username, total_requests, total_ideas_generated,
                       total_packs_created, total_pitches_created, vip_requests,
                       first_seen, last_activity
                FROM users_analytics 
                ORDER BY total_requests DESC 
                LIMIT ?
            """, (limit,))
            
            rows = await cursor.fetchall()
            columns = [description[0] for description in cursor.description]
            
            return [dict(zip(columns, row)) for row in rows]
    
    async def get_openai_costs(self, start_date: date = None, end_date: date = None) -> Dict:
        """Получает статистику расходов на OpenAI"""
        if not start_date:
            start_date = dt.date.today().replace(day=1)  # Начало месяца
        if not end_date:
            end_date = dt.date.today()
        
        async with aiosqlite.connect(self.db_path) as db:
            cursor = await db.execute("""
                SELECT 
                    SUM(total_tokens) as total_tokens,
                    SUM(estimated_cost) as total_cost,
                    COUNT(*) as total_requests,
                    AVG(total_tokens) as avg_tokens_per_request
                FROM openai_usage 
                WHERE DATE(timestamp) BETWEEN ? AND ?
            """, (start_date.isoformat(), end_date.isoformat()))
            
            result = await cursor.fetchone()
            
            return {
                "period": f"{start_date} - {end_date}",
                "total_tokens": result[0] or 0,
                "total_cost": round(result[1] or 0, 4),
                "total_requests": result[2] or 0,
                "avg_tokens_per_request": round(result[3] or 0, 2)
            }

# Создаём глобальный экземпляр
db_service = AnalyticsDatabase()