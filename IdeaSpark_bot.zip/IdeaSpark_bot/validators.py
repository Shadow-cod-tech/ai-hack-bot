# validators.py
from functools import wraps
import re
from typing import Tuple, Optional
import html

class InputValidator:
    """Класс для валидации пользовательских данных"""
    
    # Максимальные длины
    MAX_IDEA_LENGTH = 500
    MIN_IDEA_LENGTH = 3
    
    # Запрещенные паттерны
    SPAM_PATTERNS = [
        r'(.)\1{15,}',  # Только очень длинные повторы
        # r'[^\w\s.,!?а-яА-Я-]',  # Закомментировал
        r'(https?://|www\.)',  # Ссылки
    ]
    
    # Запрещенные слова
    FORBIDDEN_WORDS = [
        'наркотики', 'оружие', 'взрывчатка', 'терроризм',
        'drugs', 'weapons', 'bomb', 'terrorism',
        'порно', 'porn', 'xxx'
    ]
    
    @classmethod
    def validate_idea_input(cls, text: str) -> Tuple[bool, Optional[str]]:
        """
        Валидирует ввод идеи
        Возвращает: (valid, error_message)
        """
        if not text or not text.strip():
            return False, "Пустой ввод не допускается"
        
        # Очищаем от HTML
        clean_text = html.escape(text.strip())
        
        # Проверка длины
        if len(clean_text) < cls.MIN_IDEA_LENGTH:
            return False, f"Слишком короткий текст (минимум {cls.MIN_IDEA_LENGTH} символа)"
        
        if len(clean_text) > cls.MAX_IDEA_LENGTH:
            return False, f"Слишком длинный текст (максимум {cls.MAX_IDEA_LENGTH} символов)"
        
        # Проверка на спам паттерны
        text_lower = clean_text.lower()
        for pattern in cls.SPAM_PATTERNS:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return False, "Обнаружен подозрительный контент"
        
        # Проверка запрещенных слов
        for word in cls.FORBIDDEN_WORDS:
            if word in text_lower:
                return False, "Обнаружен запрещенный контент"
        
        # Проверка на только цифры/символы
        if re.match(r'^[\d\s.,!?-]+$', clean_text):
            return False, "Введите осмысленный текст, а не только цифры и символы"
        
        return True, None
    
    @classmethod
    def sanitize_input(cls, text: str) -> str:
        """Очищает и санитизирует ввод"""
        if not text:
            return ""
        
        # Убираем HTML теги
        clean_text = re.sub(r'<[^>]+>', '', text)
        
        # Экранируем HTML сущности
        clean_text = html.escape(clean_text)
        
        # Убираем лишние пробелы
        clean_text = ' '.join(clean_text.split())
        
        # Ограничиваем длину
        if len(clean_text) > cls.MAX_IDEA_LENGTH:
            clean_text = clean_text[:cls.MAX_IDEA_LENGTH] + "..."
        
        return clean_text
    
    @classmethod
    def is_potential_attack(cls, text: str) -> bool:
        """Проверяет на потенциальные атаки"""
        if not text:
            return False
        
        attack_patterns = [
            r'<script',  # XSS
            r'javascript:',  # XSS
            r'sql.*union',  # SQL injection
            r'drop.*table',  # SQL injection
            r'eval\s*\(',  # Code injection
            r'exec\s*\(',  # Code injection
        ]
        
        text_lower = text.lower()
        for pattern in attack_patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return True
        
        return False

# Декоратор для валидации
def validate_input(func):
    """Декоратор для автоматической валидации ввода"""
    @wraps(func)
    async def wrapper(event, *args, **kwargs):
        # Определяем тип события
        if hasattr(event, 'text') and event.text:
            text = event.text
            if not text.startswith('/'):  # Не команда
                valid, error = InputValidator.validate_idea_input(text)
                if not valid:
                    await event.answer(f"❌ {error}")
                    return
                
                # Проверка на атаки
                if InputValidator.is_potential_attack(text):
                    await event.answer("🚫 Обнаружена подозрительная активность")
                    return
        
        return await func(event, *args, **kwargs)
    
    return wrapper