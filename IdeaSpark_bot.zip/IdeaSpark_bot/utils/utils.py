"""
Вспомогательные функции для бота
"""

import asyncio
from datetime import datetime
from typing import Optional
from aiogram import types
import openai
from config import OPENAI_API_KEY, OPENAI_MODEL

# Статистика использования (можно расширить базой данных)
usage_stats = {
    "total_requests": 0,
    "idea_generations": 0,
    "pack_requests": 0,
    "pitch_requests": 0,
    "vip_requests": 0,
    "users": set()
}

def update_stats(user_id: int, request_type: str = "general"):
    """Обновляет статистику использования"""
    global usage_stats
    
    usage_stats["total_requests"] += 1
    usage_stats["users"].add(user_id)
    
    if request_type == "idea":
        usage_stats["idea_generations"] += 1
    elif request_type == "pack":
        usage_stats["pack_requests"] += 1
    elif request_type == "pitch":
        usage_stats["pitch_requests"] += 1
    elif request_type == "vip":
        usage_stats["vip_requests"] += 1

def get_stats() -> str:
    """Возвращает статистику в красивом формате"""
    stats = usage_stats.copy()
    stats["unique_users"] = len(stats["users"])
    del stats["users"]  # Убираем множество из вывода
    
    return f"""
📊 **Статистика бота:**

👥 Уникальных пользователей: {stats['unique_users']}
📝 Всего запросов: {stats['total_requests']}
💡 Генераций идей: {stats['idea_generations']}
📦 Упаковок: {stats['pack_requests']}
🔥 Питчей: {stats['pitch_requests']}
⭐ VIP запросов: {stats['vip_requests']}

Обновлено: {datetime.now().strftime('%d.%m.%Y %H:%M')}
"""

async def show_typing(message: types.Message, duration: int = 2):
    """Показывает индикатор печати"""
    await message.bot.send_chat_action(
        chat_id=message.chat.id,
        action="typing"
    )
    await asyncio.sleep(duration)

async def safe_ai_request(prompt: str, max_tokens: int = 1000, temperature: float = 0.7) -> str:
    """Безопасный запрос к OpenAI с обработкой ошибок"""
    client = openai.OpenAI(api_key=OPENAI_API_KEY)
    
    try:
        completion = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=max_tokens,
            temperature=temperature
        )
        return completion.choices[0].message.content
        
    except openai.RateLimitError:
        return "⏱ Превышен лимит запросов. Попробуй через минуту."
        
    except openai.AuthenticationError:
        return "🔑 Проблема с API ключом OpenAI. Проверь настройки."
        
    except openai.APIError as e:
        return f"🚫 Ошибка API OpenAI: {str(e)}"
        
    except Exception as e:
        return f"❌ Неожиданная ошибка: {str(e)}"

def format_idea_response(response: str) -> str:
    """Форматирует ответ для лучшей читаемости"""
    # Добавляем отступы и улучшаем форматирование
    formatted = response.replace("**", "<b>").replace("**", "</b>")
    
    # Добавляем эмодзи-разделители
    sections = [
        ("🧠 Гипотеза:", "🧠 <b>Гипотеза:</b>"),
        ("📦 Оффер:", "📦 <b>Оффер:</b>"),
        ("🖼 Структура:", "🖼 <b>Структура лендинга:</b>"),
        ("👉 CTA:", "👉 <b>Call-to-Action:</b>"),
        ("🎯 Почему сработает:", "🎯 <b>Почему сработает:</b>")
    ]
    
    for old, new in sections:
        formatted = formatted.replace(old, new)
    
    return formatted

def validate_user_input(text: str) -> bool:
    """Валидация пользовательского ввода"""
    if not text or len(text.strip()) < 3:
        return False
    
    # Проверяем на спам и бессмысленные сообщения
    spam_patterns = ["test", "тест", "aaaa", "1111", "йцукенг"]
    text_lower = text.lower()
    
    for pattern in spam_patterns:
        if pattern in text_lower and len(text) < 10:
            return False
    
    return True

def get_user_context(user_id: int) -> dict:
    """Получает контекст пользователя (можно расширить базой данных)"""
    return {
        "user_id": user_id,
        "last_request_time": datetime.now(),
        "request_count": usage_stats.get(f"user_{user_id}", 0)
    }

def is_admin(user_id: int) -> bool:
    """Проверяет, является ли пользователь админом"""
    from config import ADMIN_IDS
    return user_id in ADMIN_IDS

def clean_text(text: str) -> str:
    """Очищает текст от лишних символов"""
    # Убираем лишние пробелы и переносы строк
    cleaned = " ".join(text.split())
    
    # Ограничиваем длину
    if len(cleaned) > 500:
        cleaned = cleaned[:500] + "..."
    
    return cleaned

def get_success_message() -> str:
    """Возвращает случайное сообщение успеха"""
    messages = [
        "🚀 Готов взорвать твой мозг? 3...2...1...",
        "🧠 Запускаю нейросети...",
        "💡 Генерирую гениальность...",
        "🔥 Создаю что-то невероятное...",
        "⚡ Обрабатываю твою идею...",
        "🎯 Анализирую возможности...",
        "🌟 Превращаю мысли в золото..."
    ]
    import random
    return random.choice(messages)

def format_error_message(error: str) -> str:
    """Форматирует сообщения об ошибках"""
    return f"""
❌ <b>Упс! Что-то пошло не так</b>

<i>{error}</i>

🔄 <b>Что можно сделать:</b>
• Попробуй ещё раз через несколько секунд
• Проверь, что запрос корректный
• Напиши /help для справки

<i>Если проблема повторяется, сообщи разработчику</i>
"""

def get_random_tip() -> str:
    """Возвращает случайный совет по использованию"""
    tips = [
        "💡 <b>Совет:</b> Чем конкретнее описание проблемы, тем лучше идея!",
        "🎯 <b>Совет:</b> Попробуй VIP режим для глубокого анализа идеи",
        "📈 <b>Совет:</b> Используй упаковку идеи для презентаций инвесторам",
        "🔥 <b>Совет:</b> Создай питч, чтобы проверить убедительность идеи",
        "🧠 <b>Совет:</b> Исследуй разные тематики для поиска новых ниш",
        "⭐ <b>Совет:</b> Сохраняй понравившиеся идеи для дальнейшей проработки"
    ]
    import random
    return random.choice(tips)

async def log_user_action(user_id: int, username: str, action: str, text: str = ""):
    """Логирует действия пользователей"""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log_entry = f"[{timestamp}] User {user_id} (@{username}) - {action}: {text[:100]}"
    
    # Можно добавить запись в файл или базу данных
    print(log_entry)

def estimate_tokens(text: str) -> int:
    """Примерная оценка количества токенов"""
    # Грубая оценка: ~4 символа = 1 токен
    return len(text) // 4

def get_pricing_info() -> str:
    """Информация о ценах и лимитах"""
    return """
💰 <b>Тарифы и лимиты</b>

<b>🆓 Бесплатный режим:</b>
• 10 запросов в день
• Базовая генерация идей
• Упаковка и питчи

<b>⭐ VIP режим:</b>
• Безлимитные запросы
• Глубокий анализ рынка
• Персоны аудитории
• Бизнес-модели
• Go-to-Market стратегии
• Приоритетная поддержка

<b>💎 Корпоративный:</b>
• Персональный ассистент
• Интеграция с системами
• Кастомные функции
• Техподдержка 24/7

<i>Для заказа VIP/Корпоративного пакета напиши разработчику</i>
"""

class RateLimiter:
    """Простой лимитер запросов"""
    
    def __init__(self):
        self.user_requests = {}
        self.daily_limit = 20  # Запросов в день для бесплатных пользователей
        self.vip_limit = 1000  # Для VIP пользователей
    
    def can_make_request(self, user_id: int, is_vip: bool = False) -> tuple[bool, int]:
        """Проверяет, может ли пользователь сделать запрос"""
        today = datetime.now().date()
        user_key = f"{user_id}_{today}"
        
        current_requests = self.user_requests.get(user_key, 0)
        limit = self.vip_limit if is_vip else self.daily_limit
        
        if current_requests >= limit:
            return False, limit - current_requests
        
        return True, limit - current_requests - 1
    
    def register_request(self, user_id: int):
        """Регистрирует новый запрос"""
        today = datetime.now().date()
        user_key = f"{user_id}_{today}"
        
        self.user_requests[user_key] = self.user_requests.get(user_key, 0) + 1

# Глобальный экземпляр лимитера
rate_limiter = RateLimiter()

def check_openai_balance() -> str:
    """Проверяет баланс OpenAI (требует дополнительных API calls)"""
    # Эта функция требует отдельного API для проверки биллинга
    # Пока что возвращаем заглушку
    return "ℹ️ Для проверки баланса OpenAI используй dashboard на platform.openai.com"

def generate_idea_variations(base_idea: str, count: int = 3) -> list:
    """Генерирует вариации базовой идеи"""
    variations = []
    
    prompts = [
        f"Создай вариацию идеи '{base_idea}' для B2B сегмента",
        f"Адаптируй идею '{base_idea}' для мобильного приложения", 
        f"Переосмысли идею '{base_idea}' с использованием ИИ",
        f"Сделай из идеи '{base_idea}' SaaS решение",
        f"Превратить идею '{base_idea}' в маркетплейс"
    ]
    
    import random
    selected_prompts = random.sample(prompts, min(count, len(prompts)))
    
    return selected_prompts

def validate_openai_key(api_key: str) -> bool:
    """Проверяет валидность OpenAI API ключа"""
    if not api_key or not api_key.startswith('sk-'):
        return False
    
    # Базовая проверка формата
    if len(api_key) < 20:
        return False
    
    return True

def get_feature_roadmap() -> str:
    """Показывает планы развития бота"""
    return """
🗺 <b>Roadmap развития</b>

<b>📅 В разработке:</b>
• 🎨 Генерация логотипов для идей
• 📊 Интеграция с реальными данными рынка
• 🤖 Персональные рекомендации на основе истории
• 💬 Чат-боты для каждой сгенерированной идеи

<b>🔮 Планируется:</b>
• 📈 Интеграция с CRM системами
• 🎯 A/B тестирование лендингов
• 💰 Автоматический расчет инвестиций
• 🌍 Мультиязычная поддержка

<b>💡 Предложи свою идею!</b>
Напиши, какую функцию хотел бы видеть в боте.

<i>Лучшие предложения будут реализованы в первую очередь!</i>
"""