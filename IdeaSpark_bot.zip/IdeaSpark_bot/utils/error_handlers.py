# utils/error_handlers.py

import logging
from functools import wraps
from aiogram import types

# Кастомные классы ошибок
class BotError(Exception):
    """Базовый класс ошибок бота"""
    pass

class LimitExceededError(BotError):
    """Превышен лимит запросов"""
    pass

class VIPRequiredError(BotError):
    """Требуется VIP доступ"""
    pass

class OpenAIError(BotError):
    """Ошибка OpenAI API"""
    pass
    
# В utils/error_handlers.py добавить:
def check_limits_with_exceptions(user_id: int, request_type: str):
    """Проверяет лимиты и выбрасывает исключения при превышении"""
    from services.limit_service import limit_service
    
    can_request, error_type = limit_service.can_make_request(user_id, request_type)
    
    if not can_request:
        if error_type == "limit_exceeded":
            raise LimitExceededError("Превышен дневной лимит")
        elif error_type == "vip_required":
            raise VIPRequiredError("Требуется VIP доступ")

class DatabaseError(BotError):
    """Ошибка базы данных"""
    pass

# Декоратор для обработки ошибок (уже существует)
def error_handler(func):
    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except LimitExceededError:
            # Детальная обработка лимитов
            from services.limit_service import limit_service
            event = args[0] if args else None
            user_id = event.from_user.id if hasattr(event, 'from_user') else None
            
            if user_id:
                limit_msg = limit_service.get_limit_message(user_id, "limit_exceeded")
                keyboard = limit_service.get_limit_keyboard("limit_exceeded")
                
                if hasattr(event, 'answer'):
                    await event.answer(limit_msg, reply_markup=keyboard)
                elif hasattr(event, 'message'):
                    await event.message.answer(limit_msg, reply_markup=keyboard)
            
        except VIPRequiredError:
            # Детальная обработка VIP
            from services.limit_service import limit_service
            event = args[0] if args else None
            user_id = event.from_user.id if hasattr(event, 'from_user') else None
            
            if user_id:
                limit_msg = limit_service.get_limit_message(user_id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                
                if hasattr(event, 'answer'):
                    await event.answer(limit_msg, reply_markup=keyboard)
                elif hasattr(event, 'message'):
                    await event.message.answer(limit_msg, reply_markup=keyboard)
            
        except Exception as e:
            logging.error(f"Ошибка в {func.__name__}: {e}")
            
            event = args[0] if args else None
            if hasattr(event, 'answer'):
                await event.answer("❌ Произошла ошибка. Попробуйте позже.")
            elif hasattr(event, 'message'):
                await event.message.answer("❌ Произошла ошибка. Попробуйте позже.")
    return wrapper
    