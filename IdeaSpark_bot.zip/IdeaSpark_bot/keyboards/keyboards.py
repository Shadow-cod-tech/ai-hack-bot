"""
Клавиатуры для Telegram бота
"""

from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from config import CATEGORIES

def get_main_keyboard():
    """Основная клавиатура"""
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="💡 Сгенерировать идею")],
            [KeyboardButton(text="📚 Выбрать тематику")],
            [KeyboardButton(text="📦 Упаковать идею")],
            [KeyboardButton(text="🔥 Питч")],
            [KeyboardButton(text="🔁 Случайная идея")],
            [KeyboardButton(text="🤖 Свой AI-ассистент")],
            [KeyboardButton(text="⭐ VIP режим")]
        ],
        resize_keyboard=True,
        one_time_keyboard=False
    )

def get_category_keyboard():
    """Клавиатура выбора тематики"""
    buttons = []
    for category in CATEGORIES:
        buttons.append([InlineKeyboardButton(text=category, callback_data=f"cat_{category}")])
    
    buttons.append([InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_main")])
    return InlineKeyboardMarkup(inline_keyboard=buttons)

def get_more_keyboard():
    """Клавиатура для дополнительных действий"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🔁 Ещё идею", callback_data="generate_more"),
                InlineKeyboardButton(text="📦 Упаковать", callback_data="pack_this")
            ],
            [
                InlineKeyboardButton(text="🔥 Сделать питч", callback_data="pitch_this"),
                InlineKeyboardButton(text="⭐ VIP анализ", callback_data="vip_analysis")
            ]
        ]
    )

def get_vip_keyboard():
    """Клавиатура VIP функций"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="🧠 Глубокий анализ", callback_data="vip_deep_analysis"),
                InlineKeyboardButton(text="📊 Исследование рынка", callback_data="vip_market_research")
            ],
            [
                InlineKeyboardButton(text="🎯 Персоны аудитории", callback_data="vip_personas"),
                InlineKeyboardButton(text="💰 Бизнес-модель", callback_data="vip_business_model")
            ],
            [
                InlineKeyboardButton(text="🚀 Go-to-Market", callback_data="vip_gtm"),
                InlineKeyboardButton(text="📈 Метрики и KPI", callback_data="vip_metrics")
            ],
            [    
                InlineKeyboardButton(text="⚠️ Анализ рисков", callback_data="vip_risks"),
                InlineKeyboardButton(text="🔄 План развития", callback_data="vip_roadmap")
            ],
            [InlineKeyboardButton(text="💳 Тарифы и покупка", callback_data="show_tariffs")],
            [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_main")]
        ]
    )

def get_help_keyboard():
    """Клавиатура помощи"""
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="📖 Как пользоваться", callback_data="help_usage"),
                InlineKeyboardButton(text="💡 Примеры", callback_data="help_examples")
            ],
            [
                InlineKeyboardButton(text="⭐ Про VIP", callback_data="help_vip"),
                InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_main")
            ]
        ]
    )