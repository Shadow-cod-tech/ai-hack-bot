"""
VIP обработчики для расширенных функций
"""

from aiogram import types, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.keyboards import get_vip_keyboard
from services.ai_service import ai_service
from services.message_service import message_service
from services.limit_service import limit_service

class VIPStates(StatesGroup):
    waiting_for_deep_analysis = State()
    waiting_for_market_research = State()
    waiting_for_personas = State()
    waiting_for_business_model = State()
    waiting_for_gtm = State()
    waiting_for_metrics = State()
    waiting_for_risks = State()
    waiting_for_roadmap = State()    

class VIPHandlers:
    """Класс для VIP обработчиков"""
    
    @staticmethod
    def register_handlers(dp, bot):
        """Регистрирует все VIP обработчики"""
        
        # Коллбеки для VIP функций
        @dp.callback_query(F.data == "vip_deep_analysis")
        async def vip_deep_analysis(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("🧠 <b>Глубокий анализ</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_deep_analysis)
        
        @dp.callback_query(F.data == "vip_market_research") 
        async def vip_market_research(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("📊 <b>Исследование рынка</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_market_research)
        
        @dp.callback_query(F.data == "vip_personas")
        async def vip_personas(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("🎯 <b>Персоны аудитории</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_personas)
        
        @dp.callback_query(F.data == "vip_business_model")
        async def vip_business_model(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("💰 <b>Бизнес-модель</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_business_model)
        
        @dp.callback_query(F.data == "vip_gtm")
        async def vip_gtm(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("🚀 <b>Go-to-Market</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_gtm)
        
        @dp.callback_query(F.data == "vip_metrics")
        async def vip_metrics(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("📈 <b>Метрики и KPI</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_metrics)
            
        @dp.callback_query(F.data == "vip_risks")
        async def vip_risks(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("⚠️ <b>Анализ рисков</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_risks)

        @dp.callback_query(F.data == "vip_roadmap")
        async def vip_roadmap(callback: types.CallbackQuery, state: FSMContext):
            if not limit_service.has_vip_access(callback.from_user.id):
                limit_msg = limit_service.get_limit_message(callback.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await callback.message.answer(limit_msg,reply_markup=keyboard)
                await callback.answer()
                return
            
            await callback.answer()
            await callback.message.answer("🔄 <b>План развития</b>\n\nВведи свою идею:")
            await state.set_state(VIPStates.waiting_for_roadmap)
        
        # Обработчики состояний с регистрацией запросов
        @dp.message(VIPStates.waiting_for_deep_analysis)
        async def process_deep_analysis(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await message.answer(limit_msg,reply_markup=keyboard)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "deep_analysis")
            
            await message_service.show_thinking_animation(message, "🧠 Провожу глубокий анализ...")
            response = await ai_service.generate_vip_response(message.text, "deep_analysis")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())
            await state.clear()
        
        @dp.message(VIPStates.waiting_for_market_research)
        async def process_market_research(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await message.answer(limit_msg,reply_markup=keyboard)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "market_research")
            
            await message_service.show_thinking_animation(message, "📊 Исследую рынок...")
            response = await ai_service.generate_vip_response(message.text, "market_research")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())
            await state.clear()
        
        @dp.message(VIPStates.waiting_for_personas)
        async def process_personas(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await message.answer(limit_msg,reply_markup=keyboard)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "personas")
            
            await message_service.show_thinking_animation(message, "🎯 Создаю персоны...")
            response = await ai_service.generate_vip_response(message.text, "personas")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            keyboard = limit_service.get_limit_keyboard("vip_required")
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())
            await state.clear()
        
        @dp.message(VIPStates.waiting_for_business_model)
        async def process_business_model(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                await message.answer(limit_msg)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "business_model")
            
            await message_service.show_thinking_animation(message, "💰 Разрабатываю бизнес-модель...")
            response = await ai_service.generate_vip_response(message.text, "business_model")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())            
            await state.clear()
        
        @dp.message(VIPStates.waiting_for_gtm)
        async def process_gtm(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                await message.answer(limit_msg)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "gtm")
            
            await message_service.show_thinking_animation(message, "🚀 Строю Go-to-Market...")
            response = await ai_service.generate_vip_response(message.text, "gtm")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())
            await state.clear()
        
        @dp.message(VIPStates.waiting_for_metrics)
        async def process_metrics(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                await message.answer(limit_msg)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "metrics")
            
            await message_service.show_thinking_animation(message, "📈 Определяю метрики...")
            response = await ai_service.generate_vip_response(message.text, "metrics")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())
            await state.clear()
            
        @dp.message(VIPStates.waiting_for_risks)
        async def process_risks(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await message.answer(limit_msg,reply_markup=keyboard)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "risks")
            
            await message_service.show_thinking_animation(message, "⚠️ Анализирую риски...")
            response = await ai_service.generate_vip_response(message.text, "risks")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())
            await state.clear()

        @dp.message(VIPStates.waiting_for_roadmap)
        async def process_roadmap(message: types.Message, state: FSMContext):
            if not limit_service.has_vip_access(message.from_user.id):
                limit_msg = limit_service.get_limit_message(message.from_user.id, "vip_required")
                keyboard = limit_service.get_limit_keyboard("vip_required")
                await message.answer(limit_msg,reply_markup=keyboard)
                await state.clear()
                return
            
            # 🔥 РЕГИСТРИРУЕМ VIP ЗАПРОС
            limit_service.register_request(message.from_user.id, "roadmap")
            
            await message_service.show_thinking_animation(message, "🔄 Создаю план развития...")
            response = await ai_service.generate_vip_response(message.text, "roadmap")
            formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
            await message.answer(formatted_response, reply_markup=get_vip_keyboard())
            await state.clear()

# Создаём экземпляр для экспорта
vip_handlers = VIPHandlers()