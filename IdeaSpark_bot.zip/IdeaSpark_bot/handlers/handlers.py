"""
Дополнительные обработчики для VIP функций и расширенных возможностей
"""

from aiogram import types, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards import get_vip_keyboard, get_main_keyboard
from prompts import get_vip_prompt
import asyncio

class VIPStates(StatesGroup):
    waiting_for_deep_analysis = State()
    waiting_for_market_research = State()
    waiting_for_personas = State()
    waiting_for_business_model = State()
    waiting_for_gtm = State()
    waiting_for_metrics = State()

# Специализированные VIP промпты
VIP_PROMPTS = {
    "deep_analysis": """
Проведи глубокий анализ идеи: {input}

🧠 **ГЛУБОКИЙ АНАЛИЗ:**

**💡 Концепция и инновационность:**
• Уникальность решения (1-10)
• Технологическая сложность
• Барьеры для входа

**🎯 Problem-Solution Fit:**
• Насколько критична проблема
• Качество решения
• Альтернативы на рынке

**📈 Масштабируемость:**
• Потенциал роста
• Сетевые эффекты
• Вирусность

**⚠️ Критические риски:**
• Технологические
• Регуляторные
• Конкурентные

**🔮 Прогноз успеха:** (процент вероятности с обоснованием)

Будь максимально честным и конкретным.
""",
    
    "market_research": """
Исследуй рынок для идеи: {input}

📊 **ИССЛЕДОВАНИЕ РЫНКА:**

**🌍 Размер рынка:**
• TAM (Total Addressable Market)
• SAM (Serviceable Addressable Market) 
• SOM (Serviceable Obtainable Market)

**📈 Тренды и динамика:**
• Рост рынка (% в год)
• Ключевые драйверы
• Сезонность

**🏢 Ключевые игроки:**
• Топ-3 конкурента
• Их слабые стороны
• Наша возможность

**💰 Монетизация:**
• Популярные модели
• Средний чек
• LTV/CAC соотношение

**🎯 Сегментация:**
• Основные сегменты
• Самый перспективный
• Стратегия захвата

Приведи конкретные цифры и источники.
""",
    
    "personas": """
Создай персоны для идеи: {input}

🎯 **ПЕРСОНЫ ЦЕЛЕВОЙ АУДИТОРИИ:**

**👤 Персона #1 (Основная):**
• Имя и возраст
• Профессия и доход
• Боли и потребности
• Где проводит время
• Как принимает решения
• Что мотивирует к покупке

**👥 Персона #2 (Вторичная):**
• [аналогично]

**👔 Персона #3 (B2B, если применимо):**
• [аналогично]

**📱 Поведенческие паттерны:**
• Где ищут решения
• Кому доверяют
• Сколько готовы платить
• Как часто меняют решения

**💬 Голос аудитории:**
• Как говорят о проблеме
• Ключевые фразы
• Эмоциональные триггеры

Сделай персоны живыми и детальными.
""",
    
    "business_model": """
Разработай бизнес-модель для: {input}

💰 **БИЗНЕС-МОДЕЛЬ:**

**💵 Монетизация:**
• Основная модель (подписка/покупка/комиссия)
• Дополнительные источники
• Ценообразование
• Прогноз выручки на 3 года

**📊 Unit-экономика:**
• CAC (Customer Acquisition Cost)
• LTV (Lifetime Value)
• Payback период
• Маржинальность

**💸 Структура расходов:**
• Основные статьи
• Переменные vs фиксированные
• Точка безубыточности

**🚀 Модель роста:**
• Органический рост
• Платное привлечение
• Партнерства
• Вирусные механизмы

**🎯 KPI и метрики:**
• Северная звезда
• Операционные метрики
• Финансовые показатели

**📈 Сценарии развития:**
• Консервативный
• Реалистичный  
• Оптимистичный

Дай конкретные цифры и расчеты.
""",
    
    "gtm": """
Создай Go-to-Market стратегию для: {input}

🚀 **GO-TO-MARKET СТРАТЕГИЯ:**

**🎯 Этап 1: Валидация (0-3 месяца):**
• MVP функции
• Способы тестирования
• Метрики успеха
• Бюджет и ресурсы

**📈 Этап 2: Запуск (3-12 месяцев):**
• Каналы привлечения
• Контент-стратегия
• Партнерства
• PR и медиа

**⚡ Этап 3: Масштабирование (1-2 года):**
• Автоматизация процессов
• Расширение команды
• Новые рынки/сегменты
• Продуктовые линейки

**📢 Каналы привлечения:**
• Топ-3 приоритетных канала
• Бюджет на каждый
• Ожидаемая конверсия
• План тестирования

**🤝 Партнерская программа:**
• Типы партнеров
• Условия сотрудничества
• Взаимная выгода

**📊 Roadmap первых 100 дней:**
• Конкретные действия по неделям
• Ответственные
• Чекпоинты

Сделай план максимально действенным.
""",
    
    "metrics": """
Определи метрики и KPI для: {input}

📈 **МЕТРИКИ И KPI:**

**⭐ Северная звезда:**
• Главная метрика успеха
• Почему именно она
• Как измерять

**🔄 Продуктовые метрики:**
• Активные пользователи (DAU/MAU)
• Retention (Day 1, 7, 30)
• Engagement (время/сессии)
• Feature adoption

**💰 Финансовые метрики:**
• MRR/ARR
• CAC по каналам
• LTV по сегментам
• Churn rate
• ARPU

**📊 Операционные метрики:**
• Скорость роста
• Вирусность (k-factor)
• NPS (лояльность)
• Support tickets

**🎯 Для каждой метрики:**
• Текущее значение (если есть)
• Целевое значение
• Способ измерения
• Ответственный

**📈 Dashboard структура:**
• Ежедневный мониторинг
• Еженедельные отчеты
• Месячные ретроспективы

**⚠️ Red flags (тревожные сигналы):**
• Когда бить тревогу
• План реагирования

Дай конкретные цифры и способы отслеживания.
"""
}

async def generate_vip_response(user_input: str, vip_type: str) -> str:
    """Генерирует VIP ответ для конкретного типа анализа"""
    from main import generate_response
    
    if vip_type in VIP_PROMPTS:
        prompt = VIP_PROMPTS[vip_type].format(input=user_input)
        # Здесь мы используем промпт напрямую вместо функции
        import openai
        from config import OPENAI_API_KEY, OPENAI_MODEL
        
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        
        try:
            completion = client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1500,
                temperature=0.7
            )
            return completion.choices[0].message.content
        except Exception as e:
            return f"❌ Ошибка VIP анализа: {str(e)}"
    
    return await generate_response(user_input, mode="vip")

# Обработчики VIP коллбеков
async def handle_vip_callback(callback: types.CallbackQuery, vip_type: str, state: FSMContext):
    """Универсальный обработчик VIP коллбеков"""
    vip_titles = {
        "deep_analysis": "🧠 Глубокий анализ",
        "market_research": "📊 Исследование рынка", 
        "personas": "🎯 Персоны аудитории",
        "business_model": "💰 Бизнес-модель",
        "gtm": "🚀 Go-to-Market",
        "metrics": "📈 Метрики и KPI"
    }
    
    await callback.answer()
    await callback.message.answer(
        f"{vip_titles.get(vip_type, '⭐ VIP Анализ')}\n\n"
        f"Введи свою идею для детального анализа:"
    )
    
    # Устанавливаем соответствующее состояние
    state_mapping = {
        "deep_analysis": VIPStates.waiting_for_deep_analysis,
        "market_research": VIPStates.waiting_for_market_research,
        "personas": VIPStates.waiting_for_personas,
        "business_model": VIPStates.waiting_for_business_model,
        "gtm": VIPStates.waiting_for_gtm,
        "metrics": VIPStates.waiting_for_metrics
    }
    
    await state.set_state(state_mapping.get(vip_type, VIPStates.waiting_for_deep_analysis))
    # Сохраняем тип анализа в данных состояния
    await state.update_data(vip_type=vip_type)

# Обработчики состояний VIP
async def process_vip_analysis(message: types.Message, state: FSMContext, vip_type: str):
    """Обрабатывает VIP анализ"""
    thinking_messages = {
        "deep_analysis": "🧠 Провожу глубокий анализ идеи...",
        "market_research": "📊 Исследую рынок и конкурентов...", 
        "personas": "🎯 Создаю персоны целевой аудитории...",
        "business_model": "💰 Разрабатываю бизнес-модель...",
        "gtm": "🚀 Строю Go-to-Market стратегию...",
        "metrics": "📈 Определяю ключевые метрики..."
    }
    
    thinking_msg = await message.answer(thinking_messages.get(vip_type, "⭐ Провожу VIP анализ..."))
    await asyncio.sleep(3)
    await thinking_msg.delete()
    
    response = await generate_vip_response(message.text, vip_type)
    await message.answer(response, reply_markup=get_vip_keyboard())
    await state.clear()

# Функции для экспорта в main.py
def register_vip_handlers(dp, bot):
    """Регистрирует VIP обработчики"""
    
    @dp.callback_query(F.data == "vip_deep_analysis")
    async def vip_deep_analysis(callback: types.CallbackQuery, state: FSMContext):
        await handle_vip_callback(callback, "deep_analysis", state)
    
    @dp.callback_query(F.data == "vip_market_research") 
    async def vip_market_research(callback: types.CallbackQuery, state: FSMContext):
        await handle_vip_callback(callback, "market_research", state)
    
    @dp.callback_query(F.data == "vip_personas")
    async def vip_personas(callback: types.CallbackQuery, state: FSMContext):
        await handle_vip_callback(callback, "personas", state)
    
    @dp.callback_query(F.data == "vip_business_model")
    async def vip_business_model(callback: types.CallbackQuery, state: FSMContext):
        await handle_vip_callback(callback, "business_model", state)
    
    @dp.callback_query(F.data == "vip_gtm")
    async def vip_gtm(callback: types.CallbackQuery, state: FSMContext):
        await handle_vip_callback(callback, "gtm", state)
    
    @dp.callback_query(F.data == "vip_metrics")
    async def vip_metrics(callback: types.CallbackQuery, state: FSMContext):
        await handle_vip_callback(callback, "metrics", state)
    
    # Обработчики состояний
    @dp.message(VIPStates.waiting_for_deep_analysis)
    async def process_deep_analysis(message: types.Message, state: FSMContext):
        await process_vip_analysis(message, state, "deep_analysis")
    
    @dp.message(VIPStates.waiting_for_market_research)
    async def process_market_research(message: types.Message, state: FSMContext):
        await process_vip_analysis(message, state, "market_research")
    
    @dp.message(VIPStates.waiting_for_personas)
    async def process_personas(message: types.Message, state: FSMContext):
        await process_vip_analysis(message, state, "personas")
    
    @dp.message(VIPStates.waiting_for_business_model)
    async def process_business_model(message: types.Message, state: FSMContext):
        await process_vip_analysis(message, state, "business_model")
    
    @dp.message(VIPStates.waiting_for_gtm)
    async def process_gtm(message: types.Message, state: FSMContext):
        await process_vip_analysis(message, state, "gtm")
    
    @dp.message(VIPStates.waiting_for_metrics)
    async def process_metrics(message: types.Message, state: FSMContext):
        await process_vip_analysis(message, state, "metrics")