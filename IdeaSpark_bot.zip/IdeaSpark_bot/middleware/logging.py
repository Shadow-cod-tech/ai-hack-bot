from aiogram import BaseMiddleware
from database import db_service

class LoggingMiddleware(BaseMiddleware):
    async def __call__(self, handler, event, data):
        user = event.from_user
        await db_service.log_user_activity(
            user.id, user.username, user.first_name, user.last_name
        )
        return await handler(event, data)