import asyncio
import openai
import re
from config import BOT_TOKEN, OPENAI_API_KEY, OPENAI_MODEL
from utils.error_handlers import error_handler
from utils.error_handlers import error_handler, check_limits_with_exceptions
from logging_config import setup_logging, log_user_action, log_business_metric 
from database import db_service
from aiogram import Bot, Dispatcher, types
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.client.default import DefaultBotProperties
from aiogram import F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from functools import wraps

# Импортируем наши модули
from config import BOT_TOKEN, BUTTON_TEXTS
from utils.error_handlers import error_handler
from validators import InputValidator, validate_input
from keyboards.keyboards import (
    get_main_keyboard, get_category_keyboard, get_more_keyboard, 
    get_vip_keyboard, get_help_keyboard
)
from services.ai_service import ai_service
from services.message_service import message_service
from services.limit_service import limit_service  # 🔥 НОВОЕ!

# MIDDLEWARE
from middleware.logging import LoggingMiddleware

# ВАЖНО: Импортируем VIP обработчики СРАЗУ
from handlers.vip_handlers import vip_handlers

# 🔥 ПРОДАКШЕН ЛОГИРОВАНИЕ
from logging_config import setup_logging, log_user_action, log_business_metric
logger = setup_logging()
logger.info("🚀 Запускаю Idea Spark бота (Production Mode)...")

# Инициализация бота
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))

# Инициализация бота
bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher(storage=MemoryStorage())

# Подключаем middleware для автоматического логирования
dp.message.middleware(LoggingMiddleware())
dp.callback_query.middleware(LoggingMiddleware())

# СРАЗУ регистрируем VIP обработчики (до других обработчиков!)
vip_handlers.register_handlers(dp, bot)

# === ПРОВЕРКА API === 
async def check_apis():
    """Проверка доступности API"""
    try:
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "test"}],
            max_tokens=1
        )
        logger.info("✅ OpenAI API работает")
    except Exception as e:
        logger.error(f"❌ Ошибка OpenAI API: {e}")
        raise

# Состояния
class IdeaStates(StatesGroup):
    waiting_for_idea = State()
    waiting_for_pack = State()
    waiting_for_pitch = State()

# === КОМАНДЫ ===

@dp.message(CommandStart())
@validate_input
@error_handler
async def start_handler(message: types.Message):
    # 📊 ЛОГИРУЕМ ПОЛЬЗОВАТЕЛЯ
    await db_service.log_user_activity(
        message.from_user.id,
        message.from_user.username,
        message.from_user.first_name,
        message.from_user.last_name,
        message.from_user.language_code
    )
    
    # Показываем статус пользователя при старте
    status_msg = limit_service.get_status_message(message.from_user.id)
    welcome_msg = message_service.get_welcome_message()
    
    await message.answer(f"{welcome_msg}\n\n{status_msg}", reply_markup=get_main_keyboard())

@dp.message(Command("help"))
@validate_input
@error_handler
async def help_handler(message: types.Message):
    await message.answer(
        message_service.get_help_message(), 
        reply_markup=get_help_keyboard()
    )

@dp.message(Command("vip"))
@validate_input
@error_handler
async def vip_handler(message: types.Message):
    await message.answer(
        message_service.get_vip_message(), 
        reply_markup=get_vip_keyboard()
    )

@dp.message(Command("status"))  # 🆕 НОВАЯ КОМАНДА
@validate_input
@error_handler
async def status_handler(message: types.Message):
    status_msg = limit_service.get_status_message(message.from_user.id)
    await message.answer(status_msg)
    
@dp.message(Command("stats"))
@error_handler
async def stats_handler(message: types.Message):
    # 🔥 ПРОВЕРКА АДМИНА
    from config import ADMIN_IDS
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("❌ Доступ запрещен")
        return
    
    # Получаем статистику за сегодня
    daily_stats = await db_service.get_daily_stats()
    
    # Топ пользователи
    top_users = await db_service.get_top_users(limit=5)
    
    # Расходы на OpenAI
    openai_costs = await db_service.get_openai_costs()
    
    stats_msg = f"""
📊 <b>Статистика за сегодня:</b>

👥 Активных пользователей: {daily_stats['active_users']}
📝 Всего запросов: {daily_stats['total_requests']}
⏱ Среднее время: {daily_stats['avg_processing_time_ms']}ms
❌ Ошибок: {daily_stats['errors_count']}

<b>По типам запросов:</b>
"""
    
    for req_type, count in daily_stats['requests_by_type'].items():
        stats_msg += f"• {req_type}: {count}\n"
    
    stats_msg += f"""
<b>🏆 Топ-5 пользователей:</b>
"""
    
    for i, user in enumerate(top_users[:5], 1):
        stats_msg += f"{i}. @{user['username'] or 'unknown'}: {user['total_requests']} запросов\n"
    
    await message.answer(stats_msg)

# === ОБРАБОТЧИКИ КНОПОК ===

@dp.message(F.text == "💡 Сгенерировать идею")
@validate_input
@error_handler
async def generate_idea_button(message: types.Message, state: FSMContext):
    # 🔥 ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(message.from_user.id, "idea")
        
    prompts = message_service.get_generation_prompts()
    await message.answer(prompts["idea"])
    await state.set_state(IdeaStates.waiting_for_idea)

@dp.message(F.text == "📦 Упаковать идею")
@validate_input
@error_handler
async def pack_idea_button(message: types.Message, state: FSMContext):
    # 🔥 ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(message.from_user.id, "pack")
    
    prompts = message_service.get_generation_prompts()
    await message.answer(prompts["pack"])
    await state.set_state(IdeaStates.waiting_for_pack)

@dp.message(F.text == "🔥 Питч")
@validate_input
@error_handler
async def pitch_button(message: types.Message, state: FSMContext):
    # 🔥 ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(message.from_user.id, "pitch")
    
    prompts = message_service.get_generation_prompts()
    await message.answer(prompts["pitch"])
    await state.set_state(IdeaStates.waiting_for_pitch)

@dp.message(F.text == "🔁 Случайная идея")
@validate_input
@error_handler
async def random_idea_button(message: types.Message):
    # 🔥 ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(message.from_user.id, "random")   
        
    # 📊 НАЧИНАЕМ ОТСЧЕТ ВРЕМЕНИ
    import time
    start_time = time.time()
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(message.from_user.id, "random")
    
    await message.answer("🎲 Генерирую случайную идею...")
    await message_service.show_thinking_animation(message)
   
    try:
        response = await ai_service.generate_response("", mode="random")
        
        # 📊 ЛОГИРУЕМ УСПЕШНЫЙ ЗАПРОС
        processing_time = int((time.time() - start_time) * 1000)
        await db_service.log_request(
            user_id=message.from_user.id,
            request_type="random",
            input_text="случайная идея",
            response_length=len(response),
            processing_time_ms=processing_time,
            success=True
        )
        
        # Сохраняем случайную идею для кнопок (берем название из ответа)
        if "Название:" in response:
            idea_name = response.split("Название:")[1].split("\n")[0].strip()
            # 🔥 ОЧИЩАЕМ HTML ТЕГИ
            import re
            idea_name = re.sub(r'<[^>]+>', '', idea_name)
            message_service.save_user_idea(message.from_user.id, idea_name, "random")
        else:
            message_service.save_user_idea(message.from_user.id, "случайная идея", "random")
        
        formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
        
    except Exception as e:
        # 📊 ЛОГИРУЕМ ОШИБКУ
        processing_time = int((time.time() - start_time) * 1000)
        await db_service.log_request(
            user_id=message.from_user.id,
            request_type="random",
            input_text="случайная идея",
            processing_time_ms=processing_time,
            success=False,
            error_message=str(e)
        )
        formatted_response = "❌ Произошла ошибка при генерации случайной идеи"
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(message.from_user.id)
    if not (message.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await message.answer(formatted_response, reply_markup=get_more_keyboard())

@dp.message(F.text == "📚 Выбрать тематику")
@validate_input
@error_handler
async def choose_category(message: types.Message):
    prompts = message_service.get_generation_prompts()
    await message.answer(prompts["category"], reply_markup=get_category_keyboard())

@dp.message(F.text == "⭐ VIP режим")
@validate_input
@error_handler
async def vip_mode_button(message: types.Message):
    await vip_handler(message)

@dp.message(F.text == "🤖 Свой AI-ассистент")
@validate_input
@error_handler
async def custom_assistant(message: types.Message):
    await message.answer(message_service.get_custom_assistant_message())

# === ОБРАБОТЧИКИ СОСТОЯНИЙ ===

@dp.message(IdeaStates.waiting_for_idea)
@validate_input
@error_handler
async def process_idea_input(message: types.Message, state: FSMContext):
    # 🔥 ПОВТОРНАЯ ПРОВЕРКА ЛИМИТОВ (на случай если изменились)
    check_limits_with_exceptions(message.from_user.id, "idea")   
    
    if not message_service.validate_user_input(message.text):
        await message.answer("⚠️ Пожалуйста, введи более детальное описание идеи (минимум 3 символа)")
        return
        
    # 📊 НАЧИНАЕМ ОТСЧЕТ ВРЕМЕНИ
    import time
    start_time = time.time()
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(message.from_user.id, "idea")
    
    await message_service.log_user_action(
        message.from_user.id, 
        message.from_user.username or "unknown", 
        "idea_generation", 
        message.text
    )
    
    # Сохраняем исходную идею пользователя
    message_service.save_user_idea(message.from_user.id, message.text, "input")
    
    await message_service.show_thinking_animation(message)
    clean_input = InputValidator.sanitize_input(message.text)
    response = await ai_service.generate_response(message.text, mode="idea")
    
    # 📊 ЛОГИРУЕМ ЗАПРОС В АНАЛИТИКУ
    processing_time = int((time.time() - start_time) * 1000)  # в миллисекундах
    await db_service.log_request(
        user_id=message.from_user.id,
        request_type="idea",
        input_text=message.text,
        response_length=len(response),
        processing_time_ms=processing_time,
        success=True
    )
    
    formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(message.from_user.id)
    if not limit_service.has_vip_access(message.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await message.answer(formatted_response, reply_markup=get_more_keyboard())
    await state.clear()

@dp.message(IdeaStates.waiting_for_pack)
@validate_input 
@error_handler
async def process_pack_input(message: types.Message, state: FSMContext):
    # 🔥 ПОВТОРНАЯ ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(message.from_user.id, "pack")
        
    if not message_service.validate_user_input(message.text):
        await message.answer("⚠️ Пожалуйста, введи более детальное описание идеи (минимум 3 символа)")
        return
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(message.from_user.id, "pack")
    
    await message_service.log_user_action(
        message.from_user.id, 
        message.from_user.username or "unknown", 
        "pack_generation", 
        message.text
    )
    
    await message_service.show_thinking_animation(message)
    clean_input = InputValidator.sanitize_input(message.text)
    response = await ai_service.generate_response(message.text, mode="pack")
    formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(message.from_user.id)
    if not limit_service.has_vip_access(message.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await message.answer(formatted_response, reply_markup=get_more_keyboard())
    await state.clear()

@dp.message(IdeaStates.waiting_for_pitch)
@validate_input
@error_handler
async def process_pitch_input(message: types.Message, state: FSMContext):
    # 🔥 ПОВТОРНАЯ ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(message.from_user.id, "pitch")    
    
    if not message_service.validate_user_input(message.text):
        await message.answer("⚠️ Пожалуйста, введи более детальное описание идеи (минимум 3 символа)")
        return
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(message.from_user.id, "pitch")
    
    await message_service.log_user_action(
        message.from_user.id, 
        message.from_user.username or "unknown", 
        "pitch_generation", 
        message.text
    )
    
    await message_service.show_thinking_animation(message)
    clean_input = InputValidator.sanitize_input(message.text)
    response = await ai_service.generate_response(message.text, mode="pitch")
    formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(message.from_user.id)
    if not limit_service.has_vip_access(message.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await message.answer(formatted_response, reply_markup=get_more_keyboard())
    await state.clear()

# === ОБРАБОТЧИКИ КОЛЛБЕКОВ ===

@dp.callback_query(F.data.startswith("cat_"))
@validate_input
@error_handler
async def category_selected(callback: types.CallbackQuery):
    # 🔥 ПРОВЕРКА ЛИМИТОВ ДЛЯ КАТЕГОРИЙ
    check_limits_with_exceptions(callback.from_user.id, "idea")    
    
    category = callback.data[4:]
    await callback.message.edit_text(f"✅ Выбрана тематика: <b>{category}</b>")
    await callback.answer()
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(callback.from_user.id, "idea")
    
    # Сохраняем выбранную категорию
    message_service.save_user_idea(callback.from_user.id, category, "category")
    
    await message_service.show_thinking_animation(callback.message)
    response = await ai_service.generate_response(category, mode="idea")
    formatted_response = message_service.format_success_message(response, user_id=callback.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(callback.from_user.id)
    if not limit_service.has_vip_access(callback.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await callback.message.answer(formatted_response, reply_markup=get_more_keyboard())

@dp.callback_query(F.data == "generate_more")
@validate_input
@error_handler
async def generate_more(callback: types.CallbackQuery):
    # 🔥 ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(callback.from_user.id, "random")   
   
    await callback.answer()
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(callback.from_user.id, "random")
    
    await message_service.show_thinking_animation(callback.message)
    response = await ai_service.generate_response("", mode="random")
    formatted_response = message_service.format_success_message(response, user_id=callback.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(callback.from_user.id)
    if not limit_service.has_vip_access(callback.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await callback.message.answer(formatted_response, reply_markup=get_more_keyboard())

@dp.callback_query(F.data == "back_to_main")
@validate_input
@error_handler
async def back_to_main(callback: types.CallbackQuery):
    prompts = message_service.get_generation_prompts()
    await callback.message.edit_text(prompts["main_menu"], reply_markup=None)
    await callback.answer()

@dp.callback_query(F.data == "pack_this")
@validate_input
@error_handler
async def pack_this_callback(callback: types.CallbackQuery):
    # 🔥 ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(callback.from_user.id, "pack")    
    
    await callback.answer()
    
    # Получаем последнюю идею пользователя
    last_idea = message_service.get_user_last_idea(callback.from_user.id)
    
    if not last_idea:
        await callback.message.answer(
            "❌ <b>Не найдена последняя идея</b>\n\n"
            "Сначала сгенерируй идею, а потом нажимай 'Упаковать'!"
        )
        return
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(callback.from_user.id, "pack")
    
    await callback.message.answer(f"📦 <b>Упаковываю идею:</b> <i>{last_idea[:50]}...</i>")
    await message_service.show_thinking_animation(callback.message, "📦 Создаю красивую упаковку...")
    
    response = await ai_service.generate_response(last_idea, mode="pack")
    formatted_response = message_service.format_success_message(response, user_id=callback.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(callback.from_user.id)
    if not limit_service.has_vip_access(callback.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await callback.message.answer(formatted_response, reply_markup=get_more_keyboard())

@dp.callback_query(F.data == "pitch_this")
@validate_input
@error_handler
async def pitch_this_callback(callback: types.CallbackQuery):
    # 🔥 ПРОВЕРКА ЛИМИТОВ
    check_limits_with_exceptions(callback.from_user.id, "pitch")   
   
    await callback.answer()
    
    # Получаем последнюю идею пользователя
    last_idea = message_service.get_user_last_idea(callback.from_user.id)
    
    if not last_idea:
        await callback.message.answer(
            "❌ <b>Не найдена последняя идея</b>\n\n"
            "Сначала сгенерируй идею, а потом нажимай 'Сделать питч'!"
        )
        return
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(callback.from_user.id, "pitch")
    
    await callback.message.answer(f"🔥 <b>Создаю питч для идеи:</b> <i>{last_idea[:50]}...</i>")
    await message_service.show_thinking_animation(callback.message, "🔥 Готовлю убедительный питч...")
    
    response = await ai_service.generate_response(last_idea, mode="pitch")
    formatted_response = message_service.format_success_message(response, user_id=callback.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(callback.from_user.id)
    if not limit_service.has_vip_access(callback.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await callback.message.answer(formatted_response, reply_markup=get_more_keyboard())

@dp.callback_query(F.data == "vip_analysis")
@validate_input
@error_handler
async def vip_analysis_callback(callback: types.CallbackQuery):
    await callback.message.answer(
        message_service.get_vip_message(), 
        reply_markup=get_vip_keyboard()
    )
    await callback.answer()

# Обработчики справки
@dp.callback_query(F.data == "help_usage")
@validate_input
@error_handler
async def help_usage(callback: types.CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        "📖 <b>Как пользоваться:</b>\n\n"
        "1. Выбери режим работы\n"
        "2. Введи свою идею или тему\n"
        "3. Получи готовый результат\n"
        "4. Используй дополнительные функции"
    )

@dp.callback_query(F.data == "help_examples")
@validate_input
@error_handler
async def help_examples(callback: types.CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        "💡 <b>Примеры запросов:</b>\n\n"
        "• 'AI для изучения языков'\n"
        "• 'Сервис доставки здоровой еды'\n"
        "• 'Платформа для удаленной работы'\n"
        "• 'Экологичная упаковка для еды'\n"
        "• 'Автоматизация для малого бизнеса'"
    )

@dp.callback_query(F.data == "help_vip")
@validate_input
@error_handler
async def help_vip(callback: types.CallbackQuery):
    await callback.answer()
    await callback.message.answer(
        "⭐ <b>Про VIP режим:</b>\n\n"
        "VIP дает доступ к экспертному анализу:\n"
        "• Глубокое исследование рынка\n"
        "• Детальные персоны клиентов\n"
        "• Готовые бизнес-модели\n"
        "• Стратегии выхода на рынок\n"
        "• Метрики для отслеживания успеха"
    )
    
@dp.callback_query(F.data == "show_tariffs")
@validate_input
@error_handler
async def show_tariffs_callback(callback: types.CallbackQuery):
    await callback.answer()
    # Логируем действие
    await db_service.log_user_activity(
        callback.from_user.id,
        callback.from_user.username,
        callback.from_user.first_name,
        callback.from_user.last_name
    )
    # Проверяем, есть ли VIP-доступ
    if limit_service.has_vip_access(callback.from_user.id):
        await callback.message.answer(
            "🎉 У тебя есть VIP-доступ! Выбери функцию:",
            reply_markup=get_vip_keyboard()  # Возвращаем VIP-функции
        )
    else:
        # Показываем тарифы и предложение купить
        tariff_msg = limit_service.get_tariffs_message() + "\n\n💳 Нажми, чтобы купить VIP:"
        await callback.message.answer(
            tariff_msg,
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="💎 Купить VIP Месяц - 399₽", callback_data="buy_vip_month")],
                    [InlineKeyboardButton(text="🔥 Купить VIP Год - 3990₽", callback_data="buy_vip_year")],
                    [InlineKeyboardButton(text="📦 Пакет 50 - 99₽", callback_data="buy_pack_50")],
                    [InlineKeyboardButton(text="📦 Пакет 200 - 299₽", callback_data="buy_pack_200")],
                    [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_main")]
                ]
            )
        )
        
@dp.callback_query(F.data.in_(["buy_vip_month", "buy_vip_year", "buy_pack_50", "buy_pack_200"]))
@validate_input
@error_handler
async def buy_tariff_callback(callback: types.CallbackQuery):
    await callback.answer()
    tariff = callback.data
    
    # Простое сообщение без логирования покупки
    await callback.message.answer(
        f"💳 <b>Покупка тарифа</b>\n\n"
        f"Выбранный тариф: {tariff}\n\n"
        f"🚧 Интеграция с платежной системой в разработке\n\n"
        f"По всем вопросам пишите - @Niro7_Bot",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="🔙 Назад", callback_data="back_to_main")]
            ]
        )
    )      

# === ОБЩИЙ ОБРАБОТЧИК (ДОЛЖЕН БЫТЬ ПОСЛЕДНИМ!) ===

@dp.message()
@validate_input
@error_handler
async def handle_text(message: types.Message, state: FSMContext):
    user_input = message.text.strip()
    
    # Пропускаем тексты кнопок
    if user_input in BUTTON_TEXTS:
        return
    
    # ВАЖНО: Проверяем текущее состояние - если VIP, то не обрабатываем
    current_state = await state.get_state()
    if current_state and current_state.startswith("VIPStates:"):
        return
    
    # 🔥 ПРОВЕРКА ЛИМИТОВ ДЛЯ ПРЯМОГО ВВОДА
    can_request, error_type = limit_service.can_make_request(message.from_user.id, "idea")
    
    if not can_request:
        limit_msg = limit_service.get_limit_message(message.from_user.id, error_type)
        await message.answer(limit_msg)
        return
    
    # Валидируем ввод
    if not message_service.validate_user_input(user_input):
        await message.answer("⚠️ Пожалуйста, введи более детальное описание (минимум 3 символа)")
        return
    
    # 🔥 РЕГИСТРИРУЕМ ЗАПРОС
    limit_service.register_request(message.from_user.id, "idea")
    
    # Логируем действие
    await message_service.log_user_action(
        message.from_user.id, 
        message.from_user.username or "unknown", 
        "direct_input", 
        user_input
    )
    
    # Сохраняем идею пользователя
    message_service.save_user_idea(message.from_user.id, user_input, "direct")
    
    # Обрабатываем как обычную генерацию идеи
    await message_service.show_thinking_animation(message)
    clean_input = InputValidator.sanitize_input(user_input)
    response = await ai_service.generate_response(user_input, mode="idea")
    formatted_response = message_service.format_success_message(response, user_id=message.from_user.id)
    
    # 🔥 ПОКАЗЫВАЕМ ОСТАВШИЕСЯ ЗАПРОСЫ
    requests_left = limit_service.get_requests_left(message.from_user.id)
    if not limit_service.has_vip_access(message.from_user.id) and requests_left <= 3:
        formatted_response += f"\n\n💡 Осталось запросов: {requests_left}"
    
    await message.answer(formatted_response, reply_markup=get_more_keyboard())

# === ЗАПУСК ===

async def main():
    """Запуск бота"""
    try:
        logger.info("🚀 Запускаю Idea Spark бота (Production Mode)...")
        
        # 🔥 ИНИЦИАЛИЗАЦИЯ АНАЛИТИЧЕСКОЙ БД
        await db_service.init_database()
        
        print("🚀 Запускаю Idea Spark бота...")
        print("✅ Бот готов к работе!")
        await dp.start_polling(bot)
        
    except Exception as e:
        print(f"❌ Ошибка запуска: {e}")
        
if __name__ == "__main__":
    asyncio.run(main())
    
async def main():
    try:
        logger.info("🚀 Запускаю Idea Spark бота...")
        
        # ПРОВЕРКИ
        if not BOT_TOKEN:
            raise ValueError("BOT_TOKEN не установлен!")
        if not OPENAI_API_KEY:
            raise ValueError("OPENAI_API_KEY не установлен!")
        
        # ПРОВЕРКА API
        await check_apis()  # ← ДОБАВИТЬ ЗДЕСЬ
        
        # ИНИЦИАЛИЗАЦИЯ
        await db_service.init_database()
        
        print("✅ Бот готов к работе!")
        await dp.start_polling(bot)
        
    except Exception as e:
        logger.error(f"❌ Ошибка запуска: {e}")
        raise
        
async def check_apis():
    """Проверка доступности API"""
    try:
        client = openai.OpenAI(api_key=OPENAI_API_KEY)
        response = client.chat.completions.create(
            model=OPENAI_MODEL,  # ← ЗАМЕНИТЬ НА ЭТО (используется из config.py)
            messages=[{"role": "user", "content": "test"}],
            max_tokens=1
        )
        logger.info("✅ OpenAI API работает")
    except Exception as e:
        logger.error(f"❌ Ошибка OpenAI API: {e}")
        raise