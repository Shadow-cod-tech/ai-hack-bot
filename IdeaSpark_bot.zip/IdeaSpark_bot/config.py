import os
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()

# Токены и ключи
BOT_TOKEN = os.getenv("BOT_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Проверка обязательных переменных
if not BOT_TOKEN:
    raise ValueError("BOT_TOKEN не найден в переменных окружения")
if not OPENAI_API_KEY:
    raise ValueError("OPENAI_API_KEY не найден в переменных окружения")

# Настройки бота
PARSE_MODE = "HTML"
OPENAI_MODEL = "gpt-4o"

# Список админов (опционально)
ADMIN_IDS = [
    638453616 # Добавь свой user_id сюда, если нужно
]

# 💰 VIP ПОЛЬЗОВАТЕЛИ (подписчики)
VIP_USERS = [
    # Твой ID
    # Сюда добавляем ID с активными подписками
]

# 💎 ПОЛЬЗОВАТЕЛИ С ПАКЕТАМИ (глобальная переменная)
PACK_USERS = {
    638453616: 50,  # Для тестирования - 10 VIP запросов
    # Можно добавлять других
}

# 📊 ЛИМИТЫ
DAILY_LIMIT_FREE = 15     # Базовых запросов в день для бесплатных
DAILY_LIMIT_VIP = 1000     # Для VIP подписчиков (практически безлимит)

# 💰 ТАРИФНЫЕ ПЛАНЫ
VIP_MONTHLY = 399    # руб/месяц
VIP_YEARLY = 3990    # руб/год (скидка 17%)

# 💎 ПАКЕТЫ VIP ЗАПРОСОВ
VIP_PACK_50 = 99     # 50 запросов
VIP_PACK_200 = 299   # 200 запросов
VIP_PACK_500 = 599   # 500 запросов

# 🎯 БАЗОВЫЕ ФУНКЦИИ (с лимитами)
BASE_FUNCTIONS = [
    "idea",      # Генерация идей
    "pack",      # Упаковка
    "pitch",     # Питч  
    "random"     # Случайные идеи
]

# ⭐ VIP ФУНКЦИИ (требуют VIP статус или пакеты)
VIP_FUNCTIONS = [
    "deep_analysis",     # Глубокий анализ
    "market_research",   # Исследование рынка
    "personas",          # Персоны аудитории
    "business_model",    # Бизнес-модель
    "gtm",              # Go-to-Market
    "metrics"           # Метрики и KPI
]

# 🛒 ОПИСАНИЯ ТАРИФОВ
TARIFF_DESCRIPTIONS = {
    "monthly": {
        "name": "VIP Месяц",
        "price": VIP_MONTHLY,
        "description": "• Безлимитные запросы\n• Все VIP функции\n• Приоритетная поддержка",
        "duration": "30 дней"
    },
    "yearly": {
        "name": "VIP Год", 
        "price": VIP_YEARLY,
        "description": "• Безлимитные запросы\n• Все VIP функции\n• Приоритетная поддержка\n• 🔥 Скидка 17%!",
        "duration": "365 дней",
        "savings": VIP_MONTHLY * 12 - VIP_YEARLY
    },
    "pack_50": {
        "name": "Пакет 50",
        "price": VIP_PACK_50,
        "description": "• 50 VIP запросов\n• Все VIP функции\n• Без ограничений по времени",
        "requests": 50
    },
    "pack_200": {
        "name": "Пакет 200",
        "price": VIP_PACK_200, 
        "description": "• 200 VIP запросов\n• Все VIP функции\n• Без ограничений по времени\n• 💰 Выгоднее на 40%!",
        "requests": 200
    },
    "pack_500": {
        "name": "Пакет 500",
        "price": VIP_PACK_500,
        "description": "• 500 VIP запросов\n• Все VIP функции\n• Без ограничений по времени\n• 🔥 Выгоднее на 60%!",
        "requests": 500
    }
}

# Тематики для генерации
CATEGORIES = [
    "💼 Стартапы", 
    "🤖 ИИ", 
    "🎨 Креатив", 
    "📱 Техно", 
    "🧘 Здоровье", 
    "🌍 Экология"
]

# Тексты кнопок
BUTTON_TEXTS = [
    "💡 Сгенерировать идею",
    "📚 Выбрать тематику",
    "📦 Упаковать идею",
    "🔥 Питч",
    "🔁 Случайная идея",
    "🤖 Свой AI-ассистент",
    "⭐ VIP режим"
]