# logging_config.py

import logging
import os
from datetime import datetime

def setup_logging():
    """Настройка продакшен логирования для бота"""
    
    # Создаем папку для логов
    logs_dir = "logs"
    if not os.path.exists(logs_dir):
        os.makedirs(logs_dir)
    
    # Настройка форматирования
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s'
    )
    
    # Основной логгер
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    # Очищаем существующие хендлеры
    logger.handlers.clear()
    
    today = datetime.now().strftime('%Y-%m-%d')
    
    # 1. Основной файл логов (INFO и выше)
    file_handler = logging.FileHandler(
        f'{logs_dir}/bot_{today}.log',
        encoding='utf-8'
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(logging.INFO)
    
    # 2. Файл ошибок (ERROR и выше)
    error_handler = logging.FileHandler(
        f'{logs_dir}/errors_{today}.log',
        encoding='utf-8'
    )
    error_handler.setFormatter(formatter)
    error_handler.setLevel(logging.ERROR)
    
    # 3. Консольный вывод
    console_handler = logging.StreamHandler()
    console_formatter = logging.Formatter(
        '%(asctime)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(logging.INFO)
    
    # 4. Бизнес-аналитика (отдельный файл)
    analytics_handler = logging.FileHandler(
        f'{logs_dir}/analytics_{today}.log',
        encoding='utf-8'
    )
    analytics_formatter = logging.Formatter(
        '%(asctime)s - %(message)s'
    )
    analytics_handler.setFormatter(analytics_formatter)
    analytics_handler.setLevel(logging.INFO)
    
    # Добавляем хендлеры
    logger.addHandler(file_handler)
    logger.addHandler(error_handler)
    logger.addHandler(console_handler)
    
    # Создаем отдельный логгер для аналитики
    analytics_logger = logging.getLogger('analytics')
    analytics_logger.setLevel(logging.INFO)
    analytics_logger.addHandler(analytics_handler)
    analytics_logger.propagate = False  # Не передавать в основной логгер
    
    return logger

def log_user_action(user_id: int, action: str, details: str = ""):
    """Логирует действия пользователей для аналитики"""
    analytics_logger = logging.getLogger('analytics')
    analytics_logger.info(f"USER_ACTION|{user_id}|{action}|{details}")

def log_business_metric(metric: str, value: any, user_id: int = None):
    """Логирует бизнес-метрики"""
    analytics_logger = logging.getLogger('analytics')
    user_part = f"|{user_id}" if user_id else ""
    analytics_logger.info(f"METRIC|{metric}|{value}{user_part}")

def log_error_with_context(error: Exception, context: dict):
    """Логирует ошибки с контекстом для отладки"""
    logger = logging.getLogger()
    context_str = "|".join([f"{k}:{v}" for k, v in context.items()])
    logger.error(f"ERROR_CONTEXT|{type(error).__name__}|{str(error)}|{context_str}")

# Функции для продакшен мониторинга
def log_performance(function_name: str, duration: float, user_id: int = None):
    """Логирует производительность функций"""
    analytics_logger = logging.getLogger('analytics')
    user_part = f"|{user_id}" if user_id else ""
    analytics_logger.info(f"PERFORMANCE|{function_name}|{duration:.3f}s{user_part}")

def log_openai_usage(tokens_used: int, cost: float, model: str, user_id: int):
    """Логирует использование OpenAI для подсчета расходов"""
    analytics_logger = logging.getLogger('analytics')
    analytics_logger.info(f"OPENAI|{user_id}|{model}|{tokens_used}|{cost:.4f}")

def cleanup_old_logs(days_to_keep: int = 30):
    """Очищает старые логи"""
    import glob
    from datetime import timedelta
    
    cutoff_date = datetime.now() - timedelta(days=days_to_keep)
    logs_pattern = "logs/*.log"
    
    for log_file in glob.glob(logs_pattern):
        try:
            file_time = datetime.fromtimestamp(os.path.getmtime(log_file))
            if file_time < cutoff_date:
                os.remove(log_file)
                print(f"Удален старый лог: {log_file}")
        except Exception as e:
            print(f"Ошибка при удалении лога {log_file}: {e}")