"""
Сервис для сохранения и загрузки данных пользователей
"""

import json
import os
from datetime import datetime
from typing import Dict, Any

class DataService:
    """Класс для работы с файловым хранилищем данных"""
    
    DATA_DIR = "data"
    DATA_FILE = "user_data.json"
    
    def __init__(self):
        self.data_path = os.path.join(self.DATA_DIR, self.DATA_FILE)
        self._ensure_data_dir()
    
    def _ensure_data_dir(self) -> None:
        """Создает папку data если её нет"""
        if not os.path.exists(self.DATA_DIR):
            os.makedirs(self.DATA_DIR)
            print(f"📁 Создана папка: {self.DATA_DIR}")
    
    def load_data(self) -> Dict[str, Any]:
        """Загружает данные из файла"""
        try:
            if os.path.exists(self.data_path):
                with open(self.data_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    print(f"📂 Загружены данные из {self.data_path}")
                    return data
            else:
                print(f"📄 Файл {self.data_path} не найден, создаю новый")
                return self._get_default_data()
                
        except Exception as e:
            print(f"❌ Ошибка загрузки данных: {e}")
            return self._get_default_data()
    
    def save_data(self, data: Dict[str, Any]) -> bool:
        """Сохраняет данные в файл"""
        try:
            # Добавляем метку времени
            data["last_updated"] = datetime.now().isoformat()
            
            with open(self.data_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            return True
            
        except Exception as e:
            print(f"❌ Ошибка сохранения данных: {e}")
            return False
    
    def _get_default_data(self) -> Dict[str, Any]:
        """Возвращает структуру данных по умолчанию"""
        return {
            "user_requests": {},
            "pack_users": {},
            "created_at": datetime.now().isoformat(),
            "last_updated": datetime.now().isoformat()
        }
    
    def backup_data(self) -> bool:
        """Создает резервную копию данных"""
        try:
            if not os.path.exists(self.data_path):
                return True
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"user_data_backup_{timestamp}.json"
            backup_path = os.path.join(self.DATA_DIR, backup_name)
            
            with open(self.data_path, 'r', encoding='utf-8') as source:
                with open(backup_path, 'w', encoding='utf-8') as backup:
                    backup.write(source.read())
            
            print(f"💾 Создан бэкап: {backup_path}")
            return True
            
        except Exception as e:
            print(f"❌ Ошибка создания бэкапа: {e}")
            return False
    
    def get_data_stats(self) -> str:
        """Возвращает статистику данных"""
        try:
            data = self.load_data()
            
            total_users = len(data.get("user_requests", {}))
            pack_users_count = len(data.get("pack_users", {}))
            total_pack_requests = sum(data.get("pack_users", {}).values())
            
            return f"""
📊 <b>Статистика данных:</b>

👥 Пользователей с активностью: {total_users}
💎 Пользователей с пакетами: {pack_users_count}
🎯 Всего VIP запросов в пакетах: {total_pack_requests}

📅 Последнее обновление: {data.get('last_updated', 'неизвестно')}
📁 Размер файла: {self._get_file_size()} KB
"""
        except Exception as e:
            return f"❌ Ошибка получения статистики: {e}"
    
    def _get_file_size(self) -> float:
        """Возвращает размер файла данных в KB"""
        try:
            if os.path.exists(self.data_path):
                size_bytes = os.path.getsize(self.data_path)
                return round(size_bytes / 1024, 2)
            return 0.0
        except:
            return 0.0
    
    def cleanup_old_data(self, days_to_keep: int = 30) -> int:
        """Очищает старые данные (старше указанного количества дней)"""
        try:
            from datetime import date, timedelta
            
            data = self.load_data()
            user_requests = data.get("user_requests", {})
            
            cutoff_date = date.today() - timedelta(days=days_to_keep)
            cutoff_str = cutoff_date.isoformat()
            
            cleaned_count = 0
            for user_id in list(user_requests.keys()):
                user_data = user_requests[user_id]
                old_dates = [d for d in user_data.keys() if d < cutoff_str]
                
                for old_date in old_dates:
                    del user_requests[user_id][old_date]
                    cleaned_count += 1
                
                # Удаляем пользователей без данных
                if not user_requests[user_id]:
                    del user_requests[user_id]
            
            if cleaned_count > 0:
                data["user_requests"] = user_requests
                self.save_data(data)
                print(f"🧹 Очищено {cleaned_count} старых записей")
            
            return cleaned_count
            
        except Exception as e:
            print(f"❌ Ошибка очистки данных: {e}")
            return 0

# Создаём глобальный экземпляр сервиса
data_service = DataService()