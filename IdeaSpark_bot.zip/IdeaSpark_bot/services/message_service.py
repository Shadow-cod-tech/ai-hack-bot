"""
Сервис для форматирования и отправки сообщений
"""

import asyncio
import random
from aiogram import types
from datetime import datetime

# Глобальный кэш для хранения последних идей пользователей
user_ideas_cache = {}

class MessageService:
    """Класс для работы с сообщениями"""
    
    @staticmethod
    def save_user_idea(user_id: int, idea_text: str, idea_type: str = "idea") -> None:
        """Сохраняет последнюю идею пользователя"""
        user_ideas_cache[user_id] = {
            "text": idea_text,
            "type": idea_type,
            "timestamp": datetime.now()
        }
    
    @staticmethod
    def get_user_last_idea(user_id: int) -> str:
        """Получает последнюю идею пользователя"""
        if user_id in user_ideas_cache:
            return user_ideas_cache[user_id]["text"]
        return None
    
    @staticmethod
    def clear_user_cache(user_id: int) -> None:
        """Очищает кэш идей пользователя"""
        if user_id in user_ideas_cache:
            del user_ideas_cache[user_id]
    
    @staticmethod
    async def show_thinking_animation(message: types.Message, text: str = None) -> None:
        """Показывает анимацию обдумывания"""
        if text is None:
            text = MessageService.get_random_thinking_message()
        
        thinking_msg = await message.answer(text)
        await asyncio.sleep(2)
        await thinking_msg.delete()
    
    @staticmethod
    def get_random_thinking_message() -> str:
        """Возвращает случайное сообщение для анимации думания"""
        messages = [
            "🚀 Готов взорвать твой мозг? 3...2...1...",
            "🧠 Запускаю нейросети...",
            "💡 Генерирую гениальность...",
            "🔥 Создаю что-то невероятное...",
            "⚡ Обрабатываю твою идею...",
            "🎯 Анализирую возможности...",
            "🌟 Превращаю мысли в золото...",
            "🤖 ИИ думает над твоей идеей...",
            "✨ Магия генерации в процессе...",
            "🎭 Творческий процесс запущен..."
        ]
        return random.choice(messages)
    
    @staticmethod
    def get_vip_thinking_message(vip_type: str) -> str:
        """Возвращает специальное сообщение для VIP анализа"""
        messages = {
            "deep_analysis": "🧠 Провожу глубокий анализ идеи...",
            "market_research": "📊 Исследую рынок и конкурентов...", 
            "personas": "🎯 Создаю персоны целевой аудитории...",
            "business_model": "💰 Разрабатываю бизнес-модель...",
            "gtm": "🚀 Строю Go-to-Market стратегию...",
            "metrics": "📈 Определяю ключевые метрики..."
        }
        return messages.get(vip_type, "⭐ Провожу VIP анализ...")
    
    @staticmethod
    def format_error_message(error: str) -> str:
        """Форматирует сообщения об ошибках"""
        return f"""
❌ <b>Упс! Что-то пошло не так</b>

<i>{error}</i>

🔄 <b>Что можно сделать:</b>
• Попробуй ещё раз через несколько секунд
• Проверь, что запрос корректный
• Напиши /help для справки

<i>Если проблема повторяется, сообщи разработчику</i>
"""
    
    @staticmethod
    def get_welcome_message() -> str:
        """Приветственное сообщение"""
        return """
🚀 <b>Добро пожаловать в Idea Spark!</b>

Я превращаю идеи в тестируемые гипотезы и помогаю создавать MVP.

<b>Что умею:</b>
💡 Генерировать идеи стартапов
📦 Упаковывать концепции 
🔥 Создавать питчи
🔁 Предлагать случайные идеи
⭐ VIP анализ (глубокий разбор)

<b>Как пользоваться:</b>
Просто введи нишу или тему (например: "бот для фрилансеров")
Или используй кнопки ниже 👇

<i>Создано для предпринимателей, которые делают будущее 🌟</i>
"""
    
    @staticmethod
    def get_help_message() -> str:
        """Сообщение справки"""
        return """
📖 <b>Инструкция по использованию</b>

<b>Основные режимы:</b>
• <b>💡 Сгенерировать идею</b> - создаю гипотезу с оффером и структурой
• <b>📦 Упаковать идею</b> - оформляю концепцию для презентации
• <b>🔥 Питч</b> - создаю убедительную презентацию
• <b>🔁 Случайная идея</b> - предлагаю неожиданные решения
• <b>⭐ VIP режим</b> - глубокий анализ с метриками и стратегией

<b>Примеры запросов:</b>
• "AI для изучения языков"
• "Сервис для удаленных команд"
• "Экологичная упаковка"
• "Автоматизация для кафе"

<b>Команды:</b>
/start - перезапуск
/help - эта справка
/vip - VIP функции
"""
    
    @staticmethod
    def get_vip_message() -> str:
        """Сообщение VIP режима"""
        return """
⭐ <b>VIP Режим - Экспертный анализ</b>

<b>Что включено:</b>
🧠 Глубокий анализ идеи
📊 Исследование рынка
🎯 Персоны целевой аудитории
💰 Детальная бизнес-модель
🚀 Go-to-Market стратегия
📈 Метрики и KPI
⚠️ Анализ рисков
🔄 План развития

<b>Как использовать:</b>
1. Нажми на нужную VIP функцию
2. Введи свою идею
3. Получи экспертный анализ

<i>Для серьезных предпринимателей 💪</i>
"""
    
    @staticmethod
    def get_custom_assistant_message() -> str:
        """Сообщение о персональном ассистенте"""
        return """
🤖 <b>Персональный AI-ассистент</b>

Хочешь заказать персонального AI-ассистента с кастомными функциями?

🚀 <b>Что включено:</b>
• Индивидуальная настройка под твои задачи
• Интеграция с твоими системами
• Приоритетная поддержка

🎯 <b>Заказать можно здесь:</b>@Niro7_Bot

<i>Превращаем идеи в бизнес 💰</i>
"""
    
    @staticmethod
    def get_generation_prompts() -> dict:
        """Возвращает промпты для разных режимов генерации"""
        return {
            "idea": """
💡 <b>Генерация идеи</b>

Введи нишу или тему для генерации идеи.

<b>Примеры:</b>
• 'тревожные люди и ИИ'
• 'автоматизация для кафе'
• 'экологичная упаковка'
""",
            "pack": """
📦 <b>Упаковка идеи</b>

Введи идею для красивой упаковки с названием, слоганом и питчем.

<b>Пример:</b>
'Приложение для поиска попутчиков в путешествиях'
""",
            "pitch": """
🔥 <b>Создание питча</b>

Введи тему для создания убедительного питча.

<b>Получишь:</b>
• Описание проблемы
• Решение и преимущества
• Бизнес-модель
• Финансовые прогнозы
""",
            "category": """
📚 <b>Выбери тематику:</b>

Выбери интересующую область для генерации идей:
""",
            "main_menu": """
🏠 <b>Главное меню</b>

Выбери действие или просто введи свою идею:
"""
        }
    
    @staticmethod
    def get_random_tip() -> str:
        """Возвращает случайный совет по использованию"""
        tips = [
            "💡 <b>Совет:</b> Чем конкретнее описание проблемы, тем лучше идея!",
            "🎯 <b>Совет:</b> Попробуй VIP режим для глубокого анализа идеи",
            "📈 <b>Совет:</b> Используй упаковку идеи для презентаций инвесторам",
            "🔥 <b>Совет:</b> Создай питч, чтобы проверить убедительность идеи",
            "🧠 <b>Совет:</b> Исследуй разные тематики для поиска новых ниш",
            "⭐ <b>Совет:</b> Сохраняй понравившиеся идеи для дальнейшей проработки",
            "🚀 <b>Совет:</b> Тестируй идеи на реальных пользователях",
            "💰 <b>Совет:</b> Всегда думай о монетизации с самого начала"
        ]
        return random.choice(tips)
    
    @staticmethod
    def format_success_message(content: str, tip: bool = True, user_id: int = None) -> str:
        """Форматирует успешный ответ с возможным добавлением совета и статуса"""
        # Добавляем случайный совет
        if tip and random.random() < 0.3:
            content = f"{content}\n\n{MessageService.get_random_tip()}"
        
        # Добавляем статус-бар если передан user_id
        if user_id is not None:
            from services.limit_service import limit_service
            status_bar = limit_service.get_short_status(user_id)
            content = f"{content}\n\n{status_bar}"
        
        return content
    
    @staticmethod
    def validate_user_input(text: str) -> bool:
        """Валидация пользовательского ввода"""
        if not text or len(text.strip()) < 3:
            return False
        
        # Проверяем на спам и бессмысленные сообщения
        spam_patterns = ["test", "тест", "aaaa", "1111", "йцукенг", "asdf"]
        text_lower = text.lower()
        
        for pattern in spam_patterns:
            if pattern in text_lower and len(text) < 10:
                return False
        
        return True
    
    @staticmethod
    async def log_user_action(user_id: int, username: str, action: str, text: str = ""):
        """Логирует действия пользователей"""
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        log_entry = f"[{timestamp}] User {user_id} (@{username}) - {action}: {text[:100]}"
        print(log_entry)  # Можно заменить на запись в файл или БД

# Создаём глобальный экземпляр сервиса
message_service = MessageService()