"""
Расширенный сервис для управления лимитами и тарифами
"""

from datetime import datetime, date
from typing import Tuple, Dict
import config  # 🔥 ИМПОРТИРУЕМ ВЕСЬ config
from config import (
    VIP_USERS, DAILY_LIMIT_FREE, DAILY_LIMIT_VIP, 
    BASE_FUNCTIONS, VIP_FUNCTIONS, TARIFF_DESCRIPTIONS
)
from services.data_service import data_service

# Хранилище использованных запросов {user_id: {date: count}}
user_requests = {}

# 🔥 ЗАГРУЖАЕМ user_requests ПРИ ИМПОРТЕ
try:
    loaded_data = data_service.load_data()
    user_requests_str = loaded_data.get("user_requests", {})
    user_requests = {int(k): v for k, v in user_requests_str.items()}
    print(f"📊 Загружены базовые лимиты: {len(user_requests)} пользователей")
except:
    user_requests = {}
    print("📊 Базовые лимиты: новый старт")

# Функция инициализации (опциональная)
def init_limit_service():
    """Инициализирует сервис лимитов при старте бота"""
    global user_requests
    
    # Загружаем данные
    loaded_data = data_service.load_data()
    
    # Загружаем запросы пользователей
    user_requests_str = loaded_data.get("user_requests", {})
    user_requests = {int(k): v for k, v in user_requests_str.items()}
    
    print(f"📊 Загружены данные пользователей: {len(user_requests)} записей")
    print(f"💎 Пакеты в файле: {loaded_data.get('pack_users', {})}")

class LimitService:
    """Класс для управления лимитами и тарифами пользователей"""
    
    @staticmethod
    def is_vip_subscriber(user_id: int) -> bool:
        """Проверяет, является ли пользователь VIP подписчиком"""
        return user_id in VIP_USERS
    
    @staticmethod
    def get_pack_requests(user_id: int) -> int:
        """Возвращает количество оставшихся запросов в пакете"""
        # Загружаем данные из файла
        loaded_data = data_service.load_data()
        pack_users = loaded_data.get("pack_users", {})
        
        # Если в файле нет, но есть в config - копируем в файл
        if str(user_id) not in pack_users and user_id in config.PACK_USERS:
            pack_users[str(user_id)] = config.PACK_USERS[user_id]
            loaded_data["pack_users"] = pack_users
            data_service.save_data(loaded_data)
            print(f"📦 Скопирован пакет {user_id}: {config.PACK_USERS[user_id]} запросов")
        
        return pack_users.get(str(user_id), 0)
    
    @staticmethod
    def has_vip_access(user_id: int) -> bool:
        """Проверяет, есть ли у пользователя VIP доступ (подписка ИЛИ пакет)"""
        return LimitService.is_vip_subscriber(user_id) or LimitService.get_pack_requests(user_id) > 0
    
    @staticmethod
    def is_vip_user(user_id: int) -> bool:
        """Алиас для обратной совместимости"""
        return LimitService.has_vip_access(user_id)
    
    @staticmethod
    def get_user_daily_limit(user_id: int) -> int:
        """Возвращает дневной лимит базовых функций"""
        return DAILY_LIMIT_VIP if LimitService.is_vip_subscriber(user_id) else DAILY_LIMIT_FREE
    
    @staticmethod
    def get_user_requests_today(user_id: int) -> int:
        """Возвращает количество базовых запросов пользователя сегодня"""
        today = date.today().isoformat()
        
        if user_id not in user_requests:
            user_requests[user_id] = {}
        
        return user_requests[user_id].get(today, 0)
    
    @staticmethod
    def can_make_request(user_id: int, request_type: str) -> Tuple[bool, str]:
        """
        Проверяет, может ли пользователь сделать запрос
        Возвращает: (можно_ли, тип_ошибки)
        """
        # VIP функции требуют VIP доступ
        if request_type in VIP_FUNCTIONS:
            if not LimitService.has_vip_access(user_id):
                return False, "vip_required"
        
        # Базовые функции - проверяем дневные лимиты
        if request_type in BASE_FUNCTIONS:
            requests_today = LimitService.get_user_requests_today(user_id)
            daily_limit = LimitService.get_user_daily_limit(user_id)
            
            if requests_today >= daily_limit:
                return False, "limit_exceeded"
        
        return True, ""
    
    @staticmethod
    def register_request(user_id: int, request_type: str) -> None:
        """Регистрирует новый запрос и списывает из соответствующих лимитов"""
        today = date.today().isoformat()
        
        # Для базовых функций ведем дневную статистику
        if request_type in BASE_FUNCTIONS:
            if user_id not in user_requests:
                user_requests[user_id] = {}
            
            if today not in user_requests[user_id]:
                user_requests[user_id][today] = 0
            
            user_requests[user_id][today] += 1
            
            # Сохраняем в файл
            LimitService._save_user_requests()
        
        # Для VIP функций списываем из пакета (если есть)
        if request_type in VIP_FUNCTIONS:
            data = data_service.load_data()
            pack_users = data.get("pack_users", {})
            user_id_str = str(user_id)
            
            if user_id_str in pack_users and pack_users[user_id_str] > 0:
                pack_users[user_id_str] -= 1
                
                # Если пакет закончился, удаляем пользователя
                if pack_users[user_id_str] <= 0:
                    del pack_users[user_id_str]
                
                # Сохраняем обновленные данные
                data["pack_users"] = pack_users
                data_service.save_data(data)
            
            # Также обновляем config для совместимости (на время сессии)
            elif user_id in config.PACK_USERS and config.PACK_USERS[user_id] > 0:
                config.PACK_USERS[user_id] -= 1
                if config.PACK_USERS[user_id] <= 0:
                    del config.PACK_USERS[user_id]
    
    @staticmethod
    def get_requests_left(user_id: int) -> int:
        """Возвращает количество оставшихся базовых запросов"""
        if LimitService.is_vip_subscriber(user_id):
            return 999999 # "Безлимит" только для VIP подписчиков
        
        # Для пакетных и обычных - обычные лимиты
        requests_today = LimitService.get_user_requests_today(user_id)
        daily_limit = DAILY_LIMIT_FREE  # 10 запросов для всех не-VIP
        
        return max(0, daily_limit - requests_today)
    
    @staticmethod
    def add_pack_requests(user_id: int, requests_count: int) -> None:
        """Добавляет пакет запросов пользователю"""
        data = data_service.load_data()
        pack_users = data.get("pack_users", {})
        user_id_str = str(user_id)
        
        if user_id_str in pack_users:
            pack_users[user_id_str] += requests_count
        else:
            pack_users[user_id_str] = requests_count
        
        data["pack_users"] = pack_users
        data_service.save_data(data)
    
    @staticmethod
    def _save_user_requests() -> None:
        """Сохраняет данные о запросах пользователей"""
        data = data_service.load_data()
        data["user_requests"] = {str(k): v for k, v in user_requests.items()}
        data_service.save_data(data)
    
    @staticmethod
    def add_vip_subscription(user_id: int) -> None:
        """Добавляет VIP подписку пользователю"""
        if user_id not in VIP_USERS:
            VIP_USERS.append(user_id)
    
    @staticmethod
    def remove_vip_subscription(user_id: int) -> None:
        """Убирает VIP подписку у пользователя"""
        if user_id in VIP_USERS:
            VIP_USERS.remove(user_id)
    
    @staticmethod
    def get_user_type(user_id: int) -> str:
        """Возвращает тип пользователя"""
        if LimitService.is_vip_subscriber(user_id):
            return "vip_subscriber"
        elif LimitService.get_pack_requests(user_id) > 0:
            return "pack_user"
        else:
            return "free_user"
    
    @staticmethod
    def get_limit_message(user_id: int, error_type: str) -> str:
        """Возвращает сообщение о лимитах с предложением тарифов"""
        if error_type == "vip_required":
            return LimitService._get_vip_offer_message()
        
        elif error_type == "limit_exceeded":
            return LimitService._get_limit_exceeded_message()
        
        return "Неизвестная ошибка лимита"
    
    @staticmethod
    def get_limit_keyboard(error_type: str):
        """Возвращает клавиатуру с кнопками покупки для лимитов"""
        from keyboards.keyboards import InlineKeyboardMarkup, InlineKeyboardButton
        
        if error_type in ["vip_required", "limit_exceeded"]:
            return InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(text="💎 VIP Месяц - 399₽", callback_data="buy_vip_month")
                    ],
                    [
                        InlineKeyboardButton(text="🔥 VIP Год - 3990₽ (скидка 17%!)", callback_data="buy_vip_year")
                    ],
                    [
                        InlineKeyboardButton(text="📦 Пакет 50 - 99₽", callback_data="buy_pack_50")
                    ],
                    [
                    InlineKeyboardButton(text="📦 Пакет 200 - 299₽", callback_data="buy_pack_200")
                    ],
                    [
                        InlineKeyboardButton(text="ℹ️ Все тарифы", callback_data="show_pricing")
                    ]
                ]
            )
        return None
    
    @staticmethod
    def _get_vip_offer_message() -> str:
        """Сообщение с предложением VIP"""
        monthly = TARIFF_DESCRIPTIONS["monthly"]
        yearly = TARIFF_DESCRIPTIONS["yearly"]
        pack_50 = TARIFF_DESCRIPTIONS["pack_50"]
        
        return f"""
⭐ <b>VIP Функция</b>

Эта функция доступна только VIP пользователям!

<b>💎 Что дает VIP:</b>
• Безлимитные базовые запросы
• Все VIP функции (анализ, исследования, персоны)
• Приоритетная поддержка

<b>🚀 Выбери свой тариф:</b>
<i>Для заказа нажми кнопку ниже</i>
"""
    
    @staticmethod
    def _get_limit_exceeded_message() -> str:
        """Сообщение о превышении лимита"""
        return f"""
📊 <b>Дневной лимит исчерпан</b>

У тебя было {DAILY_LIMIT_FREE} бесплатных запросов на сегодня.

<b>⭐ Хочешь больше?</b>
VIP дает безлимитные запросы + эксклюзивные функции!

<b>🚀 Выбери свой тариф:</b>

<i>Бесплатный лимит обновится завтра в 00:00</i>
"""
    
    @staticmethod
    def get_status_message(user_id: int) -> str:
        """Возвращает подробный статус пользователя"""
        user_type = LimitService.get_user_type(user_id)
        requests_today = LimitService.get_user_requests_today(user_id)
        
        if user_type == "vip_subscriber":
            return f"""
⭐ <b>VIP Подписчик</b>

Использовано сегодня: {requests_today} запросов
Остальных: безлимит! 🔥

<b>Доступно:</b>
• Все базовые функции (безлимит)
• Все VIP функции (безлимит)
• Приоритетная поддержка
"""
        
        elif user_type == "pack_user":
            pack_requests = LimitService.get_pack_requests(user_id)
            requests_left = LimitService.get_requests_left(user_id)
            
            return f"""
💎 <b>Пакетный пользователь</b>

<b>Базовые функции:</b>
Использовано: {requests_today}/{DAILY_LIMIT_FREE}
Осталось: {requests_left} запросов

<b>VIP функции:</b>
Осталось в пакете: {pack_requests} запросов

<b>⭐ Хочешь безлимит?</b>
 /vip подписка всего {TARIFF_DESCRIPTIONS['monthly']['price']}₽/месяц
"""
        
        else:  # free_user
            requests_left = LimitService.get_requests_left(user_id)
            
            return f"""
🆓 <b>Бесплатный режим</b>

Использовано: {requests_today}/{DAILY_LIMIT_FREE}
Осталось: {requests_left} запросов

<b>⭐ Хочешь больше?</b>
- 💎 VIP подписка - безлимит
- 📦 Пакеты VIP запросов

⭐️ /vip
"""
    
    @staticmethod
    def get_tariffs_message() -> str:
        """Возвращает сообщение с тарифами"""
        return f"""
        ⭐ <b>Выбери тариф для VIP-функций:</b>
        
💎 VIP Месяц - 399₽: безлимит + все функции

🔥 VIP Год - 3990₽ (скидка 17%): безлимит + приоритет

📦 Пакет 50 - 99₽: 50 VIP-запросов

📦 Пакет 200 - 299₽: 200 VIP-запросов


⭐🚧 VIP в разработке
"""
 
    @staticmethod 
    def get_vip_redirect_message() -> str:
        """Возвращает VIP сообщение для перенаправления с тарифов"""
        from services.message_service import message_service
        return message_service.get_vip_message()
    
    @staticmethod
    def cleanup_old_data() -> None:
        """Очищает старые данные (запускать раз в день)"""
        today = date.today().isoformat()
        
        for user_id in user_requests:
            # Оставляем только сегодняшние данные
            user_requests[user_id] = {
                today: user_requests[user_id].get(today, 0)
            }
            
    @staticmethod
    def get_short_status(user_id: int) -> str:
        """Возвращает краткий статус для подвала сообщений"""
        user_type = LimitService.get_user_type(user_id)
        requests_today = LimitService.get_user_requests_today(user_id)
        
        if user_type == "vip_subscriber":
            return "───────────────\n💡 Сегодня: ∞ | 💎 VIP: ∞ | ⭐ Подписчик"
        
        elif user_type == "pack_user":
            pack_requests = LimitService.get_pack_requests(user_id)
            daily_limit = DAILY_LIMIT_FREE
            return f"───────────────\n💡 Сегодня: {requests_today}/{daily_limit} | 💎 VIP: {pack_requests} |⭐ /vip"
        
        else:  # free_user
            daily_limit = DAILY_LIMIT_FREE
            return f"───────────────\n💡 Сегодня: {requests_today}/{daily_limit} | 💎 VIP: нет |⭐ /vip"

# Создаём глобальный экземпляр сервиса
limit_service = LimitService()