"""
Сервис для работы с OpenAI API
"""

import openai
import re
from config import OPENAI_API_KEY, OPENAI_MODEL
from prompt_files.prompts import get_idea_prompt, get_pack_prompt, get_pitch_prompt, get_random_prompt, get_vip_prompt

class AIService:
    """Класс для работы с OpenAI API"""
    
    def __init__(self):
        self.client = openai.OpenAI(api_key=OPENAI_API_KEY)
    
    async def generate_response(self, user_input: str, mode: str = "idea") -> str:
        """Генерирует ответ через OpenAI API"""
        
        # Выбираем нужный промпт
        prompt = self._get_prompt(user_input, mode)
        
        try:
            completion = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1000,
                temperature=0.7,
                timeout=30
            )
            
            # Форматируем ответ для Telegram
            response = completion.choices[0].message.content
            return self._format_response(response)
            
        except openai.RateLimitError:
            import logging
            logging.warning("OpenAI rate limit exceeded")
            return "⏱ <b>Превышен лимит запросов OpenAI</b>\n\nПопробуй через минуту."
            
        except openai.AuthenticationError:
            import logging
            logging.error("OpenAI authentication failed")
            return "🔑 <b>Проблема с API ключом</b>\n\nОбратись к администратору."
            
        except openai.APIConnectionError:
            import logging
            logging.error("OpenAI connection error")
            return "🌐 <b>Проблема с подключением к OpenAI</b>\n\nПроверь интернет и попробуй позже."
            
        except Exception as e:
            import logging
            logging.error(f"Unexpected error in AI service: {e}")
            return "❌ <b>Техническая ошибка</b>\n\nПопробуй ещё раз или обратись в поддержку."
    
    def _get_prompt(self, user_input: str, mode: str) -> str:
        """Выбирает нужный промпт в зависимости от режима"""
        if mode == "idea":
            return get_idea_prompt(user_input)
        elif mode == "pack":
            return get_pack_prompt(user_input)
        elif mode == "pitch":
            return get_pitch_prompt(user_input)
        elif mode == "random":
            return get_random_prompt()
        elif mode == "vip":
            return get_vip_prompt(user_input)
        else:
            return get_idea_prompt(user_input)
    
    def _format_response(self, response: str) -> str:
        """Форматирует ответ для Telegram HTML"""
        # Заменяем **текст** на <b>текст</b>
        response = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', response)
        
        # Простая очистка битых HTML тегов
        response = re.sub(r'<b>\s*</b>', '', response)
        response = re.sub(r'<b>\s*$', '', response)
        
        # Закрываем незакрытые теги
        open_tags = response.count('<b>') - response.count('</b>')
        if open_tags > 0:
            response += '</b>' * open_tags
        
        return response
    
    async def generate_vip_response(self, user_input: str, vip_type: str) -> str:
        """Генерирует VIP ответ для конкретного типа анализа"""
        
        if vip_type == "deep_analysis":
            prompt = self._get_deep_analysis_prompt(user_input)
        elif vip_type == "market_research":
            prompt = self._get_market_research_prompt(user_input)
        elif vip_type == "personas":
            prompt = self._get_personas_prompt(user_input)
        elif vip_type == "business_model":
            prompt = self._get_business_model_prompt(user_input)
        elif vip_type == "gtm":
            prompt = self._get_gtm_prompt(user_input)
        elif vip_type == "metrics":
            prompt = self._get_metrics_prompt(user_input)
        elif vip_type == "risks":                    
            prompt = self._get_risks_prompt(user_input)
        elif vip_type == "roadmap":                  
            prompt = self._get_roadmap_prompt(user_input)
        else:
            prompt = get_vip_prompt(user_input)                     
        
        try:
            completion = self.client.chat.completions.create(
                model=OPENAI_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1500,
                temperature=0.7
            )
            result = self._format_response(completion.choices[0].message.content)
            return result
        except Exception as e:
            return f"❌ <b>Ошибка VIP анализа:</b> {str(e)}"
    
    def _get_deep_analysis_prompt(self, user_input: str) -> str:
        """Промпт для глубокого анализа"""
        return f"""
Проведи глубокий анализ идеи: {user_input}

🧠 <b>ГЛУБОКИЙ АНАЛИЗ:</b>

<b>💡 Концепция и инновационность:</b>
• Уникальность решения (1-10)
• Технологическая сложность
• Барьеры для входа

<b>🎯 Problem-Solution Fit:</b>
• Насколько критична проблема
• Качество решения
• Альтернативы на рынке

<b>📈 Масштабируемость:</b>
• Потенциал роста
• Сетевые эффекты
• Вирусность

<b>⚠️ Критические риски:</b>
• Технологические
• Регуляторные
• Конкурентные

<b>🔮 Прогноз успеха:</b> (процент вероятности с обоснованием)

Используй HTML теги <b></b> для выделения. Будь максимально честным и конкретным.
"""
    
    def _get_market_research_prompt(self, user_input: str) -> str:
        """Промпт для исследования рынка"""
        return f"""
Исследуй рынок для идеи: {user_input}

📊 <b>ИССЛЕДОВАНИЕ РЫНКА:</b>

<b>🌍 Размер рынка:</b>
• TAM (Total Addressable Market)
• SAM (Serviceable Addressable Market) 
• SOM (Serviceable Obtainable Market)

<b>📈 Тренды и динамика:</b>
• Рост рынка (% в год)
• Ключевые драйверы
• Сезонность

<b>🏢 Ключевые игроки:</b>
• Топ-3 конкурента
• Их слабые стороны
• Наша возможность

<b>💰 Монетизация:</b>
• Популярные модели
• Средний чек
• LTV/CAC соотношение

<b>🎯 Сегментация:</b>
• Основные сегменты
• Самый перспективный
• Стратегия захвата

Используй HTML теги <b></b> для выделения. Приведи конкретные цифры.
"""
    
    def _get_personas_prompt(self, user_input: str) -> str:
        """Промпт для создания персон"""
        return f"""
Создай персоны для идеи: {user_input}

🎯 <b>ПЕРСОНЫ ЦЕЛЕВОЙ АУДИТОРИИ:</b>

<b>👤 Персона #1 (Основная):</b>
• Имя и возраст
• Профессия и доход
• Боли и потребности
• Где проводит время
• Как принимает решения
• Что мотивирует к покупке

<b>👥 Персона #2 (Вторичная):</b>
• [аналогично]

<b>📱 Поведенческие паттерны:</b>
• Где ищут решения
• Кому доверяют
• Сколько готовы платить
• Как часто меняют решения

<b>💬 Голос аудитории:</b>
• Как говорят о проблеме
• Ключевые фразы
• Эмоциональные триггеры

Используй HTML теги <b></b> для выделения. Сделай персоны живыми и детальными.
"""
    
    def _get_business_model_prompt(self, user_input: str) -> str:
        """Промпт для бизнес-модели"""
        return f"""
Разработай бизнес-модель для: {user_input}

💰 <b>БИЗНЕС-МОДЕЛЬ:</b>

<b>💵 Монетизация:</b>
• Основная модель (подписка/покупка/комиссия)
• Дополнительные источники
• Ценообразование
• Прогноз выручки на 3 года

<b>📊 Unit-экономика:</b>
• CAC (Customer Acquisition Cost)
• LTV (Lifetime Value)
• Payback период
• Маржинальность

<b>💸 Структура расходов:</b>
• Основные статьи
• Переменные vs фиксированные
• Точка безубыточности

<b>🚀 Модель роста:</b>
• Органический рост
• Платное привлечение
• Партнерства
• Вирусные механизмы

<b>📈 Сценарии развития:</b>
• Консервативный
• Реалистичный  
• Оптимистичный

Используй HTML теги <b></b> для выделения. Дай конкретные цифры и расчеты.
"""
    
    def _get_gtm_prompt(self, user_input: str) -> str:
        """Промпт для Go-to-Market стратегии"""
        return f"""
Создай Go-to-Market стратегию для: {user_input}

🚀 <b>GO-TO-MARKET СТРАТЕГИЯ:</b>

<b>🎯 Этап 1: Валидация (0-3 месяца):</b>
• MVP функции
• Способы тестирования
• Метрики успеха
• Бюджет и ресурсы

<b>📈 Этап 2: Запуск (3-12 месяцев):</b>
• Каналы привлечения
• Контент-стратегия
• Партнерства
• PR и медиа

<b>⚡ Этап 3: Масштабирование (1-2 года):</b>
• Автоматизация процессов
• Расширение команды
• Новые рынки/сегменты
• Продуктовые линейки

<b>📢 Каналы привлечения:</b>
• Топ-3 приоритетных канала
• Бюджет на каждый
• Ожидаемая конверсия
• План тестирования

<b>📊 Roadmap первых 100 дней:</b>
• Конкретные действия по неделям
• Ответственные
• Чекпоинты

Используй HTML теги <b></b> для выделения. Сделай план максимально действенным.
"""
    
    def _get_metrics_prompt(self, user_input: str) -> str:
        """Промпт для метрик и KPI"""
        return f"""
Определи метрики и KPI для: {user_input}

📈 <b>МЕТРИКИ И KPI:</b>

<b>⭐ Северная звезда:</b>
• Главная метрика успеха
• Почему именно она
• Как измерять

<b>🔄 Продуктовые метрики:</b>
• Активные пользователи (DAU/MAU)
• Retention (Day 1, 7, 30)
• Engagement (время/сессии)
• Feature adoption

<b>💰 Финансовые метрики:</b>
• MRR/ARR
• CAC по каналам
• LTV по сегментам
• Churn rate
• ARPU

<b>📊 Операционные метрики:</b>
• Скорость роста
• Вирусность (k-factor)
• NPS (лояльность)
• Support tickets

<b>📈 Dashboard структура:</b>
• Ежедневный мониторинг
• Еженедельные отчеты
• Месячные ретроспективы

<b>⚠️ Red flags (тревожные сигналы):</b>
• Когда бить тревогу
• План реагирования

Используй HTML теги <b></b> для выделения. Дай конкретные цифры и способы отслеживания.
"""

    def _get_risks_prompt(self, user_input: str) -> str:
        """Промпт для анализа рисков"""
        return f"""
Проанализируй риски для идеи: {user_input}

⚠️ <b>АНАЛИЗ РИСКОВ:</b>

<b>🎯 Продуктовые риски:</b>
- Product-Market Fit не найден
- Технические сложности
- UX/UI проблемы
- Масштабирование продукта

<b>💰 Финансовые риски:</b>
- Превышение бюджета на разработку
- Низкая конверсия/монетизация
- Высокий CAC, низкий LTV
- Проблемы с фандрайзингом

<b>🏢 Рыночные риски:</b>
- Появление сильных конкурентов
- Изменение потребностей рынка
- Экономический кризис
- Регуляторные изменения

<b>👥 Командные риски:</b>
- Недостаток экспертизы
- Конфликты в команде
- Ключевая зависимость от людей
- Выгорание основателей

<b>🛡 Митигация рисков:</b>
- Конкретные действия по снижению
- План действий при наступлении
- Индикаторы раннего предупреждения

Используй HTML теги <b></b> для выделения. Будь реалистичным и конкретным.
"""

    def _get_roadmap_prompt(self, user_input: str) -> str:
        """Промпт для плана развития"""
        return f"""
Создай план развития для идеи: {user_input}

🔄 <b>ПЛАН РАЗВИТИЯ:</b>

<b>🎯 Этап 1: MVP (0-6 месяцев):</b>
- Минимальные функции для запуска
- Первые 100 пользователей
- Валидация гипотез
- Бюджет и команда

<b>📈 Этап 2: Рост (6-18 месяцев):</b>
- Расширение функционала
- Масштабирование до 10K пользователей
- Первая монетизация
- Поиск инвестиций

<b>🚀 Этап 3: Масштабирование (1.5-3 года):</b>
- Выход на новые рынки
- 100K+ пользователей
- Прибыльность и рост выручки
- Международная экспансия

<b>🔮 Этап 4: Зрелость (3+ года):</b>
- Доминирование в нише
- Диверсификация продуктов
- IPO или продажа
- Экосистема продуктов

<b>📊 Ключевые вехи:</b>
- Конкретные цели по месяцам
- Метрики успеха
- Чекпоинты для принятия решений

Используй HTML теги <b></b> для выделения. Сделай план реалистичным и выполнимым.
"""

# Создаём глобальный экземпляр сервиса
ai_service = AIService()