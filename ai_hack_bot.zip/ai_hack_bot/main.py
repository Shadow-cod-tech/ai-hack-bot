import sys
import os
sys.path.append(os.path.dirname(__file__))
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.enums import ParseMode
from aiogram.fsm.strategy import FSMStrategy
from aiogram.client.default import DefaultBotProperties

# Импортируем обработчики
from handlers import start, commands, tools, prompts, assistants
from config import load_config

async def main():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    try:
        logger.info("Загрузка конфигурации...")
        config = load_config()
        logger.info("Конфигурация загружена успешно")
        
        logger.info("Создание бота...")
        bot = Bot(
            token=config.bot_token,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML)
        )
        
        logger.info("Проверка токена бота...")
        bot_info = await bot.get_me()
        logger.info(f"Бот запущен: @{bot_info.username} ({bot_info.full_name})")
        
        dp = Dispatcher(storage=MemoryStorage(), fsm_strategy=FSMStrategy.CHAT)
        
        # Подключаем роутеры (порядок важен!)
        dp.include_router(start.router)
        dp.include_router(commands.router)
        dp.include_router(tools.router)
        dp.include_router(prompts.router)
        dp.include_router(assistants.router)  # ← ДОБАВИЛИ НОВЫЙ РОУТЕР
        
        logger.info("Удаление старых вебхуков...")
        await bot.delete_webhook(drop_pending_updates=True)
        
        logger.info("🚀 Бот успешно запущен и готов к работе!")
        logger.info(f"Найдите бота в Telegram: @{bot_info.username}")
        
        await dp.start_polling(bot)
        
    except Exception as e:
        logger.error(f"Ошибка при запуске бота: {e}")
        raise

if __name__ == "__main__":
    asyncio.run(main())