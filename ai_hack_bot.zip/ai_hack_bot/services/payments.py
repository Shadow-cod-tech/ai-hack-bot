# services/payments.py
import uuid
import requests
import base64
from datetime import datetime, timedelta

class YooKassaPayments:
    def __init__(self):
        self.shop_id = "YOUR_SHOP_ID"  # Из личного кабинета YooKassa
        self.secret_key = "YOUR_SECRET_KEY"
        self.api_url = "https://api.yookassa.ru/v3/payments"
        
    def create_payment(self, amount: float, description: str, user_id: int, subscription_type: str):
        """Создание платежа"""
        
        # Уникальный ID платежа
        idempotence_key = str(uuid.uuid4())
        
        headers = {
            'Authorization': self._get_auth_header(),
            'Idempotence-Key': idempotence_key,
            'Content-Type': 'application/json'
        }
        
        data = {
            "amount": {
                "value": str(amount),
                "currency": "RUB"
            },
            "confirmation": {
                "type": "redirect",
                "return_url": f"https://t.me/your_bot_name"  # Возврат в бота
            },
            "capture": True,
            "description": description,
            "metadata": {
                "user_id": str(user_id),
                "subscription_type": subscription_type,
                "bot_payment": "true"
            }
        }
        
        response = requests.post(
            self.api_url,
            json=data,
            headers=headers
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Payment creation failed: {response.text}")
    
    def _get_auth_header(self):
        """Создание заголовка авторизации"""
        credentials = f"{self.shop_id}:{self.secret_key}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        return f"Basic {encoded_credentials}"
    
    def check_payment_status(self, payment_id: str):
        """Проверка статуса платежа"""
        headers = {
            'Authorization': self._get_auth_header(),
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            f"{self.api_url}/{payment_id}",
            headers=headers
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return None