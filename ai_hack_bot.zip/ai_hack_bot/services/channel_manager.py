# services/channel_manager.py - Управление приватными каналами
import logging
from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError

logger = logging.getLogger(__name__)

class ChannelManager:
    """Менеджер приватных каналов с промптами"""
    
    def __init__(self):
        # ID каналов (заполнишь после создания)
        self.VIP_CHANNEL_ID = None  # Сюда вставишь ID VIP канала
        self.PREMIUM_CHANNEL_ID = None  # Сюда вставишь ID Premium канала
        
        # Названия каналов для логов
        self.channel_names = {
            "vip": "💎 AI HACK | VIP Промпты",
            "premium": "⭐ AI HACK | Premium Промпты"
        }
    
    def set_channel_ids(self, vip_id: str, premium_id: str):
        """Установить ID каналов"""
        self.VIP_CHANNEL_ID = vip_id
        self.PREMIUM_CHANNEL_ID = premium_id
        logger.info(f"Каналы настроены: VIP={vip_id}, Premium={premium_id}")
    
    async def add_user_to_channel(self, bot: Bot, user_id: int, channel_type: str) -> bool:
        """
        Добавить пользователя в канал
        
        Args:
            bot: Экземпляр бота
            user_id: ID пользователя
            channel_type: 'vip' или 'premium'
        
        Returns:
            bool: True если добавлен успешно
        """
        try:
            # Определяем ID канала
            if channel_type == "vip":
                channel_id = self.VIP_CHANNEL_ID
            elif channel_type == "premium":
                channel_id = self.PREMIUM_CHANNEL_ID
            else:
                logger.error(f"Неизвестный тип канала: {channel_type}")
                return False
            
            if not channel_id:
                logger.error(f"ID канала {channel_type} не установлен")
                return False
            
            # Создаем инвайт-ссылку для пользователя
            invite_link = await bot.create_chat_invite_link(
                chat_id=channel_id,
                member_limit=1,  # Ссылка только для одного пользователя
                name=f"Доступ для пользователя {user_id}"
            )
            
            # Отправляем ссылку пользователю
            channel_name = self.channel_names.get(channel_type, channel_type)
            await bot.send_message(
                chat_id=user_id,
                text=f"🎉 <b>Доступ к каналу открыт!</b>\n\n"
                     f"📱 <b>Канал:</b> {channel_name}\n"
                     f"🔗 <b>Ссылка для входа:</b>\n{invite_link.invite_link}\n\n"
                     f"💡 <b>В канале вас ждут:</b>\n"
                     f"• Эксклюзивные промпты\n"
                     f"• Еженедельные обновления\n"
                     f"• Новые материалы каждую неделю\n\n"
                     f"🚀 <b>Добро пожаловать в VIP сообщество!</b>",
                parse_mode="HTML"
            )
            
            logger.info(f"Пользователь {user_id} добавлен в канал {channel_type}")
            return True
            
        except TelegramBadRequest as e:
            logger.error(f"Ошибка Telegram при добавлении в канал {channel_type}: {e}")
            return False
        except TelegramForbiddenError as e:
            logger.error(f"Нет прав для добавления в канал {channel_type}: {e}")
            return False
        except Exception as e:
            logger.error(f"Неожиданная ошибка при добавлении в канал {channel_type}: {e}")
            return False
    
    async def add_vip_user(self, bot: Bot, user_id: int) -> bool:
        """Добавить пользователя в VIP канал"""
        return await self.add_user_to_channel(bot, user_id, "vip")
    
    async def add_premium_user(self, bot: Bot, user_id: int) -> bool:
        """Добавить пользователя в Premium каналы (VIP + Premium)"""
        # Premium пользователи получают доступ к обоим каналам
        vip_success = await self.add_user_to_channel(bot, user_id, "vip")
        premium_success = await self.add_user_to_channel(bot, user_id, "premium")
        
        return vip_success and premium_success
    
    async def send_welcome_message(self, bot: Bot, user_id: int, subscription_type: str):
        """Отправить приветственное сообщение с информацией о каналах"""
        if subscription_type == "vip":
            message = (
                "🎉 <b>Поздравляем с покупкой VIP!</b>\n\n"
                "💎 <b>Ваши VIP промпты готовы</b>\n"
                "📊 Количество: 6 промптов (стартовый набор)\n"
                "🎯 Эксклюзивная коллекция для профессионалов!\n\n"
                "📱 <b>БОНУС: Добавлены в VIP канал!</b>\n"
                "🔄 Новые промпты каждую неделю: 2-3 штуки\n"
                "📈 Через месяц у вас будет: 18+ промптов\n"
                "🚀 Постоянные обновления и эксклюзивный контент!\n\n"
                "✨ <b>Теперь доступны все VIP функции бота!</b>"
            )
        elif subscription_type == "premium":
            message = (
                "🚀 <b>Поздравляем с покупкой Premium!</b>\n\n"
                "⭐ <b>Ваши Premium промпты готовы</b>\n"
                "📊 Количество: 12+ промптов (VIP + Premium)\n"
                "🏆 Максимальная экспертность!\n\n"
                "📱 <b>БОНУС: Доступ к ДВУМ каналам!</b>\n"
                "💎 VIP канал + ⭐ Premium канал\n"
                "🔄 Новые промпты каждую неделю: 4-5 штук\n"
                "📈 Через месяц у вас будет: 30+ промптов\n"
                "🚀 Максимум эксклюзивного контента!\n\n"
                "✨ <b>Добро пожаловать в элитный клуб пользователей!</b>"
            )
        else:
            return
        
        await bot.send_message(
            chat_id=user_id,
            text=message,
            parse_mode="HTML"
        )

# Глобальный экземпляр менеджера каналов
channel_manager = ChannelManager()