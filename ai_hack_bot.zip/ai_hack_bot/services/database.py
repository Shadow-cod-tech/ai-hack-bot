# services/database.py (простая версия)
import sqlite3
from datetime import datetime

class UserDatabase:
    def __init__(self):
        self.init_db()
    
    def init_db(self):
        """Создание таблиц"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                subscription_type TEXT DEFAULT 'free',
                subscription_expires DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payments (
                payment_id TEXT PRIMARY KEY,
                user_id INTEGER,
                amount INTEGER,
                subscription_type TEXT,
                status TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_payment(self, payment_id, user_id, amount, subscription_type, status):
        """Сохранение платежа"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO payments 
            (payment_id, user_id, amount, subscription_type, status)
            VALUES (?, ?, ?, ?, ?)
        ''', (payment_id, user_id, amount, subscription_type, status))
        
        conn.commit()
        conn.close()
    
    def activate_subscription(self, user_id, subscription_type, expiry_date):
        """Активация подписки"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO users 
            (user_id, subscription_type, subscription_expires)
            VALUES (?, ?, ?)
        ''', (user_id, subscription_type, expiry_date))
        
        conn.commit()
        conn.close()
    
    def get_user_subscription(self, user_id):
        """Получение подписки пользователя"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT subscription_type, subscription_expires 
            FROM users WHERE user_id = ?
        ''', (user_id,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            subscription_type, expires = result
            if expires and datetime.fromisoformat(expires) > datetime.now():
                return subscription_type
        
        return 'free'