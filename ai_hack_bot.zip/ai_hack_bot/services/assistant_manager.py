# services/assistant_manager.py - Менеджер ассистентов
from typing import Dict, Optional
from services.openai_client import ask_gpt
from services.assistant_prompts import ASSISTANT_PROMPTS, ACTION_PROMPTS

class AssistantManager:
    """Менеджер для работы с ассистентами"""
    
    def __init__(self):
        # Хранение активного ассистента для каждого пользователя
        self.user_assistants: Dict[int, str] = {}
        self.user_contexts: Dict[int, list] = {}  # Для хранения контекста диалога
    
    def set_user_assistant(self, user_id: int, assistant_name: str):
        """Установить активного ассистента для пользователя"""
        self.user_assistants[user_id] = assistant_name
        # Очищаем контекст при смене ассистента
        self.user_contexts[user_id] = []
    
    def get_user_assistant(self, user_id: int) -> Optional[str]:
        """Получить активного ассистента пользователя"""
        return self.user_assistants.get(user_id)
    
    async def process_message(self, user_id: int, message: str, action_type: str = None) -> str:
        """Обработать сообщение пользователя через активного ассистента"""
        assistant = self.get_user_assistant(user_id)
        
        if not assistant:
            return "Сначала выберите ассистента через /menu → 🤖 Ассистенты"
        
        try:
            # Получаем системный промпт
            system_prompt = ASSISTANT_PROMPTS.get(assistant, "")
            
            # Если это специальное действие, используем соответствующий промпт
            if action_type and assistant in ACTION_PROMPTS:
                action_prompts = ACTION_PROMPTS[assistant]
                if action_type in action_prompts:
                    # Форматируем промпт с пользовательским вводом
                    formatted_prompt = action_prompts[action_type].format(user_input=message)
                    system_prompt += f"\n\nВыполни специальную задачу: {formatted_prompt}"
            
            # Получаем контекст диалога
            context = self.user_contexts.get(user_id, [])
            
            # Формируем полный промпт с контекстом
            if context:
                conversation_history = "\n".join([
                    f"Пользователь: {msg['user']}\nТы: {msg['assistant']}" 
                    for msg in context[-3:]  # Последние 3 сообщения для контекста
                ])
                full_prompt = f"{system_prompt}\n\nПредыдущий диалог:\n{conversation_history}\n\nОтветь на новое сообщение:"
            else:
                full_prompt = system_prompt
            
            # Отправляем запрос к ИИ
            response = await ask_gpt(full_prompt, message)
            
            # Сохраняем в контекст
            if user_id not in self.user_contexts:
                self.user_contexts[user_id] = []
            
            self.user_contexts[user_id].append({
                "user": message,
                "assistant": response
            })
            
            # Ограничиваем размер контекста
            if len(self.user_contexts[user_id]) > 10:
                self.user_contexts[user_id] = self.user_contexts[user_id][-10:]
            
            return response
            
        except Exception as e:
            return f"Ошибка при обращении к ассистенту: {str(e)}"
    
    def clear_context(self, user_id: int):
        """Очистить контекст диалога пользователя"""
        if user_id in self.user_contexts:
            self.user_contexts[user_id] = []
    
    def get_assistant_name(self, assistant_key: str) -> str:
        """Получить красивое имя ассистента"""
        names = {
            "dreamcrafter": "💎 DreamCrafter",
            "axis": "🧭 Axis", 
            "eclipt": "🚀 Eclipt"
        }
        return names.get(assistant_key, assistant_key)

# Глобальный экземпляр менеджера
assistant_manager = AssistantManager()