# services/prompt_manager.py
import random
from .prompt_collections import BASIC_PROMPTS, PREMIUM_PROMPTS, VIP_PROMPTS, RANDOM_PROMPTS

class PromptManager:
    """Менеджер промптов с системой ограничений"""
    
    def __init__(self):
        self.subscription_limits = {
            "free": {
                "daily_limit": 5,
                "collections": ["basic"],
                "can_search": False,
                "can_generate": True,
                "generation_limit": 3
            },
            "vip": {
                "daily_limit": 25,
                "collections": ["basic", "premium"],
                "can_search": True,
                "can_generate": True,
                "generation_limit": 15
            },
            "premium": {
                "daily_limit": -1,  # Безлимит
                "collections": ["basic", "premium", "vip"],
                "can_search": True,
                "can_generate": True,
                "generation_limit": -1  # Безлимит
            }
        }
    
    def get_prompts_by_category(self, category: str, subscription_level: str = "free"):
        """Получить промпты по категории с учетом подписки"""
        limits = self.subscription_limits.get(subscription_level, self.subscription_limits["free"])
        available_prompts = []
        
        # Определяем доступные коллекции
        if "basic" in limits["collections"]:
            for cat, prompts in BASIC_PROMPTS.items():
                if category == "all" or category == cat:
                    available_prompts.extend(prompts)
        
        if "premium" in limits["collections"]:
            for cat, prompts in PREMIUM_PROMPTS.items():
                if category == "all" or category == cat:
                    available_prompts.extend(prompts)
        
        if "vip" in limits["collections"]:
            for cat, prompts in VIP_PROMPTS.items():
                if category == "all" or category == cat:
                    available_prompts.extend(prompts)
        
        return available_prompts
    
    def get_random_prompt(self, category: str = "all", subscription_level: str = "free"):
        """Получить случайный промпт"""
        limits = self.subscription_limits.get(subscription_level, self.subscription_limits["free"])
        
        if not limits["can_generate"]:
            return None
        
        # Получаем доступные промпты
        available_prompts = self.get_prompts_by_category(category, subscription_level)
        
        if not available_prompts:
            return None
        
        return random.choice(available_prompts)
    
    def generate_creative_prompt(self, prompt_type: str = "creative", subscription_level: str = "free"):
        """Генерация случайного креативного промпта"""
        limits = self.subscription_limits.get(subscription_level, self.subscription_limits["free"])
        
        if not limits["can_generate"]:
            return {
                "error": "Генерация промптов доступна с VIP подпиской",
                "upgrade_needed": True
            }
        
        if prompt_type in RANDOM_PROMPTS:
            prompt_text = random.choice(RANDOM_PROMPTS[prompt_type])
            return {
                "title": f"Случайный {prompt_type} промпт",
                "prompt": prompt_text,
                "category": prompt_type.title(),
                "type": "generated"
            }
        
        return None
    
    def search_prompts(self, query: str, subscription_level: str = "free"):
        """Поиск промптов по запросу"""
        limits = self.subscription_limits.get(subscription_level, self.subscription_limits["free"])
        
        if not limits["can_search"]:
            return {
                "error": "Поиск промптов доступен с VIP подпиской",
                "upgrade_needed": True,
                "available_basic": self.get_prompts_by_category("all", "free")[:3]  # Покажем 3 базовых
            }
        
        results = []
        query_lower = query.lower()
        
        # Получаем все доступные промпты
        all_prompts = self.get_prompts_by_category("all", subscription_level)
        
        for prompt in all_prompts:
            if (query_lower in prompt['title'].lower() or 
                query_lower in prompt['prompt'].lower() or
                any(query_lower in tag for tag in prompt['tags'])):
                results.append(prompt)
        
        return {
            "results": results,
            "count": len(results),
            "query": query
        }
    
    def get_subscription_info(self, subscription_level: str = "free"):
        """Получить информацию о возможностях подписки"""
        limits = self.subscription_limits.get(subscription_level, self.subscription_limits["free"])
        
        collections_count = {
            "basic": len([p for cat in BASIC_PROMPTS.values() for p in cat]),
            "premium": len([p for cat in PREMIUM_PROMPTS.values() for p in cat]),
            "vip": len([p for cat in VIP_PROMPTS.values() for p in cat])
        }
        
        available_count = sum(
            collections_count[col] for col in limits["collections"]
        )
        
        return {
            "subscription": subscription_level,
            "daily_limit": limits["daily_limit"],
            "available_prompts": available_count,
            "can_search": limits["can_search"],
            "can_generate": limits["can_generate"],
            "generation_limit": limits["generation_limit"],
            "collections": limits["collections"]
        }
    
    def format_prompt_for_display(self, prompt: dict, show_full: bool = True):
        """Форматирование промпта для отображения"""
        if not show_full:
            # Краткий формат для FREE пользователей
            return {
                "title": prompt["title"],
                "category": prompt["category"],
                "preview": prompt["prompt"][:100] + "...",
                "tags": prompt["tags"][:3]
            }
        
        return prompt
    
    def get_featured_prompts(self, subscription_level: str = "free", count: int = 5):
        """Получить рекомендуемые промпты"""
        all_prompts = self.get_prompts_by_category("all", subscription_level)
        
        if not all_prompts:
            return []
        
        # Выбираем случайные промпты из разных категорий
        featured = []
        categories_used = set()
        
        for prompt in random.sample(all_prompts, min(len(all_prompts), count * 2)):
            if prompt["category"] not in categories_used or len(featured) < count:
                featured.append(prompt)
                categories_used.add(prompt["category"])
                
                if len(featured) >= count:
                    break
        
        return featured[:count]

# Глобальный экземпляр менеджера
prompt_manager = PromptManager()