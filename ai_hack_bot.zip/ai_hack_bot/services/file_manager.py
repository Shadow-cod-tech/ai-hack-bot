# services/file_manager.py - ЕДИНЫЙ файл для работы с файлами
import os
import json
from datetime import datetime
from typing import List, Dict

class FileManager:
    """Простой менеджер файлов промптов"""
    
    def __init__(self):
        self.base_path = "prompt_files"
        os.makedirs(f"{self.base_path}/exports", exist_ok=True)
    
    def create_txt_file(self, prompts: List[Dict], user_id: int, level: str = "basic") -> str:
        """Создание TXT файла с промптами"""
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"prompts_{level}_{user_id}_{timestamp}.txt"
        file_path = f"{self.base_path}/exports/{filename}"
        
        with open(file_path, 'w', encoding='utf-8') as f:
            # Заголовок
            if level == "premium":
                f.write("⭐ AI HACK | SMM BOOST - PREMIUM ПРОМПТЫ ⭐\n")
            elif level == "vip":
                f.write("💎 AI HACK | SMM BOOST - VIP ПРОМПТЫ 💎\n")
            else:
                f.write("🔓 AI HACK | SMM BOOST - БАЗОВЫЕ ПРОМПТЫ 🔓\n")
            
            f.write("="*60 + "\n")
            f.write(f"📅 Создано: {datetime.now().strftime('%d.%m.%Y %H:%M')}\n")
            f.write(f"📊 Количество: {len(prompts)} промптов\n")
            f.write("="*60 + "\n\n")
            
            # Промпты
            for i, prompt in enumerate(prompts, 1):
                f.write(f"{i}. {prompt['title']}\n")
                f.write("-" * 40 + "\n")
                f.write(f"Категория: {prompt['category']}\n")
                f.write(f"Теги: {', '.join(prompt['tags'])}\n\n")
                f.write(f"ПРОМПТ:\n{prompt['prompt']}\n")
                f.write("\n" + "="*60 + "\n\n")
            
            f.write("🚀 Готово к использованию в ChatGPT, Claude и других ИИ!\n")
            f.write("💡 Заменяйте [...] на свои данные\n")
        
        return file_path
    
    def create_json_file(self, prompts: List[Dict], user_id: int, level: str = "basic") -> str:
        """Создание JSON файла с промптами"""
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"prompts_{level}_{user_id}_{timestamp}.json"
        file_path = f"{self.base_path}/exports/{filename}"
        
        export_data = {
            "title": f"AI HACK | SMM Boost - {level.upper()} промпты",
            "created_at": datetime.now().isoformat(),
            "level": level,
            "total_prompts": len(prompts),
            "prompts": prompts
        }
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, ensure_ascii=False, indent=2)
        
        return file_path
    
    def cleanup_old_files(self, days: int = 7):
        """Удаление старых файлов"""
        import time
        
        if not os.path.exists(f"{self.base_path}/exports"):
            return
        
        current_time = time.time()
        cutoff_time = current_time - (days * 24 * 60 * 60)
        
        for filename in os.listdir(f"{self.base_path}/exports"):
            file_path = f"{self.base_path}/exports/{filename}"
            if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                os.remove(file_path)

# Глобальный экземпляр
file_manager = FileManager()