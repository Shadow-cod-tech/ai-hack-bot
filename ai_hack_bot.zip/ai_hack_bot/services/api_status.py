# services/api_status.py - Проверка статуса API
import os
from dotenv import load_dotenv

load_dotenv()

def check_openai_status():
    """Проверяет доступность OpenAI API"""
    api_key = os.getenv('OPENAI_API_KEY')
    
    # Проверяем есть ли ключ и не является ли он заглушкой
    if api_key and api_key != "placeholder" and api_key != "ваш_ключ_openai":
        return {
            "available": True,
            "status_emoji": "✅",
            "status_text": "Подключен (GPT-4)",
            "mode": "Полная генерация",
            "description": "🚀 Выберите действие или просто напишите свой запрос:"
        }
    else:
        return {
            "available": False,
            "status_emoji": "❌", 
            "status_text": "Не подключен",
            "mode": "Демо-версия",
            "description": "💡 ИИ недоступен - показываю примеры и шаблоны"
        }

def get_assistant_status_text(assistant_name: str):
    """Получить текст статуса для конкретного ассистента"""
    status = check_openai_status()
    
    if assistant_name == "dreamcrafter":
        base_text = (
            f"✅ <b>Активирован: DreamCrafter</b>\n\n"
            f"🤖 <b>Статус ИИ:</b> {status['status_emoji']} {status['status_text']}\n"
            f"✨ <b>Режим:</b> {status['mode']}\n\n"
            f"💎 <b>Мои специализации:</b>\n"
            f"• Midjourney — детальные художественные промпты\n"
            f"• DALL-E — креативные концепты\n"
            f"• Улучшение ваших промптов\n"
            f"• Советы по параметрам и стилям\n\n"
            f"{status['description']}"
        )
    
    elif assistant_name == "axis":
        base_text = (
            f"✅ <b>Активирован: Axis</b>\n\n"
            f"🤖 <b>Статус ИИ:</b> {status['status_emoji']} {status['status_text']}\n"
            f"✨ <b>Режим:</b> {status['mode']}\n\n"
            f"🧭 <b>Мои специализации:</b>\n"
            f"• Бизнес-стратегии и планирование\n"
            f"• Анализ сложных ситуаций\n"
            f"• Пошаговые планы действий\n"
            f"• Риск-менеджмент и оптимизация\n\n"
            f"{status['description']}"
        )
    
    elif assistant_name == "eclipt":
        base_text = (
            f"✅ <b>Активирован: Eclipt</b>\n\n"
            f"🤖 <b>Статус ИИ:</b> {status['status_emoji']} {status['status_text']}\n"
            f"✨ <b>Режим:</b> {status['mode']}\n\n"
            f"🚀 <b>Мои способности:</b>\n"
            f"• Создание атмосферных sci-fi рассказов\n"
            f"• Разработка игровых концептов\n"
            f"• Дизайн уникальных персонажей\n"
            f"• Футуристические миры и технологии\n\n"
            f"✨ <b>Пишу не словами — а гравитацией смыслов.</b>\n"
            f"{status['description']}"
        )
    
    else:
        base_text = f"Ассистент {assistant_name} активирован"
    
    return base_text