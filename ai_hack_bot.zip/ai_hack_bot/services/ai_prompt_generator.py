# services/ai_prompt_generator.py
import os
import random
from typing import Dict, Optional, List
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()

class AIPromptGenerator:
    """ИИ-генератор промптов с fallback на заготовки"""
    
    def __init__(self):
        self.openai_client = None
        self.openai_available = self._check_openai_availability()
        
        # Заготовки промптов (fallback)
        self.fallback_prompts = {
            "creative": [
                "Придумай необычный способ презентации {topic} через сторителлинг",
                "Создай креативную концепцию для {topic} с интерактивными элементами",
                "Разработай вирусную идею для {topic} в социальных сетях",
                "Придумай нестандартный формат подачи {topic} для молодой аудитории",
                "Создай эмоциональную историю вокруг {topic} для увеличения engagement"
            ],
            
            "business": [
                "Проанализируй бизнес-потенциал {topic} и создай план монетизации",
                "Разработай стратегию масштабирования {topic} для международного рынка",
                "Создай план антикризисного управления для {topic} в сложных условиях",
                "Придумай инновационную бизнес-модель для {topic} с минимальными вложениями",
                "Разработай систему KPI и метрик для оценки успешности {topic}"
            ],
            
            "marketing": [
                "Создай полную маркетинговую стратегию для {topic} с нулевым бюджетом",
                "Разработай план PR-кампании для {topic} с элементами вирусного маркетинга",  
                "Придумай партнерскую программу для продвижения {topic}",
                "Создай стратегию контент-маркетинга для {topic} на 3 месяца",
                "Разработай систему лидогенерации для {topic} через социальные сети"
            ],
            
            "smm": [
                "Создай контент-план для {topic} на месяц с адаптацией под все платформы",
                "Разработай стратегию работы с инфлюенсерами для продвижения {topic}",
                "Придумай серию интерактивных Stories для {topic} на неделю",
                "Создай план кросс-постинга {topic} с уникальной адаптацией под каждую сеть",
                "Разработай стратегию UGC (пользовательского контента) для {topic}"
            ],
            
            "copywriting": [
                "Напиши продающий текст для {topic} с использованием принципов нейромаркетинга",
                "Создай серию email-писем для воронки продаж {topic}",
                "Разработай скрипт продаж для {topic} с работой с возражениями", 
                "Напиши цепляющий заголовок и описание для {topic} в социальных сетях",
                "Создай текст лендинга для {topic} с высокой конверсией"
            ]
        }
        
        # Системные промпты для ИИ
        self.system_prompts = {
            "creative": """Ты эксперт по креативному маркетингу и инновационным идеям. 
            Создавай необычные, запоминающиеся промпты для креативных задач. 
            Фокусируйся на эмоциональном воздействии, storytelling и viral-потенциале.
            Промпт должен быть конкретным, actionable и вдохновляющим.""",
            
            "business": """Ты бизнес-консультант с опытом в стратегическом планировании. 
            Создавай промпты для бизнес-задач с фокусом на ROI, масштабируемость и практичность.
            Включай элементы анализа рисков, планирования ресурсов и измерения результатов.""",
            
            "marketing": """Ты маркетинг-директор с экспертизой в digital-маркетинге. 
            Создавай промпты для маркетинговых кампаний с акцентом на targeting, conversion и engagement.
            Учитывай современные тренды, омниканальность и customer journey.""",
            
            "smm": """Ты SMM-менеджер с глубоким пониманием социальных платформ. 
            Создавай промпты для соцсетей с учетом алгоритмов, форматов и особенностей каждой платформы.
            Фокусируйся на engagement, viral-потенциале и community building.""",
            
            "copywriting": """Ты копирайтер-эксперт в продающих текстах и убеждении. 
            Создавай промпты для копирайтинга с использованием психологических триггеров и техник убеждения.
            Включай элементы storytelling, работы с возражениями и call-to-action."""
        }
    
    def _check_openai_availability(self) -> bool:
        """Проверка доступности OpenAI API"""
        try:
            api_key = os.getenv('OPENAI_API_KEY')
            if api_key and api_key != "placeholder":
                self.openai_client = OpenAI(api_key=api_key)
                return True
            return False
        except Exception:
            return False
    
    async def generate_prompt(self, category: str, topic: str = "", user_input: str = "", subscription_level: str = "free") -> Dict:
        """Главная функция генерации промптов"""
        
        # Проверяем лимиты подписки
        if not self._check_generation_limits(subscription_level):
            return {
                "error": "Превышен лимит генерации",
                "upgrade_needed": True,
                "subscription_required": "vip" if subscription_level == "free" else "premium"
            }
        
        if self.openai_available:
            return await self._generate_with_ai(category, topic, user_input, subscription_level)
        else:
            return self._generate_fallback(category, topic, user_input)
    
    async def _generate_with_ai(self, category: str, topic: str, user_input: str, subscription_level: str) -> Dict:
        """Генерация промпта с помощью OpenAI"""
        try:
            # Формируем запрос к ИИ
            system_prompt = self.system_prompts.get(category, self.system_prompts["creative"])
            
            user_prompt = f"""
            Создай детальный и actionable промпт для категории "{category}".

            {"Тема: " + topic if topic else ""}
            {"Дополнительная информация: " + user_input if user_input else ""}

            Требования к промпту:
            - Конкретный и практичный
            - Включает пошаговые инструкции
            - Учитывает современные тренды
            - Подходит для {subscription_level} уровня
            - Длина: {"краткий (до 200 слов)" if subscription_level == "free" else "подробный (200-500 слов)"}

            ВАЖНО ПО ФОРМАТИРОВАНИЮ:
            - Используй HTML-разметку: <b>важное</b>, <i>курсив</i>
            - НЕ используй Markdown: **, *, _
            - Добавляй эмодзи для живости

            Верни результат в формате:
            ЗАГОЛОВОК: [короткий цепляющий заголовок]
            ПРОМПТ: [сам промпт с HTML-разметкой]
            ТЕГИ: [3-5 релевантных тегов через запятую]
            """ 
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=600,
                temperature=0.8
            )
            
            result = response.choices[0].message.content
            
            # Парсим ответ
            parsed = self._parse_ai_response(result)
            
            return {
                "title": parsed.get("title", f"ИИ-промпт: {category}"),
                "prompt": parsed.get("prompt", result),
                "category": category.title(),
                "tags": parsed.get("tags", [category, "ai_generated"]),
                "type": "ai_generated",
                "subscription_level": subscription_level,
                "source": "OpenAI GPT-4"
            }
            
        except Exception as e:
            # Если ИИ не сработал - fallback на заготовки
            return self._generate_fallback(category, topic, user_input, error=str(e))
    
    def _generate_fallback(self, category: str, topic: str, user_input: str, error: str = None) -> Dict:
        """Fallback генерация из заготовок"""
        
        # Выбираем случайный промпт из категории
        category_prompts = self.fallback_prompts.get(category, self.fallback_prompts["creative"])
        base_prompt = random.choice(category_prompts)
        
        # Подставляем тему
        if topic:
            prompt = base_prompt.format(topic=topic)
        else:
            prompt = base_prompt.replace("{topic}", "[ВАША_ТЕМА]")
        
        # Добавляем пользовательский ввод
        if user_input:
            prompt += f"\n\nДополнительные требования: {user_input}"
        
        return {
            "title": f"Промпт: {category}",
            "prompt": prompt,
            "category": category.title(),
            "tags": [category, "template", "fallback"],
            "type": "template",
            "source": "Заготовка" + (f" (ИИ недоступен: {error})" if error else ""),
            "ai_available": self.openai_available
        }
    
    def _parse_ai_response(self, response: str) -> Dict:
        """Парсинг ответа от ИИ"""
        try:
            lines = response.split('\n')
            result = {}
            
            for line in lines:
                if line.startswith('ЗАГОЛОВОК:'):
                    result['title'] = line.replace('ЗАГОЛОВОК:', '').strip()
                elif line.startswith('ПРОМПТ:'):
                    # Собираем весь промпт (может быть многострочным)
                    prompt_start = response.find('ПРОМПТ:') + len('ПРОМПТ:')
                    tags_start = response.find('ТЕГИ:')
                    if tags_start > 0:
                        result['prompt'] = response[prompt_start:tags_start].strip()
                    else:
                        result['prompt'] = response[prompt_start:].strip()
                elif line.startswith('ТЕГИ:'):
                    tags_text = line.replace('ТЕГИ:', '').strip()
                    result['tags'] = [tag.strip() for tag in tags_text.split(',')]
            
            return result
        except Exception:
            return {"prompt": response}
    
    def _check_generation_limits(self, subscription_level: str) -> bool:
        """Проверка лимитов генерации (заглушка)"""
        # Здесь будет реальная проверка лимитов из базы данных
        limits = {
            "free": 3,
            "vip": 15,
            "premium": -1  # Безлимит
        }
        
        # Пока всегда возвращаем True (лимиты не проверяем)
        return True
    
    def get_available_categories(self) -> List[str]:
        """Получить список доступных категорий"""
        return list(self.fallback_prompts.keys())
    
    def get_generation_info(self, subscription_level: str = "free") -> Dict:
        """Информация о возможностях генерации"""
        limits = {
            "free": {"daily_limit": 3, "ai_powered": False},
            "vip": {"daily_limit": 15, "ai_powered": True},
            "premium": {"daily_limit": -1, "ai_powered": True}
        }
        
        info = limits.get(subscription_level, limits["free"])
        info.update({
            "openai_available": self.openai_available,
            "categories": self.get_available_categories(),
            "total_fallback_prompts": sum(len(prompts) for prompts in self.fallback_prompts.values())
        })
        
        return info

# Глобальный экземпляр генератора
ai_prompt_generator = AIPromptGenerator()