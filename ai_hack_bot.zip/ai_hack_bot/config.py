import os
from dotenv import load_dotenv
from dataclasses import dataclass

@dataclass
class Config:
    bot_token: str
    openai_api_key: str

def load_config() -> Config:
    load_dotenv()
    
    bot_token = os.getenv('BOT_TOKEN')
    openai_api_key = os.getenv('OPENAI_API_KEY')
    
    if not bot_token:
        raise ValueError("BOT_TOKEN не найден в .env файле")
    
    # Включаем проверку OpenAI ключа для работы ассистентов
    if not openai_api_key:
        raise ValueError("OPENAI_API_KEY не найден в .env файле")
    
    return Config(
        bot_token=bot_token,
        openai_api_key=openai_api_key
    )