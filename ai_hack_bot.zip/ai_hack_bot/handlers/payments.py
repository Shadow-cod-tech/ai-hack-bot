# services/payments.py
import uuid
import requests
import base64
from datetime import datetime, timedelta

class YooKassaPayments:
    def __init__(self):
        self.shop_id = "YOUR_SHOP_ID"  # Из личного кабинета YooKassa
        self.secret_key = "YOUR_SECRET_KEY"
        self.api_url = "https://api.yookassa.ru/v3/payments"
        
    def create_payment(self, amount: float, description: str, user_id: int, subscription_type: str):
        """Создание платежа"""
        
        # Уникальный ID платежа
        idempotence_key = str(uuid.uuid4())
        
        headers = {
            'Authorization': self._get_auth_header(),
            'Idempotence-Key': idempotence_key,
            'Content-Type': 'application/json'
        }
        
        data = {
            "amount": {
                "value": str(amount),
                "currency": "RUB"
            },
            "confirmation": {
                "type": "redirect",
                "return_url": f"https://t.me/your_bot_name"  # Возврат в бота
            },
            "capture": True,
            "description": description,
            "metadata": {
                "user_id": str(user_id),
                "subscription_type": subscription_type,
                "bot_payment": "true"
            }
        }
        
        response = requests.post(
            self.api_url,
            json=data,
            headers=headers
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            raise Exception(f"Payment creation failed: {response.text}")
    
    def _get_auth_header(self):
        """Создание заголовка авторизации"""
        credentials = f"{self.shop_id}:{self.secret_key}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        return f"Basic {encoded_credentials}"
    
    def check_payment_status(self, payment_id: str):
        """Проверка статуса платежа"""
        headers = {
            'Authorization': self._get_auth_header(),
            'Content-Type': 'application/json'
        }
        
        response = requests.get(
            f"{self.api_url}/{payment_id}",
            headers=headers
        )
        
        if response.status_code == 200:
            return response.json()
        else:
            return None

# handlers/payments.py
from aiogram import Router
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from services.payments import YooKassaPayments
from services.database import UserDatabase

router = Router()
payments = YooKassaPayments()
db = UserDatabase()

@router.message(lambda message: message.text == "💰 Купить VIP - 499₽")
async def buy_vip(message: Message):
    try:
        # Создаем платеж
        payment = payments.create_payment(
            amount=499.00,
            description="VIP подписка AI HACK | SMM Boost",
            user_id=message.from_user.id,
            subscription_type="vip"
        )
        
        # Сохраняем в БД
        db.save_payment(
            payment_id=payment['id'],
            user_id=message.from_user.id,
            amount=499,
            subscription_type="vip",
            status="pending"
        )
        
        # Создаем кнопку для оплаты
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text="💳 Перейти к оплате",
                url=payment['confirmation']['confirmation_url']
            )],
            [InlineKeyboardButton(
                text="✅ Проверить оплату",
                callback_data=f"check_payment:{payment['id']}"
            )]
        ])
        
        await message.answer(
            f"💎 <b>VIP подписка</b>\n\n"
            f"💰 <b>Стоимость:</b> 499₽\n"
            f"⏰ <b>Срок:</b> 30 дней\n\n"
            f"🎯 <b>Что получите:</b>\n"
            f"• 🎯 Targeting Pro ассистент\n"
            f"• 📊 Analytics Master ассистент\n"
            f"• ⭐ VIP промпты\n"
            f"• 🚀 Безлимитные запросы\n\n"
            f"<i>После оплаты нажмите 'Проверить оплату'</i>",
            reply_markup=keyboard
        )
        
    except Exception as e:
        await message.answer(
            "❌ <b>Ошибка создания платежа</b>\n\n"
            "Попробуйте позже или обратитесь в поддержку."
        )

@router.message(lambda message: message.text == "💎 Купить Premium - 1099₽")
async def buy_premium(message: Message):
    try:
        payment = payments.create_payment(
            amount=1099.00,
            description="Premium подписка AI HACK | SMM Boost",
            user_id=message.from_user.id,
            subscription_type="premium"
        )
        
        db.save_payment(
            payment_id=payment['id'],
            user_id=message.from_user.id,
            amount=1099,
            subscription_type="premium",
            status="pending"
        )
        
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(
                text="💳 Перейти к оплате",
                url=payment['confirmation']['confirmation_url']
            )],
            [InlineKeyboardButton(
                text="✅ Проверить оплату",
                callback_data=f"check_payment:{payment['id']}"
            )]
        ])
        
        await message.answer(
            f"⭐ <b>Premium подписка</b>\n\n"
            f"💰 <b>Стоимость:</b> 1099₽\n"
            f"⏰ <b>Срок:</b> 30 дней\n\n"
            f"🎯 <b>Что получите:</b>\n"
            f"• 🏆 Brand Strategy ассистент\n"
            f"• 🔍 Competitor Intel ассистент\n"
            f"• 💎 Premium промпты\n"
            f"• 🔗 Интеграция с соцсетями\n"
            f"• ⏰ Автопостинг\n"
            f"• 👥 Командная работа\n\n"
            f"<i>После оплаты нажмите 'Проверить оплату'</i>",
            reply_markup=keyboard
        )
        
    except Exception as e:
        await message.answer("❌ Ошибка создания платежа")

# Обработка проверки платежа
@router.callback_query(lambda callback: callback.data.startswith("check_payment:"))
async def check_payment(callback):
    payment_id = callback.data.split(":")[1]
    
    try:
        payment_status = payments.check_payment_status(payment_id)
        
        if payment_status and payment_status['status'] == 'succeeded':
            # Платеж успешен - активируем подписку
            subscription_type = payment_status['metadata']['subscription_type']
            user_id = int(payment_status['metadata']['user_id'])
            
            # Обновляем статус в БД
            expiry_date = datetime.now() + timedelta(days=30)
            db.activate_subscription(user_id, subscription_type, expiry_date)
            
            subscription_name = "VIP" if subscription_type == "vip" else "Premium"
            
            await callback.message.edit_text(
                f"✅ <b>Платеж успешно обработан!</b>\n\n"
                f"🎉 <b>{subscription_name} подписка активирована!</b>\n"
                f"⏰ <b>Действует до:</b> {expiry_date.strftime('%d.%m.%Y')}\n\n"
                f"Теперь у вас есть доступ ко всем {subscription_name} функциям!"
            )
            
        elif payment_status and payment_status['status'] == 'pending':
            await callback.answer("⏳ Платеж еще обрабатывается. Попробуйте через минуту.")
            
        else:
            await callback.answer("❌ Платеж не найден или отменен.")
            
    except Exception as e:
        await callback.answer("❌ Ошибка проверки платежа.")

# services/database.py (простая версия)
import sqlite3
from datetime import datetime

class UserDatabase:
    def __init__(self):
        self.init_db()
    
    def init_db(self):
        """Создание таблиц"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                subscription_type TEXT DEFAULT 'free',
                subscription_expires DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS payments (
                payment_id TEXT PRIMARY KEY,
                user_id INTEGER,
                amount INTEGER,
                subscription_type TEXT,
                status TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_payment(self, payment_id, user_id, amount, subscription_type, status):
        """Сохранение платежа"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO payments 
            (payment_id, user_id, amount, subscription_type, status)
            VALUES (?, ?, ?, ?, ?)
        ''', (payment_id, user_id, amount, subscription_type, status))
        
        conn.commit()
        conn.close()
    
    def activate_subscription(self, user_id, subscription_type, expiry_date):
        """Активация подписки"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO users 
            (user_id, subscription_type, subscription_expires)
            VALUES (?, ?, ?)
        ''', (user_id, subscription_type, expiry_date))
        
        conn.commit()
        conn.close()
    
    def get_user_subscription(self, user_id):
        """Получение подписки пользователя"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT subscription_type, subscription_expires 
            FROM users WHERE user_id = ?
        ''', (user_id,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            subscription_type, expires = result
            if expires and datetime.fromisoformat(expires) > datetime.now():
                return subscription_type
        
        return 'free'