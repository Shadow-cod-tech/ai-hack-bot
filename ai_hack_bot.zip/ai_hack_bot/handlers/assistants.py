# handlers/assistants.py - Обработчики ассистентов
from aiogram import Router
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from services.assistant_manager import assistant_manager
from services.api_status import get_assistant_status_text
from aiogram import Router

router = Router()

# Меню для каждого ассистента
def get_dreamcrafter_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="💬 Свободный запрос"),
                KeyboardButton(text="🎨 Промпт для Midjourney")
            ],
            [
                KeyboardButton(text="🖼️ Промпт для DALL-E"),
                KeyboardButton(text="⚡ Улучшить мой промпт")
            ],
            [
                KeyboardButton(text="💡 Советы по параметрам"),
                KeyboardButton(text="🔙 Сменить ассистента")
            ]
        ], 
        resize_keyboard=True
    )

def get_axis_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="💬 Свободный запрос"),
                KeyboardButton(text="📊 Бизнес-стратегия")
            ],
            [
                KeyboardButton(text="📈 Анализ ситуации"),
                KeyboardButton(text="🎯 План действий")
            ],
            [
                KeyboardButton(text="🔙 Сменить ассистента")
            ]
        ], 
        resize_keyboard=True
    )

def get_eclipt_menu():
    return ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="💬 Свободный запрос"),
                KeyboardButton(text="📖 Написать sci-fi рассказ")
            ],
            [
                KeyboardButton(text="🎮 Гейм-дизайн идея"),
                KeyboardButton(text="🌌 Концепт персонажа")
            ],
            [
                KeyboardButton(text="✨ Персонаж для истории"),
                KeyboardButton(text="🔙 Сменить ассистента")
            ]
        ], 
        resize_keyboard=True
    )

# Обработчики выбора ассистентов
@router.message(lambda message: message.text == "💎 DreamCrafter")
async def select_dreamcrafter(message: Message):
    user_id = message.from_user.id
    assistant_manager.set_user_assistant(user_id, "dreamcrafter")
    
    status_text = get_assistant_status_text("dreamcrafter")
    
    await message.answer(
        status_text,
        reply_markup=get_dreamcrafter_menu(),
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "🧭 Axis")
async def select_axis(message: Message):
    user_id = message.from_user.id
    assistant_manager.set_user_assistant(user_id, "axis")
    
    status_text = get_assistant_status_text("axis")
    
    await message.answer(
        status_text,
        reply_markup=get_axis_menu(),
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "🚀 Eclipt")
async def select_eclipt(message: Message):
    user_id = message.from_user.id
    assistant_manager.set_user_assistant(user_id, "eclipt")
    
    status_text = get_assistant_status_text("eclipt")
    
    await message.answer(
        status_text,
        reply_markup=get_eclipt_menu(),
        parse_mode="HTML"
    )

# Обработчики специальных действий DreamCrafter
@router.message(lambda message: message.text == "🎨 Промпт для Midjourney")
async def dreamcrafter_midjourney(message: Message):
    await message.answer(
        "🎨 <b>Режим: Midjourney промпт</b>\n\n"
        "Опишите, что вы хотите создать, и я сделаю детальный промпт для Midjourney с параметрами и настройками.\n\n"
        "💡 <b>Например:</b> \"Футуристический город на закате\" или \"Портрет эльфа в стиле ренессанс\""
    )

@router.message(lambda message: message.text == "🖼️ Промпт для DALL-E")
async def dreamcrafter_dalle(message: Message):
    await message.answer(
        "🖼️ <b>Режим: DALL-E промпт</b>\n\n"
        "Расскажите, какое изображение нужно создать, и я составлю оптимальный промпт для DALL-E.\n\n"
        "💡 <b>Например:</b> \"Кот-астронавт в космосе\" или \"Абстрактная картина в стиле Кандинского\""
    )

@router.message(lambda message: message.text == "⚡ Улучшить мой промпт")
async def dreamcrafter_improve(message: Message):
    await message.answer(
        "⚡ <b>Режим: Улучшение промпта</b>\n\n"
        "Отправьте свой промпт, и я сделаю его более детальным и эффективным.\n\n"
        "💡 <b>Например:</b> вставьте свой текущий промпт для анализа и улучшения"
    )

@router.message(lambda message: message.text == "💡 Советы по параметрам")
async def dreamcrafter_tips(message: Message):
    await message.answer(
        "💡 <b>Режим: Советы по параметрам</b>\n\n"
        "Расскажите, для какой нейросети нужны советы, и я дам рекомендации по параметрам и стилям.\n\n"
        "💡 <b>Например:</b> \"Как настроить параметры Midjourney для фотореализма\" или \"Лучшие стили для DALL-E\""
    )

# Обработчики специальных действий Axis
@router.message(lambda message: message.text == "📊 Бизнес-стратегия")
async def axis_strategy(message: Message):
    await message.answer(
        "📊 <b>Режим: Разработка бизнес-стратегии</b>\n\n"
        "Опишите вашу бизнес-ситуацию или цель, и я разработаю стратегию с конкретными шагами.\n\n"
        "💡 <b>Например:</b> \"Запуск онлайн-курсов\" или \"Увеличение продаж на 50%\""
    )

@router.message(lambda message: message.text == "📈 Анализ ситуации")
async def axis_analysis(message: Message):
    await message.answer(
        "📈 <b>Режим: Анализ ситуации</b>\n\n"
        "Опишите ситуацию, которую нужно проанализировать, и я дам структурированную оценку с рекомендациями.\n\n"
        "💡 <b>Например:</b> \"Падение продаж\" или \"Выбор между двумя решениями\""
    )

@router.message(lambda message: message.text == "🎯 План действий")
async def axis_plan(message: Message):
    await message.answer(
        "🎯 <b>Режим: Создание плана действий</b>\n\n"
        "Сформулируйте вашу цель или задачу, и я создам детальный план с этапами и временными рамками.\n\n"
        "💡 <b>Например:</b> \"Запустить блог\" или \"Найти новую работу за 2 месяца\""
    )

# Обработчики специальных действий Eclipt
@router.message(lambda message: message.text == "📖 Написать sci-fi рассказ")
async def eclipt_story(message: Message):
    await message.answer(
        "📖 <b>Режим: Создание sci-fi рассказа</b>\n\n"
        "Дайте мне тему, идею или сеттинг, и я напишу атмосферный научно-фантастический рассказ.\n\n"
        "💡 <b>Например:</b> \"Колония на Марсе\" или \"ИИ обретает сознание\""
    )

@router.message(lambda message: message.text == "🎮 Гейм-дизайн идея")
async def eclipt_gamedesign(message: Message):
    await message.answer(
        "🎮 <b>Режим: Разработка игрового концепта</b>\n\n"
        "Опишите жанр, сеттинг или механику, и я создам концепт игры с уникальными особенностями.\n\n"
        "💡 <b>Например:</b> \"Космическая стратегия\" или \"Загадки в киберпанк-мире\""
    )

@router.message(lambda message: message.text == "🌌 Концепт персонажа")
async def eclipt_character_concept(message: Message):
    await message.answer(
        "🌌 <b>Режим: Создание концепта персонажа</b>\n\n"
        "Опишите тип персонажа или роль, и я создам детальный концепт для игры или фильма.\n\n"
        "💡 <b>Например:</b> \"Киборг-детектив\" или \"Alien-дипломат\""
    )

@router.message(lambda message: message.text == "✨ Персонаж для истории")
async def eclipt_character_story(message: Message):
    await message.answer(
        "✨ <b>Режим: Персонаж для рассказа</b>\n\n"
        "Дайте мне описание или роль персонажа, и я создам глубокого героя с предысторией и мотивацией.\n\n"
        "💡 <b>Например:</b> \"Бунтарь против корпораций\" или \"Ученый из прошлого\""
    )

# Обработчик смены ассистента
@router.message(lambda message: message.text == "🔙 Сменить ассистента")
async def change_assistant(message: Message):
    user_id = message.from_user.id
    assistant_manager.clear_context(user_id)  # Очищаем контекст
    
    # Возвращаем в меню ассистентов
    from handlers.commands import assistants_menu
    await assistants_menu(message)

# Обработчик свободных запросов
@router.message(lambda message: message.text == "💬 Свободный запрос")
async def free_request(message: Message):
    await message.answer(
        "💬 <b>Режим свободного общения активирован</b>\n\n"
        "Теперь просто напишите ваш вопрос или запрос, и я отвечу в обычном режиме."
    )

# Главный обработчик всех текстовых сообщений (должен быть в конце)
@router.message()
async def process_assistant_message(message: Message):
    """Обработка всех текстовых сообщений через активного ассистента"""
    user_id = message.from_user.id
    user_text = message.text
    
    # Игнорируем системные команды и кнопки меню
    if user_text in [
        "💎 VIP", "⭐ Premium", "🤖 Ассистенты", "🛠 Инструменты", 
        "📝 Промпты", "❓ Помощь", "🔄 Сброс режима", "🔙 Назад в меню",
        "💰 Оформить VIP", "💰 Оформить Premium"
    ]:
        return  # Пропускаем, пусть обрабатывает commands.py
    
    # Проверяем, есть ли активный ассистент
    current_assistant = assistant_manager.get_user_assistant(user_id)
    
    if not current_assistant:
        await message.answer(
            "🤖 <b>Ассистент не выбран</b>\n\n"
            "Выберите ассистента через:\n"
            "/menu → 🤖 Ассистенты\n\n"
            "Доступные ассистенты:\n"
            "💎 DreamCrafter — промпты для ИИ-изображений\n"
            "🧭 Axis — стратегии и планирование\n"
            "🚀 Eclipt — sci-fi контент и гейм-дизайн"
        )
        return
    
    # Определяем тип действия на основе предыдущего сообщения или кнопки
    action_type = None
    
    # Показываем индикатор "печатает"
    await message.bot.send_chat_action(chat_id=message.chat.id, action="typing")
    
    # Обрабатываем сообщение через ассистента
    response = await assistant_manager.process_message(user_id, user_text, action_type)
    
    # Отправляем ответ
    assistant_name = assistant_manager.get_assistant_name(current_assistant)
    
    await message.answer(
        f"{assistant_name}\n\n{response}",
        parse_mode="HTML"
    )