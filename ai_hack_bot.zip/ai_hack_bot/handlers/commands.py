from services.channel_manager import channel_manager
from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, FSInputFile
from services.file_manager import file_manager
from services.prompt_manager import prompt_manager
import os

router = Router()

# Функция для отправки файлов после успешной покупки
async def send_subscription_file(bot, user_id: int, subscription_type: str):
    """Отправка файла с промптами + добавление в каналы после покупки подписки"""
    
    try:
        # 1. ОТПРАВЛЯЕМ ФАЙЛ (как раньше)
        if subscription_type == "vip":
            # Получаем VIP промпты
            prompts = prompt_manager.get_prompts_by_category("all", "vip")
            file_path = file_manager.create_txt_file(prompts, user_id, "vip")
            
            if os.path.exists(file_path):
                file_obj = FSInputFile(file_path)
                
                await bot.send_document(
                    chat_id=user_id,
                    document=file_obj,
                    caption="💎 <b>Стартовый набор VIP промптов</b>\n\n"
                           f"📊 Количество: {len(prompts)} промптов\n"
                           f"🎯 Готово к использованию!\n\n"
                           f"📱 <b>Также подготавливаем доступ к каналу...</b>",
                    parse_mode="HTML"
                )
                
                # Удаляем временный файл
                os.remove(file_path)
        
        elif subscription_type == "premium":
            # Получаем Premium промпты (включая VIP)
            vip_prompts = prompt_manager.get_prompts_by_category("all", "vip")
            premium_prompts = prompt_manager.get_prompts_by_category("all", "premium")
            all_prompts = vip_prompts + premium_prompts
            
            file_path = file_manager.create_txt_file(all_prompts, user_id, "premium")
            
            if os.path.exists(file_path):
                file_obj = FSInputFile(file_path)
                
                await bot.send_document(
                    chat_id=user_id,
                    document=file_obj,
                    caption="⭐ <b>Стартовый набор Premium промптов</b>\n\n"
                           f"📊 Количество: {len(all_prompts)} промптов\n"
                           f"🏆 Максимальная экспертность!\n\n"
                           f"📱 <b>Также подготавливаем доступ к каналам...</b>",
                    parse_mode="HTML"
                )
                
                # Удаляем временный файл
                os.remove(file_path)
        
        # 2. ДОБАВЛЯЕМ В КАНАЛЫ (новая функция)
        if subscription_type == "vip":
            # Добавляем в VIP канал
            success = await channel_manager.add_vip_user(bot, user_id)
            if success:
                await channel_manager.send_welcome_message(bot, user_id, "vip")
            else:
                await bot.send_message(
                    chat_id=user_id,
                    text="⚠️ <b>VIP активирован!</b>\n\n"
                         "Файл получен ✅\n"
                         "Канал: ссылка будет отправлена отдельно\n\n"
                         "Если не получили ссылку на канал, обратитесь в поддержку: /help",
                    parse_mode="HTML"
                )
        
        elif subscription_type == "premium":
            # Добавляем в оба канала (VIP + Premium)
            success = await channel_manager.add_premium_user(bot, user_id)
            if success:
                await channel_manager.send_welcome_message(bot, user_id, "premium")
            else:
                await bot.send_message(
                    chat_id=user_id,
                    text="⚠️ <b>Premium активирован!</b>\n\n"
                         "Файл получен ✅\n"
                         "Каналы: ссылки будут отправлены отдельно\n\n"
                         "Если не получили ссылки на каналы, обратитесь в поддержку: /help",
                    parse_mode="HTML"
                )
                
    except Exception as e:
        # Логируем ошибку и отправляем сообщение пользователю
        print(f"Ошибка отправки файла пользователю {user_id}: {e}")
        
        await bot.send_message(
            chat_id=user_id,
            text="⚠️ <b>Подписка активирована!</b>\n\n"
                 "Произошла ошибка при отправке материалов.\n"
                 "Файлы можно скачать в разделе промптов.\n"
                 "Ссылки на каналы будут отправлены отдельно.\n\n"
                 f"Если проблема повторяется, обратитесь в поддержку: /help",
            parse_mode="HTML"
        )

@router.message(Command("menu"))
async def menu_handler(message: Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="🤖 Ассистенты"),
                KeyboardButton(text="🛠 Инструменты")
            ],
            [
                KeyboardButton(text="📝 Промпты"),
                KeyboardButton(text="❓ Помощь")
            ],
            [
                KeyboardButton(text="💎 VIP"),
                KeyboardButton(text="⭐ Premium")
            ],
            [
                KeyboardButton(text="🔄 Сброс режима")
            ]
        ], 
        resize_keyboard=True,
        one_time_keyboard=False
    )
    await message.answer(
        "🎯 <b>Главное меню</b>\n\n"
        "🤖 <b>Ассистенты</b> — бесплатные помощники\n"
        "🛠 <b>Инструменты</b> — SMM инструменты\n"
        "📝 <b>Промпты</b> — готовые шаблоны\n"
        "💎 <b>VIP</b> — расширенные возможности\n"
        "⭐ <b>Premium</b> — максимальный функционал\n\n"
        "Выберите категорию:",
        reply_markup=kb
    )

# Меню ассистентов
@router.message(lambda message: message.text == "🤖 Ассистенты")
async def assistants_menu(message: Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="💎 DreamCrafter"),
                KeyboardButton(text="🧭 Axis")
            ],
            [
                KeyboardButton(text="🚀 Eclipt")
            ],
            [
                KeyboardButton(text="🎯 Заказать ассистента")
            ],
            [
                KeyboardButton(text="🔙 Назад в меню")
            ]
        ], 
        resize_keyboard=True,
        one_time_keyboard=False
    )
    await message.answer(
        "🤖 <b>Ассистенты</b>\n\n"
        "💎 <b>DreamCrafter</b> — переводит идеи в промпты для Midjourney, Flux, SDXL\n"
        "🧭 <b>Axis</b> — стратегии, планирование, анализ\n"
        "🚀 <b>Eclipt</b> — теневой спутник для sci-fi авторов. Пишет не словами — а гравитацией смыслов\n\n"
        "🎯 <b>Или закажите персонального ассистента под ваши задачи!</b>\n\n"
        "Выберите ассистента:",
        reply_markup=kb,
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "🎯 Заказать ассистента")
async def order_assistant(message: Message):
    await message.answer(
        "🎯 <b>Заказать персонального ассистента</b>\n\n"
        "🤖 <b>Создадим ИИ-помощника под ваши задачи:</b>\n"
        "• Персональный промпт и характер\n"
        "• Специализация под вашу нишу\n"
        "• Уникальные функции и возможности\n"
        "• Интеграция в бота или отдельное решение\n\n"
        "💰 <b>Стоимость:</b> от 15,000₽\n"
        "⏱️ <b>Срок разработки:</b> 5-7 дней\n\n"
        "📱 <b>Для заказа напишите:</b>\n"
        "👉 @Niro7_Bot - описание задач и требований\n\n"
        "💡 <b>Пример заказа:</b>\n"
        "'Нужен ассистент для анализа криптовалют и генерации торговых сигналов с интеграцией в Telegram'\n\n"
        "🎁 <b>Бонус:</b> первая консультация бесплатно!",
        parse_mode="HTML"
    )

# Меню инструментов
@router.message(lambda message: message.text == "🛠 Инструменты")
async def tools_menu(message: Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="📊 SMM Анализ"),
                KeyboardButton(text="📈 Трендовый анализ")
            ],
            [
                KeyboardButton(text="🎯 Таргетинг помощь"),
                KeyboardButton(text="📝 Контент планер")
            ],
            [
                KeyboardButton(text="#️⃣ Генератор хештегов"),
                KeyboardButton(text="📱 Креативы для Stories")
            ],
            [
                KeyboardButton(text="🔙 Назад в меню")
            ]
        ], 
        resize_keyboard=True
    )
    await message.answer(
        "🛠 <b>SMM Инструменты</b>\n\n"
        "📊 <b>SMM Анализ</b> — анализ аккаунтов и контента\n"
        "📈 <b>Трендовый анализ</b> — отслеживание трендов\n"
        "🎯 <b>Таргетинг помощь</b> — настройка рекламы\n"
        "📝 <b>Контент планер</b> — планирование публикаций\n"
        "#️⃣ <b>Генератор хештегов</b> — подбор хештегов\n"
        "📱 <b>Креативы для Stories</b> — шаблоны и идеи\n\n"
        "Выберите инструмент:",
        reply_markup=kb
    )

# Меню промптов
@router.message(lambda message: message.text == "📝 Промпты")
async def prompts_menu(message: Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="🔓 Базовые промпты"),
                KeyboardButton(text="⭐ Premium промпты")
            ],
            [
                KeyboardButton(text="💎 VIP промпты"),
                KeyboardButton(text="🎲 Генератор промптов")
            ],
            [
                KeyboardButton(text="🔙 Назад в меню")
            ]
        ], 
        resize_keyboard=True
    )
    await message.answer(
        "📝 <b>Промпты и шаблоны</b>\n\n"
        "🔓 <b>Базовые промпты</b> — простые шаблоны (бесплатно)\n"
        "⭐ <b>Premium промпты</b> — премиум шаблоны высшего качества\n"
        "💎 <b>VIP промпты</b> — продвинутые профессиональные наработки\n"
        "🎲 <b>Генератор промптов</b> — случайные промпты для вдохновения\n\n"
        "Выберите раздел:",
        reply_markup=kb
    )

@router.message(lambda message: message.text == "🔙 Назад в меню")
async def back_to_menu(message: Message):
    await menu_handler(message)

@router.message(Command("help"))
async def help_handler(message: Message):
    await message.answer(
        "ℹ️ <b>AI HACK | SMM Boost - Помощь</b>\n\n"
        "🤖 <b>Описание:</b>\n"
        "Бот-помощник для SMM, создания контента и работы с ИИ\n\n"
        "<b>📋 Основные команды:</b>\n"
        "/start — перезапуск и приветствие\n"
        "/menu — главное меню\n"
        "/help — справка по боту\n"
        "/reset — сброс режима и контекста\n\n"
        "<b>💎 Доступы:</b>\n"
        "/vip — информация о VIP-функциях\n"
        "/premium — информация о Premium\n\n"
        "<b>🤖 Ассистенты:</b>\n"
        "💎 <b>DreamCrafter</b> — переводит идеи в промпты для Midjourney, Flux, SDXL\n"
        "🧭 <b>Axis</b> — стратегии, планирование, анализ\n"
        "🚀 <b>Eclipt</b> — теневой спутник для sci-fi авторов\n\n"
        "Выберите ассистента через /menu и просто пишите свои запросы!"
    )

@router.message(Command("reset"))
async def reset_handler(message: Message):
    await message.answer(
        "🔄 <b>Режим сброшен!</b>\n\n"
        "Контекст ассистента очищен.\n"
        "Напиши /menu для выбора нового ассистента."
    )

@router.message(Command("vip"))
async def vip_handler(message: Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="💰 Оформить VIP")
            ],
            [
                KeyboardButton(text="🔙 Назад в меню")
            ]
        ], 
        resize_keyboard=True
    )
    await message.answer(
        "💎 <b>VIP-доступ</b>\n\n"
        "🎯 <b>Что входит в VIP:</b>\n"
        "• 📅 Сезонные тренды и аналитика\n"
        "• 👥 Настройка аудитории для таргетинга\n"
        "• 🎨 Генератор креативов для рекламы\n"
        "• 💡 Идеи для постов + готовые хештеги\n"
        "• 🎨 Визуальный план контента\n"
        "• 🎯 Нишевые и локальные хештеги\n"
        "• 📊 Интерактивы для Stories\n"
        "• 🎬 Видео шаблоны и сценарии\n"
        "• 📱 Расширенные шаблоны дизайна\n\n"
        "💰 <b>Стоимость:</b> 499₽/месяц\n"
        "⚡ <b>Активация мгновенная!</b>",
        reply_markup=kb
    )
    
@router.message(Command("premium"))
async def premium_handler(message: Message):
    await premium_menu_button(message)

# VIP кнопка и покупка
@router.message(lambda message: message.text == "💎 VIP")
async def vip_menu_button(message: Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="💰 Оформить VIP")
            ],
            [
                KeyboardButton(text="🔙 Назад в меню")
            ]
        ], 
        resize_keyboard=True
    )
    await message.answer(
        "💎 <b>VIP-доступ</b>\n\n"
        "🎯 <b>Что входит в VIP:</b>\n"
        "• 📅 Сезонные тренды и аналитика\n"
        "• 👥 Настройка аудитории для таргетинга\n"
        "• 🎨 Генератор креативов для рекламы\n"
        "• 💡 Идеи для постов + готовые хештеги\n"
        "• 🎨 Визуальный план контента\n"
        "• 🎯 Нишевые и локальные хештеги\n"
        "• 📊 Интерактивы для Stories\n"
        "• 🎬 Видео шаблоны и сценарии\n"
        "• 📱 Расширенные шаблоны дизайна\n\n"
        "💰 <b>Стоимость:</b> 499₽/месяц\n"
        "⚡ <b>Активация мгновенная!</b>",
        reply_markup=kb
    )

@router.message(lambda message: message.text == "💰 Оформить VIP")
async def purchase_vip(message: Message):
    """ВРЕМЕННАЯ ЗАГЛУШКА - платежи в разработке"""
    await message.answer(
        "💎 <b>VIP подписка</b>\n\n"
        "🚧 <b>Доступ ограничен</b>\n\n"
        "⏳ <b>Скоро будет доступно:</b>\n"
        "• Оплата через банковские карты\n"
        "• СБП (Система Быстрых Платежей)\n\n"
        "💬 <b>Вопросы:</b> @Niro7_Bot",
        parse_mode="HTML"
    )

# Premium кнопка и покупка
@router.message(lambda message: message.text == "⭐ Premium")
async def premium_menu_button(message: Message):
    kb = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(text="💰 Оформить Premium")
            ],
            [
                KeyboardButton(text="🔙 Назад в меню")
            ]
        ], 
        resize_keyboard=True
    )
    await message.answer(
        "⭐ <b>Premium-доступ</b>\n\n"
        "🎯 <b>Что входит в Premium:</b>\n"
        "• 🎯 Тренды по нишам и отраслям\n"
        "• 📱 Анализ вирусных форматов контента\n"
        "• 📊 A/B тестирование рекламных кампаний\n"
        "• 📈 Аналитика эффективности контента\n"
        "• 📈 Трендовые хештеги в реальном времени\n"
        "• 📝 ИИ-генератор текстов для Stories\n"
        "• 🏆 Брендинговые стратегии\n"
        "• 🔍 Конкурентная разведка\n"
        "• 🔗 Интеграция с соцсетями\n"
        "• ⏰ Автопостинг контента\n"
        "• 👥 Командная работа\n\n"
        "💰 <b>Стоимость:</b> 1099₽/месяц\n"
        "⚡ <b>Максимальный функционал!</b>",
        reply_markup=kb
    )

@router.message(lambda message: message.text == "💰 Оформить Premium")
async def purchase_premium(message: Message):
    """ВРЕМЕННАЯ ЗАГЛУШКА - платежи в разработке"""
    await message.answer(
        "⭐ <b>Premium подписка</b>\n\n"
        "🚧 <b>Доступ ограничен</b>\n\n"
        "⏳ <b>Скоро будет доступно:</b>\n"
        "• Оплата через банковские карты\n"
        "• СБП (Система Быстрых Платежей)\n\n"
        "💬 <b>Вопросы:</b> @Niro7_Bot",
        parse_mode="HTML"
    )

# Тестовые команды для разработки
@router.message(Command("activate_vip_test"))
async def test_activate_vip(message: Message):
    """ТЕСТОВАЯ активация VIP"""
    user_id = message.from_user.id
    
    await send_subscription_file(message.bot, user_id, "vip")
    
    await message.answer(
        "✅ <b>VIP активирован (ТЕСТ)</b>\n\n"
        "🎯 <b>Тестовая активация прошла успешно</b>\n"
        "💎 Все VIP функции доступны\n"
        "📄 Файл с промптами отправлен выше\n\n"
        "⚠️ <b>Это тестовый режим!</b>",
        parse_mode="HTML"
    )

@router.message(Command("activate_premium_test"))
async def test_activate_premium(message: Message):
    """ТЕСТОВАЯ активация Premium"""
    user_id = message.from_user.id
    
    await send_subscription_file(message.bot, user_id, "premium")
    
    await message.answer(
        "✅ <b>Premium активирован (ТЕСТ)</b>\n\n"
        "🎯 <b>Тестовая активация прошла успешно</b>\n"
        "⭐ Все Premium функции доступны\n"
        "📄 Файл с промптами отправлен выше\n\n"
        "⚠️ <b>Это тестовый режим!</b>",
        parse_mode="HTML"
    )

# Обработчики кнопок
@router.message(lambda message: message.text == "❓ Помощь")
async def help_button(message: Message):
    """Обработчик кнопки Помощь"""
    await help_handler(message)

@router.message(lambda message: message.text == "🔄 Сброс режима")
async def reset_button(message: Message):
    """Обработчик кнопки Сброс режима"""
    await reset_handler(message)