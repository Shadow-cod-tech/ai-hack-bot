# handlers/prompts.py
from aiogram import Router
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from services.prompt_manager import prompt_manager
from services.ai_prompt_generator import ai_prompt_generator
from services.file_manager import file_manager
import random
import os

router = Router()

# Глобальный словарь для хранения промптов пользователей
user_prompts = {}

# ===== ОСНОВНЫЕ ОБРАБОТЧИКИ МЕНЮ =====

@router.message(lambda message: message.text == "🔓 Базовые промпты")
async def basic_prompts(message: Message):
    user_id = message.from_user.id
    subscription_level = "free"  # Заглушка, потом заменим на реальную проверку
    
    # Получаем базовые промпты
    prompts = prompt_manager.get_prompts_by_category("all", subscription_level)
    
    if not prompts:
        await message.answer("❌ Базовые промпты временно недоступны")
        return
    
    # Показываем первые 5 промптов БЕЗ кнопок к каждому
    response = "🔓 <b>Базовые промпты (FREE)</b>\n\n"
    
    for i, prompt in enumerate(prompts[:5], 1):
        response += f"{i}. <b>{prompt['title']}</b>\n"
        response += f"📝 {prompt['prompt'][:80]}...\n"
        response += f"🏷️ {' '.join(f'#{tag}' for tag in prompt['tags'][:3])}\n\n"
    
    response += f"📊 <b>Показано:</b> 5 из {len(prompts)} доступных\n\n"
    response += "💡 <b>Как получить полный промпт:</b>\n"
    response += "🎲 Нажмите «Случайный промпт» для получения полного текста с кнопкой копирования\n\n"
    response += "💎 <b>VIP:</b> Доступ ко всем промптам + поиск"
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎲 Случайный промпт", callback_data="random_prompt_basic")],
        [InlineKeyboardButton(text="📥 Скачать базовые", callback_data="download_basic_prompts")],
        [InlineKeyboardButton(text="📱 SMM промпты", callback_data="category_social_media")],
        [InlineKeyboardButton(text="💼 Бизнес промпты", callback_data="category_business")],
        [InlineKeyboardButton(text="💎 Открыть VIP", callback_data="upgrade_vip")]
    ])
    
    await message.answer(response, reply_markup=kb, parse_mode="HTML")

@router.message(lambda message: message.text == "⭐ Premium промпты")
async def premium_prompts_section(message: Message):
    user_id = message.from_user.id
    subscription_level = "free"  # Заглушка
    
    if subscription_level == "free":
        # Показываем превью
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="👀 Посмотреть превью", callback_data="preview_premium")],
            [InlineKeyboardButton(text="⭐ Купить Premium", callback_data="upgrade_premium")]
        ])
        
        await message.answer(
            "⭐ <b>Premium промпты</b>\n\n"
            "🏆 <b>Профессиональные промпты высшего качества:</b>\n"
            "• 📈 Комплексные маркетинговые стратегии\n"
            "• 🎯 Вирусные кампании и тренды\n"
            "• 💰 Продающие тексты и лендинги\n"
            "• 📊 Бизнес-аналитика и планирование\n"
            "• 🚀 Персональные бренды экспертов\n\n"
            "📈 <b>Количество:</b> 50+ премиум промптов\n"
            "💎 <b>Стоимость:</b> 1399₽/месяц\n\n"
            "🔒 <b>Для доступа нужна Premium подписка</b>",
            reply_markup=kb,
            parse_mode="HTML"
        )
    else:
        # Для VIP/Premium пользователей показываем полный список
        prompts = prompt_manager.get_prompts_by_category("all", "vip")
        premium_prompts = [p for p in prompts if p.get('category') in ['Стратегия', 'Маркетинг', 'Копирайтинг']]
        
        response = "⭐ <b>Premium промпты</b>\n\n"
        
        for i, prompt in enumerate(premium_prompts[:7], 1):
            response += f"{i}. <b>{prompt['title']}</b>\n"
            response += f"📝 {prompt['prompt'][:100]}...\n\n"
        
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🎲 Случайный Premium", callback_data="random_prompt_premium")],
            [InlineKeyboardButton(text="📥 Скачать Premium", callback_data="download_premium_prompts")],
            [InlineKeyboardButton(text="🔍 Поиск промптов", callback_data="search_prompts")]
        ])
        
        await message.answer(response, reply_markup=kb, parse_mode="HTML")

@router.message(lambda message: message.text == "💎 VIP промпты")
async def vip_prompts_section(message: Message):
    user_id = message.from_user.id
    subscription_level = "free"  # Заглушка
    
    if subscription_level in ["free"]:
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="👀 Эксклюзивное превью", callback_data="preview_vip")],
            [InlineKeyboardButton(text="💎 Купить VIP", callback_data="upgrade_vip")]
        ])
        
        await message.answer(
            "💎 <b>VIP промпты</b>\n\n"
            "🎯 <b>Эксклюзивные промпты топ-уровня:</b>\n"
            "• 🧠 Экспертные стратегии и аналитика\n"
            "• 🚀 Инновационные подходы к бизнесу\n"
            "• 📊 Предиктивные модели и Blue Ocean\n"
            "• 🔥 Антикризисные PR-стратегии\n"
            "• 💰 Комплексные системы монетизации\n\n"
            "📈 <b>Количество:</b> 100+ VIP промптов\n"
            "💎 <b>Стоимость:</b> 699₽/месяц\n\n"
            "🔒 <b>Для доступа нужна VIP подписка</b>",
            reply_markup=kb,
            parse_mode="HTML"
        )
    else:
        # Для VIP/Premium пользователей
        prompts = prompt_manager.get_prompts_by_category("all", "vip")
        vip_prompts = [p for p in prompts if p.get('category') in ['Стратегический маркетинг', 'Инновационная стратегия']]
        
        response = "💎 <b>VIP промпты</b>\n\n"
        
        for i, prompt in enumerate(vip_prompts[:5], 1):
            response += f"{i}. <b>{prompt['title']}</b>\n"
            response += f"📝 {prompt['prompt'][:120]}...\n\n"
        
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🎲 Случайный VIP", callback_data="random_prompt_vip")],
            [InlineKeyboardButton(text="📥 Скачать VIP", callback_data="download_vip_prompts")],
            [InlineKeyboardButton(text="🔍 Поиск по тегам", callback_data="search_prompts")]
        ])
        
        await message.answer(response, reply_markup=kb, parse_mode="HTML")

# ===== НОВЫЙ ИИ-ГЕНЕРАТОР =====

@router.message(lambda message: message.text == "🎲 Генератор промптов")
async def ai_prompt_generator_menu(message: Message):
    user_id = message.from_user.id
    subscription_level = "free"  # Заглушка
    
    # Получаем информацию о генераторе
    gen_info = ai_prompt_generator.get_generation_info(subscription_level)
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎨 Креативные", callback_data="ai_generate_creative")],
        [InlineKeyboardButton(text="💼 Бизнес", callback_data="ai_generate_business")],
        [InlineKeyboardButton(text="📱 Маркетинг", callback_data="ai_generate_marketing")],
        [InlineKeyboardButton(text="✍️ Копирайтинг", callback_data="ai_generate_copywriting")],
        [InlineKeyboardButton(text="📱 SMM", callback_data="ai_generate_smm")],
        [InlineKeyboardButton(text="🎲 Случайный", callback_data="ai_generate_random")]
    ])
    
    response = "🎲 <b>ИИ-Генератор промптов</b>\n\n"
    
    if gen_info["openai_available"]:
        response += "🤖 <b>Статус ИИ:</b> ✅ Подключен (GPT-4)\n"
        response += "✨ <b>Режим:</b> Умная генерация промптов\n"
    else:
        response += "🤖 <b>Статус ИИ:</b> ❌ Не подключен\n"
        response += "📝 <b>Режим:</b> Заготовки промптов\n"
    
    response += f"\n🎯 <b>Доступные категории:</b>\n"
    response += "• 🎨 Креативные идеи и сторителлинг\n"
    response += "• 💼 Бизнес-стратегии и планирование\n"
    response += "• 📱 Маркетинг и реклама\n"
    response += "• ✍️ Копирайтинг и продающие тексты\n"
    response += "• 📱 SMM и социальные сети\n\n"
    
    if gen_info["daily_limit"] == -1:
        response += "✨ <b>Лимит:</b> Безлимит\n"
    else:
        response += f"⚡ <b>Лимит:</b> {gen_info['daily_limit']} в день\n"
    
    if subscription_level == "free":
        response += "💎 <b>VIP:</b> ИИ-генерация + 12 дополнительных генераций"
    
    await message.answer(response, reply_markup=kb, parse_mode="HTML")

# ===== ОБРАБОТЧИКИ СКАЧИВАНИЯ ФАЙЛОВ =====

@router.callback_query(lambda c: c.data == "download_basic_prompts")
async def download_basic_prompts_callback(callback_query):
    user_id = callback_query.from_user.id
    
    await callback_query.answer("📥 Создаю файл...")
    
    try:
        # Получаем промпты
        prompts = prompt_manager.get_prompts_by_category("all", "free")
        
        # Создаем TXT файл
        file_path = file_manager.create_txt_file(prompts, user_id, "basic")
        
        # Отправляем файл
        if os.path.exists(file_path):
            file_obj = FSInputFile(file_path)
            
            await callback_query.message.answer_document(
                document=file_obj,
                caption=f"📥 <b>Ваши базовые промпты</b>\n\n"
                       f"📊 Количество: {len(prompts)} промптов\n"
                       f"💡 Готово к использованию!",
                parse_mode="HTML"
            )
            
            # Удаляем файл после отправки
            os.remove(file_path)
            
        else:
            await callback_query.message.answer("❌ Ошибка создания файла")
            
    except Exception as e:
        await callback_query.message.answer(f"❌ Ошибка: {str(e)}")

@router.callback_query(lambda c: c.data == "download_vip_prompts")
async def download_vip_prompts_callback(callback_query):
    user_id = callback_query.from_user.id
    subscription_level = "vip"  # Заглушка - здесь должна быть проверка подписки
    
    # Проверяем доступ
    if subscription_level == "free":
        await callback_query.answer("💎 Нужна VIP подписка!", show_alert=True)
        return
    
    await callback_query.answer("📥 Создаю VIP файл...")
    
    try:
        # Получаем VIP промпты
        prompts = prompt_manager.get_prompts_by_category("all", "vip")
        
        # Создаем TXT файл
        file_path = file_manager.create_txt_file(prompts, user_id, "vip")
        
        # Отправляем файл
        if os.path.exists(file_path):
            file_obj = FSInputFile(file_path)
            
            await callback_query.message.answer_document(
                document=file_obj,
                caption=f"💎 <b>Ваши VIP промпты</b>\n\n"
                       f"📊 Количество: {len(prompts)} промптов\n"
                       f"🎯 Эксклюзивная коллекция!",
                parse_mode="HTML"
            )
            
            # Удаляем файл после отправки
            os.remove(file_path)
            
        else:
            await callback_query.message.answer("❌ Ошибка создания файла")
            
    except Exception as e:
        await callback_query.message.answer(f"❌ Ошибка: {str(e)}")

@router.callback_query(lambda c: c.data == "download_premium_prompts")
async def download_premium_prompts_callback(callback_query):
    user_id = callback_query.from_user.id
    subscription_level = "premium"  # Заглушка - здесь должна быть проверка подписки
    
    # Проверяем доступ
    if subscription_level in ["free", "vip"]:
        await callback_query.answer("⭐ Нужна Premium подписка!", show_alert=True)
        return
    
    await callback_query.answer("📥 Создаю Premium файл...")
    
    try:
        # Получаем Premium промпты
        prompts = prompt_manager.get_prompts_by_category("all", "premium")
        
        # Создаем TXT файл
        file_path = file_manager.create_txt_file(prompts, user_id, "premium")
        
        # Отправляем файл
        if os.path.exists(file_path):
            file_obj = FSInputFile(file_path)
            
            await callback_query.message.answer_document(
                document=file_obj,
                caption=f"⭐ <b>Ваши Premium промпты</b>\n\n"
                       f"📊 Количество: {len(prompts)} промптов\n"
                       f"🏆 Максимальная экспертность!",
                parse_mode="HTML"
            )
            
            # Удаляем файл после отправки
            os.remove(file_path)
            
        else:
            await callback_query.message.answer("❌ Ошибка создания файла")
            
    except Exception as e:
        await callback_query.message.answer(f"❌ Ошибка: {str(e)}")

# JSON версии для скачивания
@router.callback_query(lambda c: c.data == "download_basic_json")
async def download_basic_json_callback(callback_query):
    user_id = callback_query.from_user.id
    
    await callback_query.answer("📥 Создаю JSON...")
    
    try:
        prompts = prompt_manager.get_prompts_by_category("all", "free")
        file_path = file_manager.create_json_file(prompts, user_id, "basic")
        
        if os.path.exists(file_path):
            file_obj = FSInputFile(file_path)
            await callback_query.message.answer_document(
                document=file_obj,
                caption="💾 JSON файл с базовыми промптами"
            )
            os.remove(file_path)
            
    except Exception as e:
        await callback_query.message.answer(f"❌ Ошибка: {str(e)}")

# ===== ОСТАЛЬНЫЕ CALLBACK ОБРАБОТЧИКИ (без изменений) =====

@router.callback_query(lambda c: c.data == "back_to_basic_list")
async def back_to_basic_list_callback(callback_query):
    await callback_query.answer("🔙 Возвращаемся к списку...")
    
    # Показываем базовые промпты заново
    user_id = callback_query.from_user.id
    subscription_level = "free"
    
    prompts = prompt_manager.get_prompts_by_category("all", subscription_level)
    
    response = "🔓 <b>Базовые промпты (FREE)</b>\n\n"
    
    for i, prompt in enumerate(prompts[:5], 1):
        response += f"{i}. <b>{prompt['title']}</b>\n"
        response += f"📝 {prompt['prompt'][:80]}...\n"
        response += f"🏷️ {' '.join(f'#{tag}' for tag in prompt['tags'][:3])}\n\n"
    
    response += f"📊 <b>Показано:</b> 5 из {len(prompts)} доступных\n\n"
    response += "💡 <b>Как получить полный промпт:</b>\n"
    response += "🎲 Нажмите «Случайный промпт» для получения полного текста с кнопкой копирования\n\n"
    response += "💎 <b>VIP:</b> Доступ ко всем промптам + поиск"
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎲 Случайный промпт", callback_data="random_prompt_basic")],
        [InlineKeyboardButton(text="📥 Скачать базовые", callback_data="download_basic_prompts")],
        [InlineKeyboardButton(text="📱 SMM промпты", callback_data="category_social_media")],
        [InlineKeyboardButton(text="💼 Бизнес промпты", callback_data="category_business")],
        [InlineKeyboardButton(text="💎 Открыть VIP", callback_data="upgrade_vip")]
    ])
    
    await callback_query.message.edit_text(response, reply_markup=kb, parse_mode="HTML")

@router.callback_query(lambda c: c.data == "upgrade_vip")
async def upgrade_vip_callback(callback_query):
    await callback_query.answer("💎 VIP промпты!")
    
    response = "💎 <b>VIP доступ к промптам</b>\n\n"
    response += "🔓 <b>Сейчас у вас:</b>\n"
    response += "• 13 базовых промптов (FREE)\n"
    response += "• Только превью промптов\n"
    response += "• 3 генерации в день\n\n"
    response += "💎 <b>VIP даст:</b>\n"
    response += "• 📋 6 VIP промптов (продвинутые стратегии)\n"
    response += "• 🔍 Поиск промптов по ключевым словам\n"
    response += "• ⭐ Избранные промпты\n"
    response += "• 🤖 15 ИИ-генераций в день\n"
    response += "• 📥 Скачивание промптов в файл\n"
    response += "• 📋 Полный доступ ко всем базовым промптам\n\n"
    response += "⭐ <b>Premium добавит:</b>\n"
    response += "• 🏆 6 Premium промптов (экспертный уровень)\n"
    response += "• 🤖 Безлимитная ИИ-генерация\n"
    response += "• 🎯 Персонализация промптов\n"
    response += "• 💼 Корпоративные функции\n\n"
    response += "💰 <b>Стоимость:</b>\n"
    response += "💎 VIP: 699₽/месяц\n"
    response += "⭐ Premium: 1399₽/месяц\n\n"
    response += "📱 <b>Автоматическое оформление:</b> /buy_vip\n"
    response += "💳 <b>Поддерживаем:</b> карты, СБП, криптовалюта"
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Купить VIP", callback_data="buy_vip_prompt")],
        [InlineKeyboardButton(text="👀 Превью VIP промптов", callback_data="preview_vip")],
        [InlineKeyboardButton(text="👀 Превью Premium промптов", callback_data="preview_premium")],
        [InlineKeyboardButton(text="🔙 К базовым промптам", callback_data="back_to_basic_list")]
    ])
    
    await callback_query.message.edit_text(response, reply_markup=kb, parse_mode="HTML")

@router.callback_query(lambda c: c.data == "upgrade_premium")
async def upgrade_premium_callback(callback_query):
    await callback_query.answer("⭐ Информация о Premium!")
    
    response = "⭐ <b>Premium подписка</b>\n\n"
    response += "🎯 <b>Максимальный функционал:</b>\n"
    response += "• 🎯 Тренды по нишам и отраслям\n"
    response += "• 📱 Анализ вирусных форматов контента\n"
    response += "• 📊 A/B тестирование рекламных кампаний\n"
    response += "• 📈 Аналитика эффективности контента\n"
    response += "• 📈 Трендовые хештеги в реальном времени\n"
    response += "• 📝 ИИ-генератор текстов для Stories\n"
    response += "• 🏆 Брендинговые стратегии\n"
    response += "• 🔍 Конкурентная разведка\n"
    response += "• 🔗 Интеграция с соцсетями\n"
    response += "• ⏰ Автопостинг контента\n"
    response += "• 👥 Командная работа\n"
    response += "• 🤖 Безлимитная ИИ-генерация промптов\n"
    response += "• 💎 Все VIP функции включены\n\n"
    response += "💰 <b>Стоимость:</b> 1399₽/месяц\n"
    response += "⚡ <b>Максимальные возможности!</b>\n\n"
    response += "📱 <b>Автоматическое оформление:</b> /buy_premium\n"
    response += "💳 <b>Поддерживаем:</b> карты, СБП, криптовалюта"
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Купить Premium", callback_data="buy_premium_prompt")],
        [InlineKeyboardButton(text="🔙 Назад к промптам", callback_data="back_to_basic_list")],
        [InlineKeyboardButton(text="💎 Узнать о VIP", callback_data="upgrade_vip")]
    ])
    
    await callback_query.message.edit_text(response, reply_markup=kb, parse_mode="HTML")

# Обработчики кнопок покупки
@router.callback_query(lambda c: c.data == "buy_vip_prompt")
async def buy_vip_prompt_callback(callback_query):
    await callback_query.answer("💳 Переходим к оплате VIP!")
    
    response = "💎 <b>Оформление VIP подписки</b>\n\n"
    response += "💰 <b>VIP: 699₽/месяц</b>\n\n"
    response += "🎁 <b>Что получите сразу:</b>\n"
    response += "• 6 VIP промптов (продвинутые стратегии)\n"
    response += "• Поиск по промптам\n"
    response += "• 15 ИИ-генераций в день\n"
    response += "• Избранные промпты\n"
    response += "• Скачивание в файл\n"
    response += "• Полный доступ к базовым промптам\n\n"
    response += "💳 <b>Способы оплаты:</b>\n"
    response += "• Банковская карта (Visa, MasterCard)\n"
    response += "• СБП (Система Быстрых Платежей)\n"
    response += "• Криптовалюта (BTC, USDT)\n\n"
    response += "📱 <b>Для оплаты введите команду:</b> /buy_vip"
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад", callback_data="upgrade_vip")]
    ])
    
    await callback_query.message.edit_text(response, reply_markup=kb, parse_mode="HTML")

@router.callback_query(lambda c: c.data == "buy_premium_prompt")
async def buy_premium_prompt_callback(callback_query):
    await callback_query.answer("💳 Переходим к оплате Premium!")
    
    response = "⭐ <b>Оформление Premium подписки</b>\n\n"
    response += "💰 <b>Premium: 1399₽/месяц</b>\n\n"
    response += "🎁 <b>Что получите сразу:</b>\n"
    response += "• Все VIP функции (6 VIP промптов)\n"
    response += "• 6 Premium промптов (экспертный уровень)\n"
    response += "• Безлимитная ИИ-генерация\n"
    response += "• Персонализация промптов\n"
    response += "• Приоритетная поддержка 24/7\n"
    response += "• Корпоративные функции\n\n"
    response += "💳 <b>Способы оплаты:</b>\n"
    response += "• Банковская карта (Visa, MasterCard)\n"
    response += "• СБП (Система Быстрых Платежей)\n"
    response += "• Криптовалюта (BTC, USDT)\n"
    response += "• Корпоративный счет\n\n"
    response += "📱 <b>Для оплаты введите команду:</b> /buy_premium"
    
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔙 Назад", callback_data="upgrade_premium")]
    ])
    
    await callback_query.message.edit_text(response, reply_markup=kb, parse_mode="HTML")

# ===== ОСТАЛЬНЫЕ CALLBACK ОБРАБОТЧИКИ =====

@router.callback_query(lambda c: c.data.startswith("random_prompt_"))
async def random_prompt_callback(callback_query):
    prompt_type = callback_query.data.replace("random_prompt_", "")
    user_id = callback_query.from_user.id
    subscription_level = "free"  # Заглушка
    
    # Определяем уровень доступа
    if prompt_type == "basic":
        subscription_needed = "free"
    elif prompt_type == "premium":
        subscription_needed = "vip"
    elif prompt_type == "vip":
        subscription_needed = "premium"
    else:
        subscription_needed = "free"
    
    # Проверяем доступ
    if (subscription_level == "free" and prompt_type in ["premium", "vip"]) or \
       (subscription_level == "vip" and prompt_type == "vip"):
        await callback_query.answer("🔒 Нужна более высокая подписка!", show_alert=True)
        return
    
    # Получаем случайный промпт
    random_prompt = prompt_manager.get_random_prompt("all", subscription_needed)
    
    if random_prompt:
        # Сохраняем промпт для копирования
        user_prompts[user_id] = random_prompt['prompt']
        
        await callback_query.answer("🎲 Случайный промпт!")
        
        response = f"🎲 <b>Случайный промпт:</b>\n\n"
        response += f"📝 <b>{random_prompt['title']}</b>\n\n"
        response += f"{random_prompt['prompt']}\n\n"
        response += f"🏷️ <b>Теги:</b> {' '.join(f'#{tag}' for tag in random_prompt['tags'])}\n"
        response += f"📂 <b>Категория:</b> {random_prompt['category']}"
        
        # Кнопки для действий
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📋 Копировать", callback_data="copy_saved_prompt")],
            [InlineKeyboardButton(text="🎲 Другой промпт", callback_data=f"random_prompt_{prompt_type}")],
            [InlineKeyboardButton(text="🔙 К списку", callback_data="back_to_basic_list")]
        ])
        
        await callback_query.message.edit_text(response, reply_markup=kb, parse_mode="HTML")
    else:
        await callback_query.answer("❌ Промпт не найден")

# ===== НОВЫЕ CALLBACK ОБРАБОТЧИКИ ДЛЯ ИИ-ГЕНЕРАТОРА =====

@router.callback_query(lambda c: c.data.startswith("ai_generate_"))
async def ai_generate_callback(callback_query):
    category = callback_query.data.replace("ai_generate_", "")
    user_id = callback_query.from_user.id
    subscription_level = "free"  # Заглушка
    
    # Обработка случайной категории
    if category == "random":
        categories = ["creative", "business", "marketing", "copywriting", "smm"]
        category = random.choice(categories)
    
    await callback_query.answer("🤖 Генерирую промпт...")
    
    # Показываем процесс генерации
    loading_message = await callback_query.message.edit_text(
        f"🤖 <b>Генерация промпта...</b>\n\n"
        f"📂 Категория: {category.title()}\n"
        f"⚙️ Обработка запроса...\n"
        f"✨ Это займет несколько секунд",
        parse_mode="HTML"
    )
    
    try:
        # Генерируем промпт
        result = await ai_prompt_generator.generate_prompt(
            category=category,
            subscription_level=subscription_level
        )
        
        if "error" in result:
            # Показываем ошибку с предложением апгрейда
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="💎 Открыть VIP", callback_data="upgrade_vip")]
            ])
            
            await loading_message.edit_text(
                f"🔒 <b>Лимит исчерпан</b>\n\n"
                f"❌ {result['error']}\n\n"
                f"💎 <b>VIP подписка даст:</b>\n"
                f"• 15 генераций в день\n"
                f"• ИИ-генерация промптов\n"
                f"• Персонализация по темам\n"
                f"• Приоритетная обработка",
                reply_markup=kb,
                parse_mode="HTML"
            )
            return
        
        # СОХРАНЯЕМ ПРОМПТ ДЛЯ КОПИРОВАНИЯ
        user_prompts[user_id] = result['prompt']
        
        # Формируем ответ
        response = f"🎲 <b>{result['title']}</b>\n\n"
        response += f"📝 <b>Промпт:</b>\n{result['prompt']}\n\n"
        response += f"🏷️ <b>Теги:</b> {' '.join(f'#{tag}' for tag in result['tags'])}\n"
        response += f"📂 <b>Категория:</b> {result['category']}\n"
        response += f"🤖 <b>Источник:</b> {result['source']}"
        
        # Кнопки для действий
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔄 Еще один", callback_data=f"ai_generate_{category}")],
            [InlineKeyboardButton(text="📋 Копировать", callback_data="copy_saved_prompt")],
            [InlineKeyboardButton(text="⭐ В избранное", callback_data="fav_prompt")]
        ])
        
        await loading_message.edit_text(response, reply_markup=kb, parse_mode="HTML")
        
    except Exception as e:
        await loading_message.edit_text(
            f"❌ <b>Ошибка генерации</b>\n\n"
            f"Произошла ошибка: {str(e)}\n"
            f"Попробуйте еще раз через минуту.",
            parse_mode="HTML"
        )

# ===== ОСТАЛЬНЫЕ CALLBACK ОБРАБОТЧИКИ =====

@router.callback_query(lambda c: c.data.startswith("category_"))
async def category_callback(callback_query):
    category = callback_query.data.replace("category_", "")
    user_id = callback_query.from_user.id
    subscription_level = "free"  # Заглушка
    
    # Получаем промпты по категории
    prompts = prompt_manager.get_prompts_by_category(category, subscription_level)
    
    if prompts:
        await callback_query.answer("📂 Категория загружена!")
        
        category_names = {
            "social_media": "📱 SMM",
            "business": "💼 Бизнес"
        }
        
        response = f"{category_names.get(category, category)} <b>промпты:</b>\n\n"
        
        for i, prompt in enumerate(prompts[:8], 1):
            response += f"{i}. <b>{prompt['title']}</b>\n"
            response += f"📝 {prompt['prompt'][:60]}...\n\n"
        
        if len(prompts) > 8:
            response += f"📊 <b>Показано:</b> 8 из {len(prompts)}\n"
            response += "💎 <b>VIP:</b> Полный доступ ко всем промптам"
        
        await callback_query.message.edit_text(response, parse_mode="HTML")
    else:
        await callback_query.answer("❌ Промпты не найдены")

@router.callback_query(lambda c: c.data.startswith("preview_"))
async def preview_callback(callback_query):
    preview_type = callback_query.data.replace("preview_", "")
    
    if preview_type == "premium":
        response = "⭐ <b>Premium промпты - Превью</b>\n\n"
        response += "🎯 <b>Пример:</b> 'Вирусная кампания'\n"
        response += "📝 Создай концепцию вирусной кампании для [ПРОДУКТ]. Разработай основную идею, крючок для распространения, механику участия...\n\n"
        response += "🏆 <b>Это лишь начало промпта!</b>\n"
        response += "💎 <b>Полная версия:</b> 300+ слов детального описания\n"
        response += "⭐ <b>Premium:</b> 50+ таких промптов"
        
    elif preview_type == "vip":
        response = "💎 <b>VIP промпты - Эксклюзивное превью</b>\n\n"
        response += "🧠 <b>Пример:</b> 'Blue Ocean стратегия'\n"
        response += "📝 Примени концепцию Blue Ocean Strategy для создания нового рыночного пространства в индустрии [ИНДУСТРИЯ]...\n\n"
        response += "🎯 <b>Это элитный уровень!</b>\n"
        response += "💎 <b>Полная версия:</b> 500+ слов экспертного контента\n"
        response += "🔥 <b>VIP:</b> 100+ эксклюзивных промптов"
    
    await callback_query.answer("👀 Превью показано!")
    await callback_query.message.edit_text(response, parse_mode="HTML")

@router.callback_query(lambda c: c.data == "copy_saved_prompt")
async def copy_saved_prompt_callback(callback_query):
    user_id = callback_query.from_user.id
    
    if user_id in user_prompts:
        prompt_text = user_prompts[user_id]
        
        await callback_query.answer("📋 Отправляю промпт для копирования!")
        
        # Отправляем промпт как отдельное сообщение
        await callback_query.message.answer(
            f"📋 <b>Промпт для копирования:</b>\n\n"
            f"{prompt_text}",
            parse_mode="HTML"
        )
        
        # Отправляем инструкцию
        await callback_query.message.answer(
            "💡 <b>Как использовать:</b>\n"
            "1️⃣ Выделите текст промпта выше\n"
            "2️⃣ Скопируйте (Ctrl+C или долгое нажатие)\n"
            "3️⃣ Вставьте в ChatGPT, Claude или другой ИИ\n"
            "4️⃣ Замените [...] на свои данные\n\n"
            "✨ <b>Готово к использованию!</b>"
        )
        
    else:
        await callback_query.answer("❌ Промпт не найден! Сгенерируйте новый.")

@router.callback_query(lambda c: c.data == "back_to_generator")
async def back_to_generator_callback(callback_query):
    await callback_query.answer("🔙 Возвращаемся...")
    await ai_prompt_generator_menu(callback_query.message)

@router.callback_query(lambda c: c.data == "copy_prompt")
async def copy_prompt_callback(callback_query):
    await callback_query.answer("📋 Промпт готов к копированию!")
    
    response = "📋 <b>Промпт скопирован!</b>\n\n"
    response += "✅ Промпт готов к использованию\n"
    response += "💡 Просто замените [...] на свои данные\n"
    response += "🚀 Используйте в ChatGPT, Claude или других ИИ"
    
    await callback_query.message.edit_text(response, parse_mode="HTML")

@router.callback_query(lambda c: c.data == "fav_prompt")
async def favorite_prompt_callback(callback_query):
    user_id = callback_query.from_user.id
    subscription_level = "free"  # Заглушка
    
    if subscription_level == "free":
        await callback_query.answer("💎 Избранное доступно с VIP подпиской!", show_alert=True)
        return
    
    await callback_query.answer("⭐ Добавлено в избранное!")
    
    response = "⭐ <b>Промпт добавлен в избранное!</b>\n\n"
    response += "📚 Найти в разделе 'Мои промпты'\n"
    response += "🔍 Доступен через поиск\n"
    response += "📱 Быстрый доступ к лучшим промптам"
    
    await callback_query.message.edit_text(response, parse_mode="HTML")

@router.callback_query(lambda c: c.data == "search_prompts")
async def search_prompts_callback(callback_query):
    user_id = callback_query.from_user.id
    subscription_level = "free"  # Заглушка
    
    if subscription_level == "free":
        await callback_query.answer("🔍 Поиск доступен с VIP подпиской!", show_alert=True)
        return
    
    await callback_query.answer("🔍 Функция поиска в разработке!")
    
    response = "🔍 <b>Поиск промптов</b>\n\n"
    response += "⏳ <b>Функция в разработке!</b>\n\n"
    response += "🎯 <b>Скоро будет доступно:</b>\n"
    response += "• Поиск по ключевым словам\n"
    response += "• Фильтрация по категориям\n"
    response += "• Поиск по тегам\n"
    response += "• Сохранение избранных"
    
    await callback_query.message.edit_text(response, parse_mode="HTML")

# Обработка старых callback'ов для совместимости
@router.callback_query(lambda c: c.data.startswith("generate_"))
async def old_generate_callback(callback_query):
    """Перенаправление старых генераторов на новые"""
    old_category = callback_query.data.replace("generate_", "")
    
    category_mapping = {
        "creative": "creative",
        "business": "business", 
        "marketing": "marketing",
        "random": "random"
    }
    
    new_category = category_mapping.get(old_category, "creative")
    callback_query.data = f"ai_generate_{new_category}"
    await ai_generate_callback(callback_query)