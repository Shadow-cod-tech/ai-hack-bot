# handlers/tools.py
from aiogram import Router
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
import random
from services.smm_tools import SMMToolsManager

router = Router()

# Создаем глобальный экземпляр SMM менеджера
smm_manager = SMMToolsManager()

# Обработчики SMM инструментов
@router.message(lambda message: message.text == "📊 SMM Анализ")
async def smm_analysis_handler(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔵 ВКонтакте", callback_data="analyze_vk")],
        [InlineKeyboardButton(text="✈️ Telegram", callback_data="analyze_telegram")]
    ])
    
    await message.answer(
        "📊 <b>SMM Анализ</b>\n\n"
        "🔍 <b>Что анализируем:</b>\n"
        "• Эффективность постов и метрики\n"
        "• Рост аудитории и вовлеченность\n"
        "• Лучшее время публикаций\n"
        "• Рекомендации по улучшению\n\n"
        "📱 <b>Выберите платформу:</b>",
        reply_markup=kb,
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "📈 Трендовый анализ")
async def trend_analysis_handler(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔥 Топ хештеги", callback_data="trend_hashtags")],
        [InlineKeyboardButton(text="📱 Вирусные форматы", callback_data="trend_formats")],
        [InlineKeyboardButton(text="🎯 Тренды по нишам", callback_data="trend_niches")],
        [InlineKeyboardButton(text="📅 Сезонные тренды", callback_data="trend_seasonal")]
    ])
    
    await message.answer(
        "📈 <b>Трендовый анализ</b>\n\n"
        "🔥 <b>Отслеживаем актуальные тренды:</b>\n"
        "• Популярные хештеги и темы\n"
        "• Вирусные форматы контента\n"
        "• Сезонные и праздничные тренды\n"
        "• Региональные особенности\n\n"
        "📊 <b>Выберите тип анализа:</b>",
        reply_markup=kb,
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "🎯 Таргетинг помощь")
async def targeting_help_handler(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👥 Настройка аудитории", callback_data="target_audience")],
        [InlineKeyboardButton(text="💰 Бюджет и ставки", callback_data="target_budget")],
        [InlineKeyboardButton(text="🎨 Креативы", callback_data="target_creatives")],
        [InlineKeyboardButton(text="📊 A/B тестирование", callback_data="target_testing")]
    ])
    
    await message.answer(
        "🎯 <b>Таргетинг помощь</b>\n\n"
        "🚀 <b>Поможем настроить эффективную рекламу:</b>\n"
        "• Точная настройка целевой аудитории\n"
        "• Оптимизация бюджета и ставок\n"
        "• A/B тестирование креативов\n"
        "• Анализ и улучшение результатов\n\n"
        "⚙️ <b>Выберите этап настройки:</b>",
        reply_markup=kb,
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "📝 Контент планер")
async def content_planner_handler(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📅 Календарь контента", callback_data="content_calendar")],
        [InlineKeyboardButton(text="💡 Идеи для постов", callback_data="content_ideas")],
        [InlineKeyboardButton(text="🎨 Визуальный план", callback_data="content_visual")],
        [InlineKeyboardButton(text="📊 Аналитика контента", callback_data="content_analytics")]
    ])
    
    await message.answer(
        "📝 <b>Контент планер</b>\n\n"
        "📅 <b>Планируем контент стратегически:</b>\n"
        "• Календарь публикаций на месяц\n"
        "• Тематические серии постов\n"
        "• Праздничный и сезонный контент\n"
        "• Кросс-постинг между платформами\n\n"
        "🎯 <b>Выберите функцию планирования:</b>",
        reply_markup=kb,
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "#️⃣ Генератор хештегов")
async def hashtag_generator_handler(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🔥 Популярные теги", callback_data="hashtag_popular")],
        [InlineKeyboardButton(text="🎯 Нишевые теги", callback_data="hashtag_niche")],
        [InlineKeyboardButton(text="🌍 Локальные теги", callback_data="hashtag_local")],
        [InlineKeyboardButton(text="📈 Трендовые теги", callback_data="hashtag_trending")]
    ])
    
    await message.answer(
        "#️⃣ <b>Генератор хештегов</b>\n\n"
        "🏷️ <b>Подбираем идеальные хештеги:</b>\n"
        "• Популярные и трендовые теги\n"
        "• Нишевые хештеги по тематике\n"
        "• Локальные теги для региона\n"
        "• Анализ эффективности тегов\n\n"
        "🎯 <b>Выберите тип хештегов:</b>",
        reply_markup=kb,
        parse_mode="HTML"
    )

@router.message(lambda message: message.text == "📱 Креативы для Stories")
async def stories_creatives_handler(message: Message):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🎨 Шаблоны дизайна", callback_data="stories_templates")],
        [InlineKeyboardButton(text="📊 Интерактивы", callback_data="stories_interactive")],
        [InlineKeyboardButton(text="🎬 Видео шаблоны", callback_data="stories_video")],
        [InlineKeyboardButton(text="📝 Текстовые посты", callback_data="stories_text")]
    ])
    
    await message.answer(
        "📱 <b>Креативы для Stories</b>\n\n"
        "🎨 <b>Создаем эффектные истории:</b>\n"
        "• Готовые шаблоны и макеты\n"
        "• Интерактивные элементы (опросы, вопросы)\n"
        "• Анимированные стикеры и GIF\n"
        "• Брендированные элементы дизайна\n\n"
        "✨ <b>Выберите тип креатива:</b>",
        reply_markup=kb,
        parse_mode="HTML"
    )

# ===== CALLBACK ОБРАБОТЧИКИ С РЕАЛЬНОЙ ЛОГИКОЙ =====

# SMM Анализ callbacks - в разработке
@router.callback_query(lambda c: c.data.startswith("analyze_"))
async def process_analyze_callback(callback_query):
    platform = callback_query.data.replace("analyze_", "")
    
    # Словарь для отображения названий платформ
    platform_names = {
        "vk": "ВКонтакте",
        "telegram": "Telegram"
    }
    
    platform_display = platform_names.get(platform, platform)
    
    # Показываем статус "В разработке"
    await callback_query.message.edit_text(
        f"🔵 <b>Анализ {platform_display}</b>\n\n"
        f"⏳ <b>Функция в разработке</b>\n\n"
        f"🚧 Скоро будет доступно:\n"
        f"• Анализ подписчиков и активности\n"
        f"• Статистика постов и вовлеченности\n" 
        f"• Рекомендации по улучшению\n"
        f"• Сравнение с конкурентами\n\n"
        f"🔔 <b>Уведомим о запуске!</b>",
        parse_mode="HTML"
    )
    await callback_query.answer("🚧 В разработке!")

# Трендовый анализ callbacks - с проверкой подписки!
@router.callback_query(lambda c: c.data.startswith("trend_"))
async def process_trend_callback(callback_query):
    trend_type = callback_query.data.replace("trend_", "")
    user_id = callback_query.from_user.id
    
    # Проверяем уровень доступа (пока заглушка, потом добавим реальную проверку)
    user_subscription = "free"  # Заглушка: free, vip, premium
    
    # 🔥 Топ хештеги - FREE
    if trend_type == "hashtags":
        await callback_query.answer("🔄 Анализируем тренды...")
        
        try:
            hashtags_data = await smm_manager.trend_analyzer.get_trending_hashtags("general")
            
            response = "🔥 <b>Топ хештеги сегодня (FREE):</b>\n\n"
            # Ограничиваем для FREE пользователей
            hashtags_limit = 5 if user_subscription == "free" else 10
            for hashtag, stats in list(hashtags_data['trending_hashtags'].items())[:hashtags_limit]:
                response += f"{hashtag} ({stats['posts_count']:,} постов)\n"
            
            if user_subscription == "free":
                response += f"\n💎 <b>VIP:</b> +5 хештегов, обновления каждый час"
            
            response += f"\n📈 <b>Обновлено:</b> {hashtags_data['updated']}"
            
        except Exception as e:
            response = "❌ Ошибка получения трендов. Попробуйте позже."
    
    # 📅 Сезонные тренды - VIP
    elif trend_type == "seasonal":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "📅 <b>Сезонные тренды</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n✨ <b>Что получите:</b>\n• Праздничные тренды\n• Сезонная аналитика\n• Актуальные события\n• Региональные особенности"
        else:
            await callback_query.answer("🔄 Анализируем сезонные тренды...")
            response = "📅 <b>Сезонные тренды (VIP):</b>\n\n❄️ Зимние активности (+67%)\n🎄 Новогодние акции (+89%)\n💝 Подарочные идеи (+156%)\n🏂 Зимний спорт (+34%)\n🎭 Праздничные мероприятия (+78%)"
    
    # 🎯 Тренды по нишам - PREMIUM  
    elif trend_type == "niches":
        if user_subscription in ["free", "vip"]:
            await callback_query.answer("⭐ Доступно только в Premium!", show_alert=True)
            response = "🎯 <b>Тренды по нишам</b>\n\n⭐ <b>Premium функция</b>\n\n🔒 Для доступа нужна Premium подписка\n\n🚀 <b>Что получите:</b>\n• Глубокая аналитика по отраслям\n• Персональные рекомендации\n• Тренды конкурентов\n• Прогнозы развития"
        else:
            await callback_query.answer("🔄 Анализируем нишевые тренды...")
            response = "🎯 <b>Тренды по нишам (Premium):</b>\n\n💼 Бизнес: личный бренд (+34%)\n🍔 Еда: здоровое питание (+28%)\n🏃 Фитнес: домашние тренировки (+45%)\n🎨 Дизайн: минимализм (+56%)\n💻 IT: ИИ и автоматизация (+89%)"
    
    # 📱 Вирусные форматы - PREMIUM
    elif trend_type == "formats":
        if user_subscription in ["free", "vip"]:
            await callback_query.answer("⭐ Доступно только в Premium!", show_alert=True)
            response = "📱 <b>Вирусные форматы</b>\n\n⭐ <b>Premium функция</b>\n\n🔒 Для доступа нужна Premium подписка\n\n🔥 <b>Что получите:</b>\n• Анализ вирусного контента\n• Лучшие форматы по платформам\n• ИИ-рекомендации\n• Прогноз трендов"
        else:
            await callback_query.answer("🔄 Анализируем вирусные форматы...")
            try:
                formats_data = await smm_manager.trend_analyzer.analyze_content_formats()
                
                response = "📱 <b>Вирусные форматы (Premium):</b>\n\n"
                for format_name, stats in formats_data['formats_performance'].items():
                    emoji = "🔥" if float(stats['growth'].replace('%', '').replace('+', '')) > 20 else "📊"
                    response += f"{emoji} {format_name}: {stats['growth']} роста\n"
                
                response += f"\n🏆 <b>Лучший формат:</b> {formats_data['best_format']}"
            except Exception as e:
                response = "❌ Ошибка получения данных. Попробуйте позже."
    
    else:
        response = "📈 Анализ трендов в процессе..."
    
    await callback_query.message.edit_text(response, parse_mode="HTML")

# Контент планер callbacks - с системой ограничений и улучшенной генерацией!
@router.callback_query(lambda c: c.data.startswith("content_"))
async def process_content_callback(callback_query):
    content_type = callback_query.data.replace("content_", "")
    user_id = callback_query.from_user.id
    
    # Проверяем уровень доступа (пока заглушка)
    user_subscription = "free"  # Заглушка: free, vip, premium
    
    # 📅 Календарь контента - FREE (ограниченно) / VIP (полный)
    if content_type == "calendar":
        await callback_query.answer("📅 Генерируем план...")
        
        try:
            # Ограничиваем количество дней для FREE пользователей
            days_limit = 3 if user_subscription == "free" else 7
            calendar_data = await smm_manager.content_planner.generate_content_calendar(days_limit)
            
            if user_subscription == "free":
                response = "📅 <b>Календарь на 3 дня (FREE):</b>\n\n"
            else:
                response = "📅 <b>Календарь на неделю (VIP+):</b>\n\n"
            
            for date, day_data in list(calendar_data['calendar'].items()):
                day_name = day_data['day'][:3]  # Сокращенное название дня
                optimal_times = ", ".join(day_data['optimal_times'])
                theme = day_data['focus_theme']
                
                response += f"📱 <b>{day_name}:</b> {theme}\n"
                response += f"⏰ Время: {optimal_times}\n\n"
            
            response += f"📊 <b>Всего постов:</b> {calendar_data['total_posts_planned']}"
            
            if user_subscription == "free":
                response += f"\n\n💎 <b>VIP:</b> Полный месяц + персональные рекомендации"
            
        except Exception as e:
            response = "❌ Ошибка генерации плана. Попробуйте позже."
    
    # 💡 Идеи для постов - VIP
    elif content_type == "ideas":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "💡 <b>Идеи для постов</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n✨ <b>Что получите:</b>\n• 50+ готовых идей контента\n• Конкретные темы по нишам\n• Хештеги к каждой идее\n• Примеры текстов"
        else:
            await callback_query.answer("💡 Генерируем идеи...")
            
            # Улучшенная генерация конкретных идей
            content_ideas = [
                {"title": "5 ошибок в Instagram Stories", "format": "карусель", "hashtags": "#stories #ошибки #smm"},
                {"title": "Мой рабочий день: таймлапс", "format": "реелс", "hashtags": "#рабочийдень #таймлапс #работа"},
                {"title": "Какой цвет ассоциируется с вашим брендом?", "format": "опрос", "hashtags": "#бренд #цвета #опрос"},
                {"title": "До/После: результаты клиента", "format": "пост", "hashtags": "#результаты #доипосле #кейс"},
                {"title": "3 тренда в дизайне 2025", "format": "карусель", "hashtags": "#тренды #дизайн #2025"},
                {"title": "Отвечаю на ваши вопросы", "format": "видео", "hashtags": "#вопросы #ответы #прямой_эфир"},
                {"title": "Секреты продуктивности", "format": "пост", "hashtags": "#продуктивность #советы #лайфхаки"}
            ]
            
            response = "💡 <b>Идеи для постов (VIP):</b>\n\n"
            for i, idea in enumerate(content_ideas[:5], 1):
                response += f"{i}. <b>{idea['title']}</b> ({idea['format']})\n"
                response += f"   {idea['hashtags']}\n\n"
            
            response += "✨ <b>+45 идей в полной версии</b>"
    
    # 🎨 Визуальный план - VIP  
    elif content_type == "visual":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "🎨 <b>Визуальный план</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n🎨 <b>Что получите:</b>\n• Цветовые схемы\n• Готовые шаблоны\n• План съемок\n• Брендинг контента"
        else:
            await callback_query.answer("🎨 Создаем визуальный план...")
            response = "🎨 <b>Визуальный план (VIP):</b>\n\n🎨 Цветовая схема: синий (#1DA1F2) + белый\n📱 Шаблоны: 5 готовых макетов для Stories\n📸 План съемок: 3 фотосессии в месяц\n🖼️ Стиль: минимализм + акценты\n📊 Соотношение: 60% фото, 40% графика\n\n✅ План готов к использованию"
    
    # 📊 Аналитика контента - PREMIUM
    elif content_type == "analytics":
        if user_subscription in ["free", "vip"]:
            await callback_query.answer("⭐ Доступно только в Premium!", show_alert=True)
            response = "📊 <b>Аналитика контента</b>\n\n⭐ <b>Premium функция</b>\n\n🔒 Для доступа нужна Premium подписка\n\n📈 <b>Что получите:</b>\n• Анализ эффективности постов\n• Лучшее время публикации\n• Топ-контент по вовлеченности\n• Рекомендации по улучшению"
        else:
            await callback_query.answer("📊 Анализируем контент...")
            response = "📊 <b>Аналитика контента (Premium):</b>\n\n📈 Лучшие посты: карусели (+67% вовлеченности)\n⏰ Оптимальное время: 18:00-20:00 (пн-ср)\n💬 Больше комментариев: вопросы к аудитории\n📱 Топ-формат: короткие видео до 30 сек\n🔥 Растущий тренд: behind the scenes\n\n💡 Рекомендация: больше интерактива в Stories"
    
    else:
        response = "📝 Планирование контента..."
    
    await callback_query.message.edit_text(
        response + "\n\n💾 <b>План сохранен</b>",
        parse_mode="HTML"
    )

# Генератор хештегов callbacks - с системой ограничений!
@router.callback_query(lambda c: c.data.startswith("hashtag_"))
async def process_hashtag_callback(callback_query):
    hashtag_type = callback_query.data.replace("hashtag_", "")
    user_id = callback_query.from_user.id
    
    # Проверяем уровень доступа (пока заглушка)
    user_subscription = "free"  # Заглушка: free, vip, premium
    
    # 🔥 Популярные теги - FREE (ограниченно)
    if hashtag_type == "popular":
        await callback_query.answer("🏷️ Генерируем хештеги...")
        
        try:
            # Ограничиваем количество хештегов для FREE
            hashtags_count = 10 if user_subscription == "free" else 30
            hashtags_data = await smm_manager.hashtag_generator.generate_hashtags(
                category=hashtag_type, 
                topic="", 
                count=hashtags_count
            )
            
            response = f"🔥 <b>Популярные хештеги (FREE):</b>\n\n"
            
            # Группируем хештеги по 5 в строке для компактности
            hashtags = hashtags_data['hashtags']
            for i in range(0, min(len(hashtags), hashtags_count), 5):
                group = hashtags[i:i+5]
                response += " ".join(group) + "\n"
            
            response += f"\n📊 <b>Охват:</b> {hashtags_data['estimated_reach']}\n"
            response += f"🎯 <b>Конкуренция:</b> {hashtags_data['competition_level']}\n"
            response += f"📈 <b>Количество:</b> {len(hashtags)} тегов"
            
            if user_subscription == "free":
                response += f"\n\n💎 <b>VIP:</b> +20 хештегов, нишевые и локальные теги"
                
        except Exception as e:
            response = "❌ Ошибка генерации хештегов. Попробуйте позже."
    
    # 🎯 Нишевые теги - VIP
    elif hashtag_type == "niche":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "🎯 <b>Нишевые хештеги</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n✨ <b>Что получите:</b>\n• Хештеги по 50+ нишам\n• Низкоконкурентные теги\n• Специализированные сообщества\n• Обновления каждую неделю"
        else:
            await callback_query.answer("🎯 Генерируем нишевые хештеги...")
            try:
                hashtags_data = await smm_manager.hashtag_generator.generate_hashtags(
                    category=hashtag_type, 
                    topic="", 
                    count=25
                )
                
                response = f"🎯 <b>Нишевые хештеги (VIP):</b>\n\n"
                
                hashtags = hashtags_data['hashtags']
                for i in range(0, min(len(hashtags), 25), 5):
                    group = hashtags[i:i+5]
                    response += " ".join(group) + "\n"
                
                response += f"\n📊 <b>Охват:</b> {hashtags_data['estimated_reach']}\n"
                response += f"🎯 <b>Конкуренция:</b> {hashtags_data['competition_level']}\n"
                response += f"💡 <b>Особенность:</b> Специализированные сообщества"
                
            except Exception as e:
                response = "❌ Ошибка генерации хештегов. Попробуйте позже."
    
    # 🌍 Локальные теги - VIP
    elif hashtag_type == "local":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "🌍 <b>Локальные хештеги</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n🗺️ <b>Что получите:</b>\n• Геолокационные теги\n• Региональные сообщества\n• Местные события\n• Городские хештеги"
        else:
            await callback_query.answer("🌍 Генерируем локальные хештеги...")
            try:
                hashtags_data = await smm_manager.hashtag_generator.generate_hashtags(
                    category=hashtag_type, 
                    topic="", 
                    count=20
                )
                
                response = f"🌍 <b>Локальные хештеги (VIP):</b>\n\n"
                
                hashtags = hashtags_data['hashtags']
                for i in range(0, min(len(hashtags), 20), 5):
                    group = hashtags[i:i+5]
                    response += " ".join(group) + "\n"
                
                response += f"\n📍 <b>Регион:</b> Москва и область\n"
                response += f"🎯 <b>Аудитория:</b> Локальная\n"
                response += f"💡 <b>Преимущество:</b> Меньше конкуренции"
                
            except Exception as e:
                response = "❌ Ошибка генерации хештегов. Попробуйте позже."
    
    # 📈 Трендовые теги - PREMIUM
    elif hashtag_type == "trending":
        if user_subscription in ["free", "vip"]:
            await callback_query.answer("⭐ Доступно только в Premium!", show_alert=True)
            response = "📈 <b>Трендовые хештеги</b>\n\n⭐ <b>Premium функция</b>\n\n🔒 Для доступа нужна Premium подписка\n\n🔥 <b>Что получите:</b>\n• Хештеги в реальном времени\n• Вирусные теги недели\n• Предсказание трендов\n• Первыми узнаете о новых тегах"
        else:
            await callback_query.answer("📈 Анализируем трендовые хештеги...")
            try:
                hashtags_data = await smm_manager.hashtag_generator.generate_hashtags(
                    category=hashtag_type, 
                    topic="", 
                    count=15
                )
                
                response = f"📈 <b>Трендовые хештеги (Premium):</b>\n\n"
                
                hashtags = hashtags_data['hashtags']
                for i in range(0, min(len(hashtags), 15), 5):
                    group = hashtags[i:i+5]
                    response += " ".join(group) + "\n"
                
                response += f"\n🔥 <b>Тренд:</b> Растут последние 48 часов\n"
                response += f"📊 <b>Прогноз:</b> +340% роста на неделе\n"
                response += f"⚡ <b>Статус:</b> Вирусные прямо сейчас"
                
            except Exception as e:
                response = "❌ Ошибка генерации хештегов. Попробуйте позже."
    
    else:
        response = "🏷️ Генерация хештегов..."
    
    await callback_query.message.edit_text(
        response + "\n\n📋 <b>Готово к копированию</b>",
        parse_mode="HTML"
    )

# Остальные callbacks (таргетинг с ограничениями)
@router.callback_query(lambda c: c.data.startswith("target_"))
async def process_target_callback(callback_query):
    target_type = callback_query.data.replace("target_", "")
    user_id = callback_query.from_user.id
    
    # Проверяем уровень доступа (пока заглушка)
    user_subscription = "free"  # Заглушка: free, vip, premium
    
    # 💰 Бюджет и ставки - FREE
    if target_type == "budget":
        await callback_query.answer("📊 Рассчитываем бюджет...")
        response = "💰 <b>Бюджет и ставки (FREE):</b>\n\n📊 Рекомендуемый бюджет: 1000₽/день\n💸 CPC: 15-25₽\n📈 CPM: 150-300₽\n🎯 Прогноз: 40-60 кликов/день\n\n💎 <b>VIP:</b> Персональный калькулятор + оптимизация"
    
    # 👥 Настройка аудитории - VIP
    elif target_type == "audience":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "👥 <b>Настройка аудитории</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n✨ <b>Что получите:</b>\n• Конструктор аудитории\n• Расчет охвата\n• Сегментация по интересам\n• Сохранение настроек"
        else:
            await callback_query.answer("🎯 Настраиваем аудиторию...")
            response = "👥 <b>Настройка аудитории (VIP):</b>\n\n🎯 Демография: женщины 25-35 лет\n📍 География: Москва + область\n💼 Интересы: красота, мода, lifestyle\n📊 Охват: 847,000 человек\n💰 Стоимость: 18₽ за клик\n\n✅ Настройки сохранены"
    
    # 🎨 Креативы - VIP
    elif target_type == "creatives":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "🎨 <b>Креативы</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n🎨 <b>Что получите:</b>\n• Шаблоны креативов\n• Генератор текстов\n• Советы по дизайну\n• Библиотека примеров"
        else:
            await callback_query.answer("🎨 Генерируем креативы...")
            response = "🎨 <b>Креативы (VIP):</b>\n\n📱 Формат: карусель 1080x1080\n📝 Заголовок: 'Скидка 30% на все!'\n🎯 Текст: 'Только сегодня специальные цены'\n🔗 CTA: 'Купить сейчас'\n📊 Прогноз CTR: 2.1-2.8%\n\n✅ Креатив готов к запуску"
    
    # 📊 A/B тестирование - PREMIUM
    elif target_type == "testing":
        if user_subscription in ["free", "vip"]:
            await callback_query.answer("⭐ Доступно только в Premium!", show_alert=True)
            response = "📊 <b>A/B тестирование</b>\n\n⭐ <b>Premium функция</b>\n\n🔒 Для доступа нужна Premium подписка\n\n🧪 <b>Что получите:</b>\n• Планировщик тестов\n• Статистическая значимость\n• Автоматические выводы\n• Оптимизация по результатам"
        else:
            await callback_query.answer("🧪 Настраиваем A/B тест...")
            response = "📊 <b>A/B тестирование (Premium):</b>\n\n🎯 Тест: 2 версии креатива\n👥 Группа A: 1000 показов\n👥 Группа B: 1000 показов\n📊 Текущий CTR: A=2.1%, B=2.8%\n🏆 Победитель: вариант B\n📈 Уверенность: 95%\n\n✅ Тест завершен, масштабируем B"
    
    else:
        response = "🎯 Настройка таргетинга..."
    
    await callback_query.message.edit_text(
        response + "\n\n💡 <b>Настройки применены</b>",
        parse_mode="HTML"
    )

@router.callback_query(lambda c: c.data.startswith("stories_"))
async def process_stories_callback(callback_query):
    stories_type = callback_query.data.replace("stories_", "")
    user_id = callback_query.from_user.id
    
    # Проверяем уровень доступа (пока заглушка)
    user_subscription = "free"  # Заглушка: free, vip, premium
    
    # 🎨 Шаблоны дизайна - FREE (ограниченно)
    if stories_type == "templates":
        await callback_query.answer("🎨 Загружаем шаблоны...")
        
        if user_subscription == "free":
            response = "🎨 <b>Шаблоны дизайна (FREE):</b>\n\n📱 <b>Базовые шаблоны:</b>\n• Минимализм: белый фон + один акцент\n• Текст на цвете: градиент + белый текст\n• Фото + рамка: простая белая рамка\n\n💎 <b>VIP:</b> +15 премиум шаблонов, анимации"
        else:
            response = "🎨 <b>Шаблоны дизайна (VIP+):</b>\n\n📱 <b>Премиум коллекция:</b>\n• Минимализм: 5 вариантов\n• Яркие: градиенты + неон\n• Бизнес: строгий + инфографика\n• Креатив: необычные формы\n• Сезонные: праздничные темы\n\n✨ Всего 18 шаблонов доступно"
    
    # 📊 Интерактивы - VIP
    elif stories_type == "interactive":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "📊 <b>Интерактивы</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n🎯 <b>Что получите:</b>\n• Готовые опросы и викторины\n• Шаблоны вопросов\n• Слайдеры и стикеры\n• Игры для аудитории"
        else:
            await callback_query.answer("📊 Генерируем интерактивы...")
            response = "📊 <b>Интерактивы (VIP):</b>\n\n🎯 <b>Готовые форматы:</b>\n📋 Опросы: 'Да/Нет', 'Это или То'\n❓ Вопросы: 'Спроси меня что угодно'\n📊 Викторины: 'Угадай правильный ответ'\n🎯 Слайдер: 'Оцени от 1 до 10'\n🎮 Игры: 'Правда или ложь'\n\n💡 <b>Бонус:</b> Готовые тексты для каждого формата"
    
    # 🎬 Видео шаблоны - VIP
    elif stories_type == "video":
        if user_subscription == "free":
            await callback_query.answer("💎 Доступно только в VIP!", show_alert=True)
            response = "🎬 <b>Видео шаблоны</b>\n\n💎 <b>VIP функция</b>\n\n🔒 Для доступа нужна VIP подписка\n\n🎥 <b>Что получите:</b>\n• Готовые сценарии видео\n• Таймлапс идеи\n• Бумеранг концепции\n• Музыкальные треки"
        else:
            await callback_query.answer("🎬 Создаем видео шаблоны...")
            response = "🎬 <b>Видео шаблоны (VIP):</b>\n\n🎥 <b>Популярные форматы:</b>\n⏱️ Таймлапс: рабочий процесс (15-30 сек)\n🔄 Бумеранг: эффектные движения\n🎵 Под музыку: трендовые треки\n📱 Переходы: смена локаций/образов\n🎭 До/После: результаты работы\n\n🎶 <b>Бонус:</b> Подборка трендовых треков"
    
    # 📝 Текстовые посты - PREMIUM
    elif stories_type == "text":
        if user_subscription in ["free", "vip"]:
            await callback_query.answer("⭐ Доступно только в Premium!", show_alert=True)
            response = "📝 <b>Текстовые посты</b>\n\n⭐ <b>Premium функция</b>\n\n🔒 Для доступа нужна Premium подписка\n\n✍️ <b>Что получите:</b>\n• ИИ-генератор текстов\n• 500+ готовых цитат\n• Персональные посты\n• Автоадаптация под бренд"
        else:
            await callback_query.answer("📝 Генерируем тексты...")
            response = "📝 <b>Текстовые посты (Premium):</b>\n\n✍️ <b>ИИ-коллекция:</b>\n💭 Мотивационные цитаты: персонализированные\n📋 Полезные списки: '5 способов...'\n❓ Вопросы аудитории: для вовлечения\n📊 Интересные факты: по вашей нише\n🎯 Призывы к действию: эффективные CTA\n\n🤖 <b>ИИ адаптирует</b> под ваш бренд и тон"
    
    else:
        response = "📱 Создание креативов..."
    
    await callback_query.message.edit_text(
        response + "\n\n✨ <b>Готово к использованию</b>",
        parse_mode="HTML"
    )